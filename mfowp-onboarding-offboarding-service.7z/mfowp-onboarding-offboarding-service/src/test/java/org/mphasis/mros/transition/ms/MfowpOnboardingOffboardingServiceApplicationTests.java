package org.mphasis.mros.transition.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfowpOnboardingOffboardingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
