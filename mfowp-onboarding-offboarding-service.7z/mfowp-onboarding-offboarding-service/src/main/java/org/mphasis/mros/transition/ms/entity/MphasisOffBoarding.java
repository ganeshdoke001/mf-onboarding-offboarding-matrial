package org.mphasis.mros.transition.ms.entity;

import java.util.List;

/**
 * Mphasis Off Boarding Procedures
 * 
 *
 */
public class MphasisOffBoarding {

	private String releaseDate_Prisim;

	private String releaseDate;
	
	private String location; 
	
	private Laptop laptop;
	
	private List<Access> access;
	
	private String vpnDeactivated;
	
	private String idDeactivated;
	
	private String mailDeactivated;
	
	private List<Assets> assets;

	public MphasisOffBoarding() {
		super();
	}

	public String getReleaseDate_Prisim() {
		return releaseDate_Prisim;
	}

	public void setReleaseDate_Prisim(String releaseDate_Prisim) {
		this.releaseDate_Prisim = releaseDate_Prisim;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Laptop getLaptop() {
		return laptop;
	}

	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}

	public List<Access> getAccess() {
		return access;
	}

	public void setAccess(List<Access> access) {
		this.access = access;
	}

	public String getVpnDeactivated() {
		return vpnDeactivated;
	}

	public void setVpnDeactivated(String vpnDeactivated) {
		this.vpnDeactivated = vpnDeactivated;
	}

	public String getIdDeactivated() {
		return idDeactivated;
	}

	public void setIdDeactivated(String idDeactivated) {
		this.idDeactivated = idDeactivated;
	}

	public String getMailDeactivated() {
		return mailDeactivated;
	}

	public void setMailDeactivated(String mailDeactivated) {
		this.mailDeactivated = mailDeactivated;
	}

	public List<Assets> getAssets() {
		return assets;
	}

	public void setAssets(List<Assets> assets) {
		this.assets = assets;
	}

	public MphasisOffBoarding(String releaseDate_Prisim, String releaseDate, String location, Laptop laptop,
			List<Access> access, String vpnDeactivated, String idDeactivated, String mailDeactivated,
			List<Assets> assets) {
		super();
		this.releaseDate_Prisim = releaseDate_Prisim;
		this.releaseDate = releaseDate;
		this.location = location;
		this.laptop = laptop;
		this.access = access;
		this.vpnDeactivated = vpnDeactivated;
		this.idDeactivated = idDeactivated;
		this.mailDeactivated = mailDeactivated;
		this.assets = assets;
	}

	@Override
	public String toString() {
		return "MphasisOffBoarding [releaseDate_Prisim=" + releaseDate_Prisim + ", releaseDate=" + releaseDate
				+ ", location=" + location + ", laptop=" + laptop + ", access=" + access + ", vpnDeactivated="
				+ vpnDeactivated + ", idDeactivated=" + idDeactivated + ", mailDeactivated=" + mailDeactivated
				+ ", assets=" + assets + "]";
	}

	
	
}
