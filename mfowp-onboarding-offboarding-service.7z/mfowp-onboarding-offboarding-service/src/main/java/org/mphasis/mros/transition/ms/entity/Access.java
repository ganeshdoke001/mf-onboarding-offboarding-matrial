package org.mphasis.mros.transition.ms.entity;

/**
 * This class if for Store Access Related information
 * ODC Access, Main Gate Access
 * 
 *
 */
public class Access {
	private String accessName;// to Store any device details provided by Client/Mphasis
	private String accessStatus;//to store status of the Access
	
	public Access() {
		super();
	}
	
	public Access(String accessName, String accessStatus) {
		super();
		this.accessName = accessName;
		this.accessStatus = accessStatus;
	}

	
	public String getAccessName() {
		return accessName;
	}
	public void setAccessName(String assetName) {
		this.accessName = assetName;
	}
	
	public String getAccessStatus() {
		return accessStatus;
	}
	public void setAccessStatus(String accessStatus) {
		this.accessStatus = accessStatus;
	}
	
	
	@Override
	public String toString() {
		return "Access [accessName=" + accessName + ", accessStatus=" + accessStatus + "]";
	}


}
