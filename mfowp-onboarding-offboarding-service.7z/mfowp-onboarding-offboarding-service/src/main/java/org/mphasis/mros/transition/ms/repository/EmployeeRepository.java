package org.mphasis.mros.transition.ms.repository;



import java.util.List;



import org.mphasis.mros.transition.ms.entity.EmployeeEntity;
import org.springframework.data.mongodb.repository.MongoRepository;



public interface EmployeeRepository extends MongoRepository<EmployeeEntity, Integer> {
    




}