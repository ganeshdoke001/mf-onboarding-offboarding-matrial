package org.mphasis.mros.transition.ms.entity;


/**
 * Laptop status Status and Laptop Details
 * It is common for Both Mphasis/FedEx
 *
 */
public class Laptop {
	private String status;
	private String hostName;
	private long serialNumber;
	
	
	public Laptop(String status, String hostName, long serialNumber) {
		super();
		this.status = status;
		this.hostName = hostName;
		this.serialNumber = serialNumber;
	}
	public Laptop() {
		super();
	}
	public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		this.status = status;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public long getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(long serialNumber) {
		this.serialNumber = serialNumber;
	}
	@Override
	public String toString() {
		return "Laptop [status=" + status + ", hostName=" + hostName + ", serialNumber=" + serialNumber + "]";
	}
	
	

}
