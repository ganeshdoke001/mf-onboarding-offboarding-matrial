package org.mphasis.mros.transition.ms.entity;

import java.util.List;

/**
 * Mphasis OnBoarding Tracker
 * 
 *
 */
public class MphasisOnBoarding {
	
	private Laptop laptop;
	
	private List<Access> access;
	
	private List<Assets> assets;
	
	private String wfhAttestation;
	
	private String accesstoMandatoryCourse;
	
	private List<MandatoryTraining> mandatoryCourses;
	
	private String mphasisVpnActivated;
	
	private String certificateSubmited;
	
	private String assignmentStartDate;
	
	private String assignmentEndDate;

	public MphasisOnBoarding() {
		super();
	}

	public Laptop getLaptop() {
		return laptop;
	}

	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}

	public List<Access> getAccess() {
		return access;
	}

	public void setAccess(List<Access> access) {
		this.access = access;
	}

	public List<Assets> getAssets() {
		return assets;
	}

	public void setAssets(List<Assets> assets) {
		this.assets = assets;
	}

	public String getWfhAttestation() {
		return wfhAttestation;
	}

	public void setWfhAttestation(String wfhAttestation) {
		this.wfhAttestation = wfhAttestation;
	}

	public String getAccesstoMandatoryCourse() {
		return accesstoMandatoryCourse;
	}

	public void setAccesstoMandatoryCourse(String accesstoMandatoryCourse) {
		this.accesstoMandatoryCourse = accesstoMandatoryCourse;
	}

	public List<MandatoryTraining> getMandatoryCourses() {
		return mandatoryCourses;
	}

	public void setMandatoryCourses(List<MandatoryTraining> mandatoryCourses) {
		this.mandatoryCourses = mandatoryCourses;
	}

	public String getMphasisVpnActivated() {
		return mphasisVpnActivated;
	}

	public void setMphasisVpnActivated(String mphasisVpnActivated) {
		this.mphasisVpnActivated = mphasisVpnActivated;
	}

	public String getCertificateSubmited() {
		return certificateSubmited;
	}

	public void setCertificateSubmited(String certificateSubmited) {
		this.certificateSubmited = certificateSubmited;
	}

	public String getAssignmentStartDate() {
		return assignmentStartDate;
	}

	public void setAssignmentStartDate(String assignmentStartDate) {
		this.assignmentStartDate = assignmentStartDate;
	}

	public String getAssignmentEndDate() {
		return assignmentEndDate;
	}

	public void setAssignmentEndDate(String assignmentEndDate) {
		this.assignmentEndDate = assignmentEndDate;
	}

	public MphasisOnBoarding(Laptop laptop, List<Access> access, List<Assets> assets, String wfhAttestation,
			String accesstoMandatoryCourse, List<MandatoryTraining> mandatoryCourses, String mphasisVpnActivated,
			String certificateSubmited, String assignmentStartDate, String assignmentEndDate) {
		super();
		this.laptop = laptop;
		this.access = access;
		this.assets = assets;
		this.wfhAttestation = wfhAttestation;
		this.accesstoMandatoryCourse = accesstoMandatoryCourse;
		this.mandatoryCourses = mandatoryCourses;
		this.mphasisVpnActivated = mphasisVpnActivated;
		this.certificateSubmited = certificateSubmited;
		this.assignmentStartDate = assignmentStartDate;
		this.assignmentEndDate = assignmentEndDate;
	}

	@Override
	public String toString() {
		return "MphasisOnBoarding [laptop=" + laptop + ", access=" + access + ", assets=" + assets + ", wfhAttestation="
				+ wfhAttestation + ", accesstoMandatoryCourse=" + accesstoMandatoryCourse + ", mandatoryCourses="
				+ mandatoryCourses + ", mphasisVpnActivated=" + mphasisVpnActivated + ", certificateSubmited="
				+ certificateSubmited + ", assignmentStartDate=" + assignmentStartDate + ", assignmentEndDate="
				+ assignmentEndDate + "]";
	}
	
}
