package org.mphasis.mros.transition.ms.entity;

import java.util.List;

public class AccountOnboarding {
	
	private String accountInduction;//Fedex Induction Programe
	private String accountNdaSigned;
	private String accountDateOfJoin;
	private String ldapIdActivated;//LDAP id Status
	private String ldapId;
	private String accountEmailIdActivated;//FedEx mail Id status
	private String accountEmailId;
	private String designation; //
	private String accountMVOIPActivated;
	private Laptop accountLaptop; // FedEx Laptop
	private List<Assets> assets; //Any devices shared by FedEx

	
	public AccountOnboarding() {
		super();
	}


	public String getAccountInduction() {
		return accountInduction;
	}


	public void setAccountInduction(String accountInduction) {
		this.accountInduction = accountInduction;
	}


	public String getAccountNdaSigned() {
		return accountNdaSigned;
	}


	public void setAccountNdaSigned(String accountNdaSigned) {
		this.accountNdaSigned = accountNdaSigned;
	}


	public String getAccountDateOfJoin() {
		return accountDateOfJoin;
	}


	public void setAccountDateOfJoin(String accountDateOfJoin) {
		this.accountDateOfJoin = accountDateOfJoin;
	}


	public String getLdapIdActivated() {
		return ldapIdActivated;
	}


	public void setLdapIdActivated(String ldapIdActivated) {
		this.ldapIdActivated = ldapIdActivated;
	}


	public String getLdapId() {
		return ldapId;
	}


	public void setLdapId(String ldapId) {
		this.ldapId = ldapId;
	}


	public String getAccountEmailIdActivated() {
		return accountEmailIdActivated;
	}


	public void setAccountEmailIdActivated(String accountEmailIdActivated) {
		this.accountEmailIdActivated = accountEmailIdActivated;
	}


	public String getAccountEmailId() {
		return accountEmailId;
	}


	public void setAccountEmailId(String accountEmailId) {
		this.accountEmailId = accountEmailId;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public String getAccountMVOIPActivated() {
		return accountMVOIPActivated;
	}


	public void setAccountMVOIPActivated(String accountMVOIPActivated) {
		this.accountMVOIPActivated = accountMVOIPActivated;
	}


	public Laptop getAccountLaptop() {
		return accountLaptop;
	}


	public void setAccountLaptop(Laptop accountLaptop) {
		this.accountLaptop = accountLaptop;
	}


	public List<Assets> getAssets() {
		return assets;
	}


	public void setAssets(List<Assets> assets) {
		this.assets = assets;
	}


	public AccountOnboarding(String accountInduction, String accountNdaSigned, String accountDateOfJoin,
			String ldapIdActivated, String ldapId, String accountEmailIdActivated, String accountEmailId,
			String designation, String accountMVOIPActivated, Laptop accountLaptop, List<Assets> assets) {
		super();
		this.accountInduction = accountInduction;
		this.accountNdaSigned = accountNdaSigned;
		this.accountDateOfJoin = accountDateOfJoin;
		this.ldapIdActivated = ldapIdActivated;
		this.ldapId = ldapId;
		this.accountEmailIdActivated = accountEmailIdActivated;
		this.accountEmailId = accountEmailId;
		this.designation = designation;
		this.accountMVOIPActivated = accountMVOIPActivated;
		this.accountLaptop = accountLaptop;
		this.assets = assets;
	}


	@Override
	public String toString() {
		return "AccountOnboarding [accountInduction=" + accountInduction + ", accountNdaSigned=" + accountNdaSigned
				+ ", accountDateOfJoin=" + accountDateOfJoin + ", ldapIdActivated=" + ldapIdActivated + ", ldapId="
				+ ldapId + ", accountEmailIdActivated=" + accountEmailIdActivated + ", accountEmailId=" + accountEmailId
				+ ", designation=" + designation + ", accountMVOIPActivated=" + accountMVOIPActivated
				+ ", accountLaptop=" + accountLaptop + ", assets=" + assets + "]";
	}
	
	
		
			

}
