package org.mphasis.mros.transition.ms.exceptionClasses;

public class ValidEmpID extends Exception{
	private String errorMessage;
	public ValidEmpID(String errorMessage) {
		this.errorMessage=errorMessage;
	}

}
