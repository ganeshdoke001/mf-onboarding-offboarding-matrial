package org.mphasis.mros.transition.ms.service;

import java.util.List;

import org.mphasis.mros.transition.ms.entity.EmployeeBGVEntity;
import org.mphasis.mros.transition.ms.entity.EmployeeEntity;
import org.mphasis.mros.transition.ms.exceptionClasses.DataNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.EmpAlreadyExists;
import org.mphasis.mros.transition.ms.exceptionClasses.EmployeeNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;
import org.mphasis.mros.transition.ms.exceptionClasses.ValidEmpID;
import org.springframework.http.ResponseEntity;

public interface MongoDAO {

	// TO insert new Employee Data
	public ResponseEntity<EmployeeEntity> insertnewEmployeeDetails(EmployeeEntity emp) throws EmpAlreadyExists;

	// get Employee data (EmpDetails + BGV Data)
	public ResponseEntity<?> getEmployeeById(int empNumber) throws EmployeeNotFound;

	// delete Employee data (EmpDetails + BGV Data)
	public ResponseEntity<?> deleteEmployeeById(int empNumber) throws DataNotFound;

	// update Employee data
	public ResponseEntity<EmployeeEntity> updateEmployeeDetails(EmployeeEntity emp, int empNumber) throws ValidEmpID;

	public ResponseEntity<?> getEmpInSpecifiedPeriod(String startDate, String endDate) throws IncorrectDateFormat;

	public ResponseEntity<?> getOnboardingEmployeeCount(String startDate, String endDate) throws IncorrectDateFormat;

	public ResponseEntity<?> getOffBoardingEmployeeCount(String startDate, String endDate) throws IncorrectDateFormat;
	
	public ResponseEntity<?> getTransitionEmployeeCount(String startDate, String endDate) throws IncorrectDateFormat;

	public ResponseEntity<?> onboardingStatusCount(String startDate, String endDate) throws IncorrectDateFormat;
	
	public ResponseEntity<?> getCountOfLaptopByDm(int dmEmpId) throws DataNotFound;
	
//	public ResponseEntity<?> getCountOfLaptopByDmList(String startDate, String endDate) throws DataNotFound;
	
	public ResponseEntity<?> getEmployeeDetails(int dmEmpId, String startDate, String endDate) throws IncorrectDateFormat;

    public ResponseEntity<?> getEmployeeDetails(String startDate, String endDate) throws IncorrectDateFormat;


}