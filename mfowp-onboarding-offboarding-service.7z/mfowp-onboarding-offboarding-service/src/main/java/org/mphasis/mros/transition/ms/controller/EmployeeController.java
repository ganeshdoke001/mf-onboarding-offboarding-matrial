package org.mphasis.mros.transition.ms.controller;

import java.util.List;


import javax.validation.Valid;

import org.mphasis.mros.transition.ms.controller.EmployeeController;
import org.mphasis.mros.transition.ms.entity.EmployeeBGVEntity;
import org.mphasis.mros.transition.ms.entity.EmployeeEntity;
import org.mphasis.mros.transition.ms.exceptionClasses.DataNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.EmpAlreadyExists;
import org.mphasis.mros.transition.ms.exceptionClasses.EmployeeNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;
import org.mphasis.mros.transition.ms.exceptionClasses.ValidEmpID;
import org.mphasis.mros.transition.ms.service.MongoDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:4201"})
@Service
public class EmployeeController {
	
	@Autowired
	private org.mphasis.mros.transition.ms.repository.EmployeeRepository empRepo;

	@Autowired
	MongoDAO mongoInterface;

	Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@PostMapping("/addnewEmployee")
	public ResponseEntity<EmployeeEntity> addEmployeeDetails(@Valid @RequestBody EmployeeEntity employeeDetails) throws EmpAlreadyExists {
		logger.info("inside addEmployeeDetails()");
		return mongoInterface.insertnewEmployeeDetails(employeeDetails);

	}

	@GetMapping("/getEmpById/{empNumber}")
	public ResponseEntity<?> getEmployeeById(@PathVariable("empNumber") int empNumber)
			throws EmployeeNotFound {
		logger.info("inside getEmployeeById()");
		return mongoInterface.getEmployeeById(empNumber);

	}
	
	@DeleteMapping("/deleteEmpById/{empNumber}")
	public ResponseEntity<?> deleteEmployeeById(@PathVariable int empNumber) throws DataNotFound{
		logger.info("inside deleteEmployeeById()");
		return mongoInterface.deleteEmployeeById(empNumber);

	}
	
	@PutMapping("/updateEmpById/{empNumber}")
	public ResponseEntity<EmployeeEntity> updateEmployeeDetails(@PathVariable int empNumber,
			@RequestBody EmployeeEntity emp) throws ValidEmpID {
		logger.info("inside updateEmployeeDetails()");
		return mongoInterface.updateEmployeeDetails(emp, empNumber);
	}
	
	@GetMapping("/getEmpInSpecifiedPeriod")
	public ResponseEntity<?> getEmpInSpecifiedPeriod(@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate) throws IncorrectDateFormat {
		logger.info("inside getEmpInSpecifiedPeriod()");
		return mongoInterface.getEmpInSpecifiedPeriod(startDate, endDate);
	}


}
