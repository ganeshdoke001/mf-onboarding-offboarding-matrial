package org.mphasis.mros.transition.ms.service;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.mphasis.mros.transition.ms.entity.AdminUsers;
import org.mphasis.mros.transition.ms.entity.EmployeeEntity;
import org.mphasis.mros.transition.ms.exceptionClasses.DataNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.EmpAlreadyExists;
import org.mphasis.mros.transition.ms.exceptionClasses.EmployeeNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;
import org.mphasis.mros.transition.ms.exceptionClasses.ValidEmpID;
import org.mphasis.mros.transition.ms.repository.EmployeeRepository;
import org.mphasis.mros.transition.ms.util.EmployeeConstants;
import org.mphasis.mros.transition.ms.util.ServiceHelper;
import org.mphasis.mros.transition.ms.vo.EmpTransitionResponseVO;
import org.mphasis.mros.transition.ms.vo.NotificationVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class MongoDAOImpl implements MongoDAO {
	@Autowired
	private EmployeeRepository repository;

	@Autowired
	MongoTemplate mongoTemplate;

	Logger logger = LoggerFactory.getLogger(MongoDAOImpl.class);

	@Override
	public ResponseEntity<EmployeeEntity> insertnewEmployeeDetails(EmployeeEntity emp) throws EmpAlreadyExists {
		EmployeeEntity empDetails = null;
		try {
			empDetails = repository.insert(emp);
//            return "Inserted Successfully";
			logger.debug("MongoDAOImpl.addEmployeeDetails()");
			return empDetails == null ? new ResponseEntity<EmployeeEntity>(empDetails, HttpStatus.BAD_REQUEST)
					: new ResponseEntity<EmployeeEntity>(empDetails, HttpStatus.CREATED);
		} catch (Exception e) {
			System.out.println(e);
			throw new EmpAlreadyExists(EmployeeConstants.EMP_ALREADY_EXISTS);
		}
	}

	@Override
	public ResponseEntity<?> getEmployeeById(int empNumber) throws EmployeeNotFound {
		EmployeeEntity empDetails = null;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			empDetails = repository.findById(empNumber).get();
			logger.debug("MongoDAOImpl.getEmployeeById()");
			if (empDetails != null) {
				responseObj.put("empList", empDetails);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			throw new EmployeeNotFound(EmployeeConstants.EMP_NOT_FOUND);

		}
	}

	@Override
	public ResponseEntity<?> deleteEmployeeById(int empNumber) throws DataNotFound {
		EmployeeEntity empDetails = null;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			empDetails = repository.findById(empNumber).get();
			repository.deleteById(empNumber);
			logger.debug("MongoDAOImpl.deleteEmployeeById()");
			if (empDetails != null) {
				responseObj.put("empList", empDetails);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "410", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.GONE);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			throw new DataNotFound(EmployeeConstants.NO_DATA_AVAILABLE);

		}

	}

	@Override
	public ResponseEntity<EmployeeEntity> updateEmployeeDetails(EmployeeEntity emp, int empNumber) throws ValidEmpID {
		try {
			EmployeeEntity uE = repository.findById(empNumber).get();
			uE.setDate(emp.getDate());
			uE.setEmpNumber(emp.getEmpNumber());
			uE.setEmpName(emp.getEmpName());
			uE.setDateOfJoining(emp.getDateOfJoining());
			uE.setTransitionType(emp.getTransitionType());
			uE.setLocation(emp.getLocation());
			uE.setlocationPosition(emp.getlocationPosition());
			uE.setGradeDesc(emp.getGradeDesc());
			uE.setEmpCategory(emp.getEmpCategory());
			uE.setPmName(emp.getPmName());
			uE.setPmContactEstablished(emp.getPmContactEstablished());
			uE.setProjectNumber(emp.getProjectNumber());
			uE.setProjectName(emp.getProjectName());
			uE.setMphasisOnBoarding(emp.getMphasisOnBoarding());
			uE.setAccountOnboarding(emp.getAccountOnboarding());
			uE.setMphasisOffBoarding(emp.getMphasisOffBoarding());
			uE.setAccountOffBoarding(emp.getAccountOffBoarding());
			uE.setEmployeeBGVdata(emp.getEmployeeBGVdata());
			uE.setResourceAllocationStatus(emp.getResourceAllocationStatus());
			repository.save(uE);
			logger.debug("MongoDAOImpl.updateEmployeeDetails()");
			if (uE != null)
				return new ResponseEntity<EmployeeEntity>(uE, HttpStatus.OK);
			else
				throw new ValidEmpID(EmployeeConstants.VALID_EMP_ID);

		} catch (Exception e) {
			System.out.println(e);
			throw new ValidEmpID(EmployeeConstants.VALID_EMP_ID);
		}

	}

	@Override
	public ResponseEntity<?> getEmpInSpecifiedPeriod(String startDate, String endDate) throws IncorrectDateFormat {
		ResponseEntity<List<EmployeeEntity>> responseEnity = null;
		List<EmployeeEntity> empList = null;
		int count = 0;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();

		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			LocalDate ld = LocalDate.parse(startDate);
			System.out.println(ld);
			LocalDate ld1 = LocalDate.parse(endDate);
			System.out.println(ld1);
			Query queryObj = new Query(Criteria.where("dateOfJoining").gte(startDate).lte(endDate));
//			empList = mongoTemplate.find(queryObj, EmployeeEntity.class);
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			System.out.println(count);
			logger.debug("MongoDAOImpl.getEmpInSpecifiedPeriod() - Query:: ", queryObj.toString());
			if (result.size() > 0) {
				responseObj.put("count", result.size());
				responseObj.put("empList", result);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException e) {
			throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}

	}

	/*
	 * Getting the count of
	 * laptopAllocated,ODCAccess,NDASigned,MandatoryCourses,WFHAttestation,
	 * FedexInduction
	 * 
	 * @Param - date & transition
	 * 
	 */
	@Override
	public ResponseEntity<?> onboardingStatusCount(String startDate, String endDate) throws IncorrectDateFormat {
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		int count = 0;
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			LocalDate ld = LocalDate.parse(startDate);
			System.out.println(ld);
			LocalDate ld1 = LocalDate.parse(endDate);
			System.out.println(ld1);
//			Query queryObj = new Query(Criteria.where("transitionType").is("Seperated").and("dateOfJoining").gte(startDate).lte(endDate));	
			Query queryObj = new Query(new Criteria()
					.orOperator(Criteria.where("transitionType").is("New Hire"),
							Criteria.where("transitionType").is("In-Transfer"))
					.andOperator(Criteria.where("dateOfJoining").gte(startDate).lte(endDate)));
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			Map<String, Object> fedexODCObj = ServiceHelper.getODCAccesCount(result);
			Map<String, Object> laptopAllocatedObj = ServiceHelper.getLaptopAllocatedCount(result);
			Map<String, Object> ndaSignedObj = ServiceHelper.getndaSignedCount(result);
			Map<String, Object> mandatoryTrainingObj = ServiceHelper.getmandatoryTrainingCount(result);
			Map<String, Object> wfhAttestationObj = ServiceHelper.getWfhAttestationCount(result);
			Map<String, Object> accountInductionObj = ServiceHelper.getAccountInductionCount(result);
			logger.debug("MongoDAOImpl.onboardingStatusCount() - Query:: ", queryObj.toString());
			if (result.size() > 0) {
				LinkedHashMap<String, Object> finalMap = new LinkedHashMap<String, Object>();
				finalMap.put("ODCAccess", fedexODCObj);
				finalMap.put("laptopAllocated", laptopAllocatedObj);
				finalMap.put("accountInduction", accountInductionObj);
				finalMap.put("ndaSigned", ndaSignedObj);
				finalMap.put("mandatoryTraining", mandatoryTrainingObj);
				finalMap.put("wfhAttestation", wfhAttestationObj);
//					responseObj.put("empList", result);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(finalMap);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException e) {
			throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}
	}

	@Override
	public ResponseEntity<?> getOnboardingEmployeeCount(String startDate, String endDate) throws IncorrectDateFormat {
//	        String startDate = DateUtil.getStartDate(month, "-");
//	        String endDate = DateUtil.getEndDate(month, "-");
		int count = 0;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			LocalDate ld = LocalDate.parse(startDate);
			System.out.println(ld);
			Query queryObj = new Query(new Criteria()
					.orOperator(Criteria.where("transitionType").is("New Hire"),
							Criteria.where("transitionType").is("In-Transfer"))
					.andOperator(Criteria.where("dateOfJoining").gte(startDate).lte(endDate)));
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			System.out.println(count);
			logger.debug("MongoDAOImpl.getOnboardingEmployeeCount() - Query:: ", queryObj.toString());
			if (result.size() > 0) {
				responseObj.put("count", result.size());
				responseObj.put("empList", result);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException e) {
			throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}
	}

	@Override
	public ResponseEntity<?> getOffBoardingEmployeeCount(String startDate, String endDate) throws IncorrectDateFormat {
//	        String startDate = DateUtil.getStartDate(month, "-");
//	        String endDate = DateUtil.getEndDate(month, "-");
		int count = 0;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			LocalDate ld = LocalDate.parse(startDate);
			System.out.println(ld);
			Query queryObj = new Query(Criteria.where("transitionType").is("Seperated").and("MphasisOffBoarding.releaseDate").gte(startDate).lte(endDate));	
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			System.out.println(count);
			logger.debug("MongoDAOImpl.getOffBoardingEmployeeCount() - Query:: ", queryObj.toString());
			if (result.size() > 0) {
				responseObj.put("count", result.size());
				responseObj.put("empList", result);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException e) {
			throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}
	}
	
	
	@Override
	public ResponseEntity<?> getTransitionEmployeeCount(String startDate, String endDate) throws IncorrectDateFormat {
//	        String startDate = DateUtil.getStartDate(month, "-");
//	        String endDate = DateUtil.getEndDate(month, "-");
		int count = 0;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			LocalDate ld = LocalDate.parse(startDate);
			System.out.println(ld);
			Query queryObj = new Query(Criteria.where("transitionType").is("Out-Transfer").and("dateOfJoining").gte(startDate).lte(endDate));	
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			System.out.println(count);
			logger.debug("MongoDAOImpl.getTransitionEmployeeCount() - Query:: ", queryObj.toString());
			if (result.size() > 0) {
				responseObj.put("count", result.size());
				responseObj.put("empList", result);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException e) {
			throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}
	}
	
	
	@Override
	public ResponseEntity<?> getCountOfLaptopByDm(int dmEmpId) throws DataNotFound {
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		int count = 0;
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			Query queryObj = new Query(Criteria.where("dmEmpId").is(dmEmpId));
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			Map<String, Object> laptopAllocatedObj = ServiceHelper.getLaptopAllocatedCount(result);
			System.out.println(count);
			logger.debug("MongoDAOImpl.getCountOfLaptopByDm() - Query:: ", queryObj.toString());
			if (result.size() > 0) {
				Map<String, Object> finalMap = new HashMap<String, Object>();
				finalMap.put("laptopAllocated", laptopAllocatedObj);
//				finalMap.put("count", result.size());
//				finalMap.put("empList", result);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(finalMap);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			throw new DataNotFound(EmployeeConstants.NO_DATA_AVAILABLE);
		}
	}

	
	
//	@Override
//	public ResponseEntity<?> getCountOfLaptopByDmList(String startDate, String endDate) throws DataNotFound {
//		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
//		int count = 0;
//		try {
//			Map<String, Object> responseObj = new HashMap<String, Object>();
//	        Map<Integer, String> map = new HashMap<>();
//			Query query = new Query(new Criteria().where("employeeNumber").ne(null));
//			List<AdminUsers> adminUsersList = mongoTemplate.find(query,AdminUsers.class);
//			map=adminUsersList.stream().collect(Collectors.toMap(AdminUsers::getEmployeeNumber,AdminUsers::getEmployeeName));
//			System.out.println("------------ "+map.entrySet().stream().map(Map.Entry::getKey).collect(Collectors.toSet()));
//			Query queryObj = new Query(new Criteria()
//					.orOperator(Criteria.where("transitionType").is("New Hire"),
//							Criteria.where("transitionType").is("In-Transfer"))
//					.andOperator(Criteria.where("dmEmpId").in(map.entrySet().stream()
//				              .map(Map.Entry::getKey).collect(Collectors.toSet())).and("dateOfJoining").gte(startDate).lte(endDate)));
//			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
////			System.out.println("- Query:: ," +queryObj.toString());
////			System.out.println("result: "+result.toString());																					
//			
//			//Create one Map and Store DM Id and List
//			
//			Map<String, Object> laptopAllocatedObj = ServiceHelper.getLaptopAllocatedCount(result);
//			logger.debug("MongoDAOImpl.getCountOfLaptopByDmList() - Query:: ", queryObj.toString());
//			if (result.size() > 0) {
//				Map<String, Object> finalMap = new HashMap<String, Object>();
//				finalMap.put("laptopAllocated", laptopAllocatedObj);
//				responseObj.put("count", result.size());
//				responseObj.put("empList", result);
//				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
//				empTransitionResponseVO.setData(finalMap);
//				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
//						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
//				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
//			} else {
//				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
//				empTransitionResponseVO.setData(responseObj);
//				empTransitionResponseVO.setNotification(
//						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
//				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
//			}
//		} catch (Exception e) {
//			throw new DataNotFound(EmployeeConstants.NO_DATA_AVAILABLE);
//		}
//	}
	
	
	@SuppressWarnings("static-access")
    @Override
    public ResponseEntity<?> getEmployeeDetails(int dmEmpId, String startDate, String endDate) throws IncorrectDateFormat {       
        EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
        try {
            Map<String, Object> responseObj = new HashMap<String, Object>();
            // validating startDate and endDate
            LocalDate ld = LocalDate.parse(startDate);
            System.out.println(ld);
            LocalDate ld1 = LocalDate.parse(endDate);
            System.out.println(ld1);
            // query to filter based on parameters
            Query queryObj = new Query(new Criteria()
                    .where("transitionType").in("New Hire","In-Transfer")
                    .and("dmEmpId").is(dmEmpId).and("dateOfJoining").gte(startDate).lte(endDate));
            List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
            logger.debug("MongoDAOImpl.getEmployeeDetails() - Query:: ", queryObj.toString());
            if (result.size() > 0) {
            //    responseObj.put("count", result.size());
                responseObj.put("empList", result);
                empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
                empTransitionResponseVO.setData(responseObj);
                empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
                        EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
              return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
            } else {
                empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
                empTransitionResponseVO.setData(responseObj);
                empTransitionResponseVO.setNotification(
                        new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
                return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
            }
        } catch (DateTimeParseException e) {
            throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT, "FAILURE");
        }
    }
	
    
    @SuppressWarnings("static-access")
    @Override
    public ResponseEntity<?> getEmployeeDetails( String startDate, String endDate) throws IncorrectDateFormat {       
        EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
        try {
            Map<String, Object> responseObj = new HashMap<String, Object>();
            // validating startDate and endDate
            LocalDate ld = LocalDate.parse(startDate);
            System.out.println(ld);
            LocalDate ld1 = LocalDate.parse(endDate);
            System.out.println(ld1);
            // query to filter based on parameters
            Query queryObj = new Query(new Criteria()
                    .where("transitionType").in("New Hire","In-Transfer")
                    .and("dateOfJoining").gte(startDate).lte(endDate));
            List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
            logger.debug("MongoDAOImpl.getEmployeeDetails() - Query:: ", queryObj.toString());
            if (result.size() > 0) {
            //    responseObj.put("count", result.size());
                responseObj.put("empList", result);
                empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
                empTransitionResponseVO.setData(responseObj);
                empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
                        EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
              return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
            } else {
                empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
                empTransitionResponseVO.setData(responseObj);
                empTransitionResponseVO.setNotification(
                        new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
                return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
            }
        } catch (DateTimeParseException e) {
            throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT, "FAILURE");
        }
    }
}
