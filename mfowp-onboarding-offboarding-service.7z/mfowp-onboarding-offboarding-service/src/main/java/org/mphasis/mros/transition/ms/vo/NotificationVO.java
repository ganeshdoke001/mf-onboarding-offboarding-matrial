package org.mphasis.mros.transition.ms.vo;

public class NotificationVO {
	
	
	private String message;//to indicate the status
	private String highseverity;
	private String code;
	private String source;

	public NotificationVO(String message,String highseverity, String code, String source) {
		super();
		this.message = message;
		this.highseverity = highseverity;
		this.code=code;
		this.source=source;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSeverity() {
		return highseverity;
	}
	public void setSeverity(String highseverity) {
		this.highseverity = highseverity;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	
	@Override
	public String toString() {
		return "";
		
	}

}
