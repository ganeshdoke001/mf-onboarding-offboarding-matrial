package org.mphasis.mros.transition.ms.entity;

import java.util.List;


import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * To store Employee Master info
 * Mphasis On Boarding/Off Boarding Details, On Boarding/Off Boarding FedEx Details, 
 *
 */
@Document(collection = "Employee")
public class EmployeeEntity {
	private String date;
	@Id
	private int empNumber;
	private String empName;
	private String dateOfJoining;
	private String transitionType;// New Hire/In-Transfer/Supparated 
	private String location;
	private String locationPosition;//Onsite/Offshore
	private String gradeDesc;
	private String empCategory;
	private int pmEmpId;
	private String pmName;
	private String pmContactEstablished;
	private int dmEmpId;
	private String dmName;
	private String projectNumber;
	private String projectName;
	private String resourceAllocationStatus;
	private MphasisOnBoarding mphasisOnBoarding;
	private AccountOnboarding accountOnboarding;
	private MphasisOffBoarding mphasisOffBoarding;
	private AccountOffBoarding accountOffBoarding;
	private EmployeeBGVEntity employeeBGVdata;
	
	public EmployeeEntity(int pmEmpId, int dmEmpId) {
		super();
		this.pmEmpId = pmEmpId;
		this.dmEmpId = dmEmpId;
	}
	public EmployeeEntity() {
		super();
	}
	public EmployeeEntity(String date, int empNumber, String empName, String dateOfJoining, String transitionType,
			String location, String locationPosition, String gradeDesc, String empCategory, String pmName,
			String pmContactEstablished, String dmName, String projectNumber, String projectName,
			String respourceAllocationStatus, MphasisOnBoarding mphasisOnBoarding, AccountOnboarding accountOnboarding,
			MphasisOffBoarding mphasisOffBoarding, AccountOffBoarding accountOffBoarding, String resourceAllocationStatus) {
		super();
		this.date = date;
		this.empNumber = empNumber;
		this.empName = empName;
		this.dateOfJoining = dateOfJoining;
		this.transitionType = transitionType;
		this.location = location;
		this.locationPosition = locationPosition;
		this.gradeDesc = gradeDesc;
		this.empCategory = empCategory;
		this.pmName = pmName;
		this.pmContactEstablished = pmContactEstablished;
		this.dmName = dmName;
		this.projectNumber = projectNumber;
		this.projectName = projectName;
		this.resourceAllocationStatus = resourceAllocationStatus;
		this.mphasisOnBoarding = mphasisOnBoarding;
		this.accountOnboarding = accountOnboarding;
		this.mphasisOffBoarding = mphasisOffBoarding;
		this.accountOffBoarding = accountOffBoarding;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getEmpNumber() {
		return empNumber;
	}
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getTransitionType() {
		return transitionType;
	}
	public void setTransitionType(String transitionType) {
		this.transitionType = transitionType;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getlocationPosition() {
		return locationPosition;
	}
	public void setlocationPosition(String locationPosition) {
		this.locationPosition = locationPosition;
	}
	public String getGradeDesc() {
		return gradeDesc;
	}
	public void setGradeDesc(String gradeDesc) {
		this.gradeDesc = gradeDesc;
	}
	public String getEmpCategory() {
		return empCategory;
	}
	public void setEmpCategory(String empCategory) {
		this.empCategory = empCategory;
	}
	public String getPmName() {
		return pmName;
	}
	public void setPmName(String pmName) {
		this.pmName = pmName;
	}
	public int getPmEmpId() {
		return pmEmpId;
	}
	public void setPmEmpId(int pmEmpId) {
		this.pmEmpId = pmEmpId;
	}
	public int getDmEmpId() {
		return dmEmpId;
	}
	public void setDmEmpId(int dmEmpId) {
		this.dmEmpId = dmEmpId;
	}
	public String getPmContactEstablished() {
		return pmContactEstablished;
	}
	public void setPmContactEstablished(String pmContactEstablished) {
		this.pmContactEstablished = pmContactEstablished;
	}
	public String getDmName() {
		return dmName;
	}
	public void setDmName(String dmName) {
		this.dmName = dmName;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getResourceAllocationStatus() {
		return resourceAllocationStatus;
	}
	public void setResourceAllocationStatus(String resourceAllocationStatus) {
		this.resourceAllocationStatus = resourceAllocationStatus;
	}
	public MphasisOnBoarding getMphasisOnBoarding() {
		return mphasisOnBoarding;
	}
	public void setMphasisOnBoarding(MphasisOnBoarding mphasisOnBoarding) {
		this.mphasisOnBoarding = mphasisOnBoarding;
	}
	public AccountOnboarding getAccountOnboarding() {
		return accountOnboarding;
	}
	public void setAccountOnboarding(AccountOnboarding accountOnboarding) {
		this.accountOnboarding = accountOnboarding;
	}
	public MphasisOffBoarding getMphasisOffBoarding() {
		return mphasisOffBoarding;
	}
	public void setMphasisOffBoarding(MphasisOffBoarding mphasisOffBoarding) {
		this.mphasisOffBoarding = mphasisOffBoarding;
	}
	public AccountOffBoarding getAccountOffBoarding() {
		return accountOffBoarding;
	}
	public void setAccountOffBoarding(AccountOffBoarding accountOffBoarding) {
		this.accountOffBoarding = accountOffBoarding;
	}
	
	public EmployeeBGVEntity getEmployeeBGVdata() {
		return employeeBGVdata;
	}
	public void setEmployeeBGVdata(EmployeeBGVEntity employeeBGVdata) {
		this.employeeBGVdata = employeeBGVdata;
	}
	@Override
	public String toString() {
		return "EmployeeEntity [date=" + date + ", empNumber=" + empNumber + ", empName=" + empName + ", dateOfJoining="
				+ dateOfJoining + ", transitionType=" + transitionType + ", location=" + location
				+ ", locationPosition=" + locationPosition + ", gradeDesc=" + gradeDesc + ", empCategory="
				+ empCategory + ", pmEmpId=" + pmEmpId + ", pmName=" + pmName + ", pmContactEstablished="
				+ pmContactEstablished + ", dmEmpId=" + dmEmpId + ", dmName=" + dmName + ", projectNumber="
				+ projectNumber + ", projectName=" + projectName + ", resourceAllocationStatus="
				+ resourceAllocationStatus + ", mphasisOnBoarding=" + mphasisOnBoarding + ", accountOnboarding="
				+ accountOnboarding + ", mphasisOffBoarding=" + mphasisOffBoarding + ", accountOffBoarding="
				+ accountOffBoarding + ", employeeBGVdata=" + employeeBGVdata + "]";
	}
	
	


}
