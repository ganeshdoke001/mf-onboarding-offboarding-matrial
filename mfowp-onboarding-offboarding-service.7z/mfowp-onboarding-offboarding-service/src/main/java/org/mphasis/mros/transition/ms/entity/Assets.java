package org.mphasis.mros.transition.ms.entity;

/**
 * Assets/Device Related Info 
 * It is common for FedEx and Mphasis
 * 
 *
 */
public class Assets {
	
	private String assetName; // Assets Details by FedEx/Mphasis

	private String assetStatus;
	
	public Assets() {
		super();
	}

	public Assets(String assetName, String assetStatus) {
		super();
		this.assetName = assetName;
		this.assetStatus = assetStatus;
	}

	public String getassetName() {
		return assetName;
	}

	public void setassetName(String assetName) {
		this.assetName = assetName;
	}

	public String getassetStatus() {
		return assetStatus;
	}

	public void setassetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}

	@Override
	public String toString() {
		return "Assets [assetName=" + assetName + ", assetStatus=" + assetStatus + "]";
	}

}
