package org.mphasis.mros.transition.ms.exceptionClasses;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.mphasis.mros.transition.ms.util.EmployeeConstants;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class RootExpceptionClass extends ResponseEntityExceptionHandler {
	
	@ResponseStatus(value= HttpStatus.NOT_FOUND,reason=EmployeeConstants.EMP_NOT_FOUND)
	@ExceptionHandler(EmployeeNotFound.class)
	public ResponseEntity<?> handleEmployeeNotFoundException(EmployeeNotFound empNotFound){
		Map<String,String> errorMap = new HashMap<String,String>();
		errorMap.put("error Message::", empNotFound.getMessage());
		return new ResponseEntity<Map<String,String>>(errorMap,HttpStatus.NOT_FOUND);
	}
	
	
	@ResponseStatus(value= HttpStatus.NOT_FOUND,reason=EmployeeConstants.NO_DATA_AVAILABLE)
	@ExceptionHandler(DataNotFound.class)
	public ResponseEntity<?> handleDataNotFoundException(DataNotFound dataNotFound){
		Map<String,String> errorMap = new HashMap<String,String>();
		errorMap.put("error Message::", dataNotFound.getMessage());
		return new ResponseEntity<Map<String,String>>(errorMap,HttpStatus.NOT_FOUND);
	}
	
	@ResponseStatus(value= HttpStatus.BAD_REQUEST,reason=EmployeeConstants.INCORRECT_DATE_FORMAT)
	@ExceptionHandler(IncorrectDateFormat.class)
	public ResponseEntity<?> handleIncorrectDateFormatException(IncorrectDateFormat incorrectDateFormat){
		Map<String,String> errorMap = new HashMap<String,String>();
		errorMap.put("error Message::", incorrectDateFormat.getMessage());
		return new ResponseEntity<Map<String,String>>(errorMap,HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(value= HttpStatus.BAD_REQUEST,reason=EmployeeConstants.VALID_EMP_ID)
	@ExceptionHandler(ValidEmpID.class)
	public ResponseEntity<?> handleValidEmpIDException(ValidEmpID ValidEmpID){
		Map<String,String> errorMap = new HashMap<String,String>();
		errorMap.put("error Message::", ValidEmpID.getMessage());
		return new ResponseEntity<Map<String,String>>(errorMap,HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(value= HttpStatus.CONFLICT,reason=EmployeeConstants.EMP_ALREADY_EXISTS)
	@ExceptionHandler(EmpAlreadyExists.class)
	public ResponseEntity<?> handleEmpAlreadyExistsException(EmpAlreadyExists EmpAlreadyExists){
		Map<String,String> errorMap = new HashMap<String,String>();
		errorMap.put("error Message::", EmpAlreadyExists.getMessage());
		return new ResponseEntity<Map<String,String>>(errorMap,HttpStatus.CONFLICT);
	}
	
	@Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
        HttpHeaders headers, HttpStatus status, WebRequest request) {
            Map<String, Object> body = new LinkedHashMap<>();
            List<String> errors = ex.getBindingResult()
                                .getAllErrors()
                                .stream()
                                .map(e -> e.getDefaultMessage())
                                .collect(Collectors.toList());
            body.put("errors", errors);
        return new ResponseEntity<>(body,headers,status);
    }
	
	
	
		

}
