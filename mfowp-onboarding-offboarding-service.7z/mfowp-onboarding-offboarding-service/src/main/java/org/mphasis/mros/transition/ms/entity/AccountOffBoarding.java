package org.mphasis.mros.transition.ms.entity;

import java.util.List;

/**
 * FedEx Off Boarding Procedures 
 * 
 * 
 *
 */
public class AccountOffBoarding {
	
	private String ldapDecativated;//FedEx Ladap id
	
	private String emailDecativated;//FedEx Email
	
	private String mvoipDecativated;

	private Laptop laptop;//If Laptop allocated by FedEx
	
	private List<Assets> assets;//any other devices provided by FedEx


	public AccountOffBoarding() {
		super();
	}


	public String getLdapDecativated() {
		return ldapDecativated;
	}


	public void setLdapDecativated(String ldapDecativated) {
		this.ldapDecativated = ldapDecativated;
	}


	public String getEmailDecativated() {
		return emailDecativated;
	}


	public void setEmailDecativated(String emailDecativated) {
		this.emailDecativated = emailDecativated;
	}


	public String getMvoipDecativated() {
		return mvoipDecativated;
	}


	public void setMvoipDecativated(String mvoipDecativated) {
		this.mvoipDecativated = mvoipDecativated;
	}


	public Laptop getLaptop() {
		return laptop;
	}


	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}


	public List<Assets> getAssets() {
		return assets;
	}


	public void setAssets(List<Assets> assets) {
		this.assets = assets;
	}


	public AccountOffBoarding(String ldapDecativated, String emailDecativated, String mvoipDecativated, Laptop laptop,
			List<Assets> assets) {
		super();
		this.ldapDecativated = ldapDecativated;
		this.emailDecativated = emailDecativated;
		this.mvoipDecativated = mvoipDecativated;
		this.laptop = laptop;
		this.assets = assets;
	}


	@Override
	public String toString() {
		return "AccountOffBoarding [ldapDecativated=" + ldapDecativated + ", emailDecativated=" + emailDecativated
				+ ", mvoipDecativated=" + mvoipDecativated + ", laptop=" + laptop + ", assets=" + assets + "]";
	}

	


}
