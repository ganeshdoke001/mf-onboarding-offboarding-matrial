package org.mphasis.mros.transition.ms.entity;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.annotation.Id;

@Document(collection="ADMIN_USERS")
public class AdminUsers {

	@Id
	private int employeeNumber;
	private String employeeName;
	private String empMail;
	private String role;
	
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmpMail() {
		return empMail;
	}
	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public AdminUsers(int employeeNumber, String employeeName, String empMail, String role) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.empMail = empMail;
		this.role = role;
	}
	public AdminUsers() {
		super();
		
	}
	@Override
	public String toString() {
		return "AdminUsers [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + ", empMail="
				+ empMail + ", role=" + role + "]";
	}
	
	
}
