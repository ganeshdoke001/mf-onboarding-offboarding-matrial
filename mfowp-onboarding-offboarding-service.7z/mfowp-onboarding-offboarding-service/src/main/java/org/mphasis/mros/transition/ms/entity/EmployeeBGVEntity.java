package org.mphasis.mros.transition.ms.entity;

import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="employeeBGVdata")
public class EmployeeBGVEntity {
	
	@NotBlank(message = "org_Relation is mandatory")
	private String org_Relation;
	@NotBlank(message = "start_Date is mandatory")
	private String start_Date;
	@NotBlank(message = "service_Line is mandatory")
	private String service_Line;
	@NotBlank(message = "location is mandatory")
	private String location;
	@NotBlank(message = "status is mandatory")
	private String status;
	
	
	public EmployeeBGVEntity(String org_Relation, String start_Date, String service_Line,
			String location, String status) {
		super();
		
		this.org_Relation = org_Relation;
		this.start_Date = start_Date;
		this.service_Line = service_Line;
		this.location = location;
		this.status = status;
	}
	
	public EmployeeBGVEntity() {
		super();
	}

		public String getOrg_Relation() {
		return org_Relation;
	}
	public void setOrg_Relation(String org_Relation) {
		this.org_Relation = org_Relation;
	}
	public String getStart_Date() {
		return start_Date;
	}
	public void setStart_Date(String start_Date) {
		this.start_Date = start_Date;
	}
	public String getService_Line() {
		return service_Line;
	}
	public void setService_Line(String service_Line) {
		this.service_Line = service_Line;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
