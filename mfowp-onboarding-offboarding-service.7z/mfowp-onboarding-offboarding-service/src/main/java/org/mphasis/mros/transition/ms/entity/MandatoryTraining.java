package org.mphasis.mros.transition.ms.entity;


/**
 * Mandatory Course Info related to Mphasis
 *
 */
public class MandatoryTraining {
	private String courseName;
	private String status;
	
	
	public MandatoryTraining() {
		super();
	}
	public MandatoryTraining(String courseName, String status) {
		super();
		this.courseName = courseName;
		this.status = status;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "MandatoryTraining [courseName=" + courseName + ", status=" + status + "]";
	}
	
	

}
