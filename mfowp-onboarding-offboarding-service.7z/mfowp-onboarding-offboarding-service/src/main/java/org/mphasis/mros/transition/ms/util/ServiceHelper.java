package org.mphasis.mros.transition.ms.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.mphasis.mros.transition.ms.entity.EmployeeEntity;
import org.mphasis.mros.transition.ms.entity.MphasisOnBoarding;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;

public class ServiceHelper {

	public static Map<String, Object> getODCAccesCount(List<EmployeeEntity> result) {
		List<EmployeeEntity> ODCYesList = null;
		List<EmployeeEntity> ODCNoList = null;
		List<EmployeeEntity> ODCNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				ODCYesList = result.stream()
						.filter(s -> s.getMphasisOnBoarding().getAccess().stream().anyMatch(
								a -> (a.getAccessName().equalsIgnoreCase("ODC Access") && a.getAccessStatus().equalsIgnoreCase("Yes"))))
						.collect(Collectors.toList());
				responseObj.put("Yes", ODCYesList.size());
				ODCNoList = result.stream()
						.filter(s -> s.getMphasisOnBoarding().getAccess().stream().anyMatch(
								a -> (a.getAccessName().equalsIgnoreCase("ODC Access") && a.getAccessStatus().equalsIgnoreCase("No"))))
						.collect(Collectors.toList());
				responseObj.put("No", ODCNoList.size());
				ODCNAList = result.stream()
						.filter(s -> s.getMphasisOnBoarding().getAccess().stream().anyMatch(
								a -> (a.getAccessName().equalsIgnoreCase("ODC Access") && a.getAccessStatus().equalsIgnoreCase("NA"))))
						.collect(Collectors.toList());
				responseObj.put("NA", ODCNAList.size());
			}
		}
		catch (Exception e) {
		}
		return responseObj;
	}

	public static Map<String, Object> getLaptopAllocatedCount(List<EmployeeEntity> result) {
		List<EmployeeEntity> laptopAllocatedYesList = null;
		List<EmployeeEntity> laptopAllocatedNoList = null;
		List<EmployeeEntity> laptopAllocatedNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				laptopAllocatedYesList = result.stream()
						.filter(e -> e.getMphasisOnBoarding().getLaptop().getstatus().equalsIgnoreCase("Yes"))
						.collect(Collectors.toList());
				responseObj.put("Yes", laptopAllocatedYesList.size());
				laptopAllocatedNoList = result.stream()
						.filter(e -> e.getMphasisOnBoarding().getLaptop().getstatus().equalsIgnoreCase("No"))
						.collect(Collectors.toList());
				responseObj.put("No", laptopAllocatedNoList.size());
				laptopAllocatedNAList = result.stream()
						.filter(e -> e.getMphasisOnBoarding().getLaptop().getstatus().equalsIgnoreCase("NA"))
						.collect(Collectors.toList());
				responseObj.put("NA", laptopAllocatedNAList.size());
			}

		} catch (Exception e) {
		}
		return responseObj;
	}

	public static Map<String, Object> getndaSignedCount(List<EmployeeEntity> result) {
		List<EmployeeEntity> ndaSignedYesList = null;
		List<EmployeeEntity> ndaSignedNoList = null;
		List<EmployeeEntity> ndaSignedNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				ndaSignedYesList =  result.stream()
						.filter(e -> e.getAccountOnboarding().getAccountNdaSigned().equalsIgnoreCase("Yes"))
						.collect(Collectors.toList());
				responseObj.put("Yes", ndaSignedYesList.size());
				ndaSignedNoList =  result.stream()
						.filter(e -> e.getAccountOnboarding().getAccountNdaSigned().equalsIgnoreCase("No"))
						.collect(Collectors.toList());
				responseObj.put("No", ndaSignedNoList.size());
				ndaSignedNAList =  result.stream()
						.filter(e -> e.getAccountOnboarding().getAccountNdaSigned().equalsIgnoreCase("NA"))
						.collect(Collectors.toList());
				responseObj.put("NA", ndaSignedNAList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;

	}

	public static Map<String, Object> getmandatoryTrainingCount(List<EmployeeEntity> result) {
		List<EmployeeEntity> mandatoryTrainingDataPrivacyYesList = null;
		List<EmployeeEntity> mandatoryTrainingDataPrivacyNoList = null;
		List<EmployeeEntity> mandatoryTrainingIsmsYesList = null;
		List<EmployeeEntity> mandatoryTrainingIsmsNoList = null;

		Map<String, Object> dataPrivacyResponseObj = new HashMap<String, Object>();
		Map<String, Object> ismsResponseObj = new HashMap<String, Object>();

		Map<String, Object> responseObj = new HashMap<String, Object>();

		try {
			if (result != null && !result.isEmpty()) {
				// Data privacy
				mandatoryTrainingDataPrivacyYesList = result.stream()
						.filter(s -> s.getMphasisOnBoarding().getMandatoryCourses().stream().anyMatch(
								a -> (a.getCourseName().equalsIgnoreCase("Data Privacy") && a.getStatus().equalsIgnoreCase("Yes"))))
						.collect(Collectors.toList());
				dataPrivacyResponseObj.put("Yes", mandatoryTrainingDataPrivacyYesList.size());
				mandatoryTrainingDataPrivacyNoList = result.stream()
						.filter(s -> s.getMphasisOnBoarding().getMandatoryCourses().stream().anyMatch(
								a -> (a.getCourseName().equalsIgnoreCase("Data Privacy") && a.getStatus().equalsIgnoreCase("No"))))
						.collect(Collectors.toList());
				dataPrivacyResponseObj.put("No", mandatoryTrainingDataPrivacyNoList.size());
		
				responseObj.put("Data privacy", dataPrivacyResponseObj);

				// ISMS response
				mandatoryTrainingIsmsYesList = result.stream()
						.filter(s -> s.getMphasisOnBoarding().getMandatoryCourses().stream().anyMatch(
								a -> (a.getCourseName().equals("ISMS") && a.getStatus().equalsIgnoreCase("Yes"))))
						.collect(Collectors.toList());
				ismsResponseObj.put("Yes", mandatoryTrainingIsmsYesList.size());
				mandatoryTrainingIsmsNoList =result.stream()
						.filter(s -> s.getMphasisOnBoarding().getMandatoryCourses().stream().anyMatch(
								a -> (a.getCourseName().equals("ISMS") && a.getStatus().equalsIgnoreCase("No"))))
						.collect(Collectors.toList());
				ismsResponseObj.put("No", mandatoryTrainingIsmsNoList.size());
				
				responseObj.put("ISMS", ismsResponseObj);
			}

		} catch (Exception e) {

		}
		return responseObj;

	}

	public static Map<String, Object> getWfhAttestationCount(List<EmployeeEntity> result) {
		List<EmployeeEntity> wfhAttestationYesList = null;
		List<EmployeeEntity> wfhAttestationNoList = null;
		List<EmployeeEntity> wfhAttestationNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				wfhAttestationYesList = result.stream()
						.filter(e -> e.getMphasisOnBoarding().getWfhAttestation().equalsIgnoreCase("Yes"))
						.collect(Collectors.toList());
				responseObj.put("Yes", wfhAttestationYesList.size());
				wfhAttestationNoList = result.stream()
						.filter(e -> e.getMphasisOnBoarding().getWfhAttestation().equalsIgnoreCase("No"))
						.collect(Collectors.toList());
				responseObj.put("No", wfhAttestationNoList.size());
				wfhAttestationNAList = result.stream()
						.filter(e -> e.getMphasisOnBoarding().getWfhAttestation().equalsIgnoreCase("NA"))
						.collect(Collectors.toList());
				responseObj.put("NA", wfhAttestationNAList.size());
			}

		} catch (Exception e) {
		}
		return responseObj;

	}

	public static Map<String, Object> getAccountInductionCount(List<EmployeeEntity> result) {
		List<EmployeeEntity> accountInductionYesList = null;
		List<EmployeeEntity> accountInductionNoList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				accountInductionYesList = result.stream()
						.filter(e -> e.getAccountOnboarding().getAccountInduction().equalsIgnoreCase("Yes"))
						.collect(Collectors.toList());
				responseObj.put("Yes", accountInductionYesList.size());
				accountInductionNoList = result.stream()
						.filter(e -> e.getAccountOnboarding().getAccountInduction().equalsIgnoreCase("No"))
						.collect(Collectors.toList());
				responseObj.put("No", accountInductionNoList.size());

			}

		} catch (Exception e) {

		}
		return responseObj;

  }

}
