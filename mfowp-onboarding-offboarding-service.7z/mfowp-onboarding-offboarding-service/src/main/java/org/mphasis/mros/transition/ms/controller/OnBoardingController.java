package org.mphasis.mros.transition.ms.controller;

import org.mphasis.mros.transition.ms.exceptionClasses.DataNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;
import org.mphasis.mros.transition.ms.service.MongoDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/onboardings/v1")
@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:4201"})
@Service
public class OnBoardingController {

	@Autowired
	private org.mphasis.mros.transition.ms.repository.EmployeeRepository empRepo;

	@Autowired
	MongoDAO mongoInterface;

	Logger logger = LoggerFactory.getLogger(OnBoardingController.class);

	@GetMapping("/status/count")
	public ResponseEntity<?> onboardingStatusCount(@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate) throws IncorrectDateFormat {
		logger.info("inside onboardingStatusCount()");
		return mongoInterface.onboardingStatusCount(startDate, endDate);
	}

	@GetMapping("/count")
	public ResponseEntity<?> getOnboardingEmployeeCount(@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate) throws IncorrectDateFormat {
		logger.info("inside getOnboardingEmployeeCount()");
		return mongoInterface.getOnboardingEmployeeCount(startDate, endDate);
	}

	@GetMapping("/laptopByDm")
	public ResponseEntity<?> getCountOfLaptopByDm(@RequestParam("dmEmpId") int dmEmpId) throws DataNotFound {
		logger.info("inside getCountOfLaptopByDm()");
		return mongoInterface.getCountOfLaptopByDm(dmEmpId);
	}

	@GetMapping("/EmployeeDetailsbyDmEmpId")
	public ResponseEntity<?> getEmployeeDetails(@RequestParam("dmEmpId") int dmEmpId,
			@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate)
			throws IncorrectDateFormat {
		logger.info("inside getEmployeeDetails()");
		return mongoInterface.getEmployeeDetails(dmEmpId, startDate, endDate);
	}

	@GetMapping("/EmployeeDetails")
	public ResponseEntity<?> getEmployeeDetails(@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate) throws IncorrectDateFormat {
		logger.info("inside getEmployeeDetails()");
		return mongoInterface.getEmployeeDetails(startDate, endDate);
	}

	

	/*
	 * @GetMapping("/getCountOfLaptopByDmList") public ResponseEntity<?>
	 * getCountOfLaptopByDmList(@RequestParam("startDate") String startDate,
	 * 
	 * @RequestParam("endDate") String endDate) throws DataNotFound {
	 * logger.info("inside getCountOfLaptopByDm()"); return
	 * mongoInterface.getCountOfLaptopByDmList(startDate, endDate); }
	 */
}
