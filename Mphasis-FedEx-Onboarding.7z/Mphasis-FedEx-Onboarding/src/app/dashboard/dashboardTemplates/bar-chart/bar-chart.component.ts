import { Component, Input, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { DashboardService } from '../../dashboardServices/dashboard.service';
import { colors } from '../../dashboardUtilities/dashboardUtilities';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss'],
})
export class BarChartComponent implements OnInit {
  @Input() public barchart: any;

  fromDate = this.dashboardService.fromDate;
  toDate = this.dashboardService.toDate;

  constructor(private dashboardService: DashboardService) {}

  ngOnInit(): void {
    let grandtotal1 =
      this.barchart['Data privacy'].yes +
      this.barchart['Data privacy'].no +
      this.barchart['Data privacy'].inProgress;
    let grandtotal2 =
      this.barchart.ISMS.yes +
      this.barchart.ISMS.no +
      this.barchart.ISMS.inProgress;
    let data = [grandtotal1 + 5, grandtotal2 + 5];
    const myChart = new Chart('barChart', {
      type: 'bar',
      data: {
        labels: ['Data privacy', 'ISMS'],

        datasets: [
          {
            label: 'yes',
            data: [this.barchart['Data privacy'].yes, this.barchart.ISMS.yes],
            backgroundColor: colors.yes,
            // borderColor: '#002E94',
            borderWidth: 1,
          },
          {
            label: 'no',
            data: [this.barchart['Data privacy'].no, this.barchart.ISMS.no],
            backgroundColor: colors.no,
            // borderColor: '#FF731D',
            borderWidth: 1,
          },
          {
            label: 'inProgress',
            data: [
              this.barchart['Data privacy'].inProgress,
              this.barchart.ISMS.inProgress,
            ],
            backgroundColor: colors.inProgress,
            // borderColor: '#256D85',
            borderWidth: 1,
          },
          {
            label: 'GrandTotal',
            data: [grandtotal1, grandtotal2],
            backgroundColor: colors.total,
            // borderColor: '#256D85',
            borderWidth: 1,
          },
        ],
      },
      plugins: [ChartDataLabels],
      options: {
        plugins: {
          // title: {
          //   position: 'top',
          //   align: 'start',
          //   color: '#a4599a',
          //   display: true,
          //   text:"Mandatory Training Status",
          //   font: {
          //     size: 16,
          //     weight: 'bold',
          //   },
          //   padding: {
          //     top: 10,
          //     bottom: 30,
          //   },
          // },
          legend: {
            display: true,
            position: 'bottom',
            labels: {
              boxWidth: 20,
              boxHeight: 10,
            },
          },

          datalabels: {
            anchor: 'end',
            align: 'top',
            formatter: Math.round,
            font: {
              weight: 'bold',
            },
          },
          tooltip: {
            enabled: true,
          },
        },
        scales: {
          x: {
            ticks: {
              display: true,
            },
          },

          y: {
            ticks: {
              display: true,
            },
            beginAtZero: true,
          },
        },
      },
    });
  }
}
