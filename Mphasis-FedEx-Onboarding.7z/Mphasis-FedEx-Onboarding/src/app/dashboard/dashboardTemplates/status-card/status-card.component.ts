import {
  AfterViewInit,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnInit,
  Renderer2,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { ChartData } from 'chart.js';
import { CardData } from '../../dashboardInterfaces/CardData';

@Component({
  selector: 'app-status-card',
  templateUrl: './status-card.component.html',
  styleUrls: ['./status-card.component.scss'],
})
export class StatusCardComponent implements OnInit, AfterViewInit, OnChanges {
  @Input() cardData!: CardData;
  @Input() cardColor!: string;

  @ViewChild('myCard', { read: ElementRef }) card!: ElementRef;

  labels!: string[];
  values!: number[];
  title!: string;

  constructor(private renderer: Renderer2) {}

  ngAfterViewInit(): void {
    this.renderer.setStyle(
      this.card.nativeElement,
      'backgroundColor',
      this.cardColor
    );

    // this.renderer.setStyle()
  }

  titleCaseWord(word: string) {
    if (!word) return word;
    return word[0].toUpperCase() + word.substring(1).toLowerCase();
  }
  ngOnInit(): void {
    this.title = this.cardData.label;
    this.labels = Object.keys(this.cardData.data);
    this.values = Object.values(this.cardData.data);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.cardData) {
      this.labels = Object.keys(this.cardData.data);
      this.values = Object.values(this.cardData.data);
    }
  }
}
