import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { Table } from 'primeng/table';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import {
  DMYesNoNAWithLists,
  DMYesNoWithLists,
  EmployeeYesNoLists,
  EmployeeYesNoNALists,
} from '../../dashboardInterfaces/TableElements ';
import { DashboardService } from '../../dashboardServices/dashboard.service';

@Component({
  selector: 'app-new-table',
  templateUrl: './new-table.component.html',
  styleUrls: ['./new-table.component.scss'],
})
export class NewTableComponent implements OnInit, OnChanges {
  displayDialog: boolean = false;
  bloackScrollValue: boolean = true;

  selectedYesNoOption: any;
  selectedDmEmpNo!: number;
  selectedDmYesNoData!: EmployeeYesNoNALists | EmployeeYesNoLists;

  DMTableData!: (DMYesNoNAWithLists | DMYesNoWithLists)[];
  empTable: any[] = [];

  employeeMap = this.dashboardService.empMap;

  @ViewChild('dt') tableRef!: Table;

  @Input()
  yesNoOpts!: any;

  @Input()
  tableName!: String;

  @Input()
  DMTableDataHeaders!: IHeader[];

  @Input()
  DMDataMap = new Map<number, DMYesNoNAWithLists | DMYesNoWithLists>();

  @Input()
  empModalTableHeaders!: any;

  constructor(private dashboardService: DashboardService) {}
  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
    if (changes.DMDataMap) {
      this.DMTableData = Array.from(this.DMDataMap.values());
    }
  }

  ngOnInit(): void {
    this.DMTableData = Array.from(this.DMDataMap.values());
  }

  loadDmWiseEmpData(selectedDmId: any) {
    console.log(selectedDmId);
    this.selectedDmEmpNo = selectedDmId;

    let selectedRecord = this.DMDataMap.get(selectedDmId) as
      | DMYesNoNAWithLists
      | DMYesNoWithLists;

    console.log(selectedRecord);

    this.selectedDmYesNoData = selectedRecord.empList;

    this.displayDialog = !this.displayDialog;
    this.getEmpDataWithYesNoFilter();
  }

  getEmpDataWithYesNoFilter() {
    if (this.selectedYesNoOption == 'yesList') {
      this.empTable = this.selectedDmYesNoData?.yesList;
    } else if (this.selectedYesNoOption == 'noList') {
      this.empTable = this.selectedDmYesNoData?.noList;
    } else if (this.selectedYesNoOption == 'notApplicableList') {
      if (this.selectedDmYesNoData instanceof EmployeeYesNoNALists) {
        this.empTable = this.selectedDmYesNoData?.notApplicableList as any[];
        console.log(this.empTable);
      }
    }
  }

  applyFilter(event: any, field: any) {
    this.tableRef.filter(event.target.value, field, 'contains');
  }

  addFilter(value: string) {
    this.DMTableDataHeaders.filter((ele: any) => {
      if (ele.value == value) {
        ele.filter = !ele.filter;
        return;
      }
    });
  }

  getDmName(dmId: number) {
    return this.DMDataMap.get(dmId)?.dmName;
  }
}
