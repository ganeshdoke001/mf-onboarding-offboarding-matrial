import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DmWiseTableComponent } from './dm-wise-table.component';

describe('DmWiseTableComponent', () => {
  let component: DmWiseTableComponent;
  let fixture: ComponentFixture<DmWiseTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DmWiseTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DmWiseTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
