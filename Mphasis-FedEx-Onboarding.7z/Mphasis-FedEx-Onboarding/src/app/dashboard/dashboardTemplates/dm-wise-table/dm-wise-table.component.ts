import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { Table } from 'primeng/table';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import {
  DMYesNoNAWithLists,
  DMYesNoWithLists,
  EmployeeYesNoLists,
  EmployeeYesNoNALists,
} from '../../dashboardInterfaces/TableElements ';
import { DashboardService } from '../../dashboardServices/dashboard.service';
import { OffboardingService } from '../../dashboardServices/offboarding/offboarding.service';

@Component({
  selector: 'app-dm-wise-table',
  templateUrl: './dm-wise-table.component.html',
  styleUrls: ['./dm-wise-table.component.scss'],
})
export class DmWiseTableComponent implements OnInit, OnChanges {
  displayDialog: boolean = false;
  bloackScrollValue: boolean = true;

  
  selectedYesNoOption="noList";
  selectedDmEmpNo!: number;
  selectedDmYesNoData!: EmployeeYesNoNALists | EmployeeYesNoLists;

  DMTableData!: (DMYesNoNAWithLists | DMYesNoWithLists)[];
  empTable: any[] = [];

  employeeMap = this.dashboardService.empMap;

  @ViewChild('dt') dmTableRef!: Table;
  @ViewChild('et') EmpTableRef!: Table;

  @Input()
  yesNoOpts!: any;

  @Input()
  tableName!: String;

  @Input()
  DMTableDataHeaders!: IHeader[];

  @Input()
  DMDataMap = new Map<number, DMYesNoNAWithLists | DMYesNoWithLists>();

  @Input()
  empModalTableHeaders!: any;

  constructor(private dashboardService: OffboardingService) {}
  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
    if (changes.DMDataMap) {
      this.DMTableData = Array.from(this.DMDataMap.values());
    }
  }

  ngOnInit(): void {
    this.DMTableData = Array.from(this.DMDataMap.values());
  }

  loadDmWiseEmpData(selectedDmId: any) {
    console.log(selectedDmId);
    this.selectedDmEmpNo = selectedDmId;

    let selectedRecord = this.DMDataMap.get(selectedDmId) as
      | DMYesNoNAWithLists
      | DMYesNoWithLists;

    console.log(selectedRecord);

    this.selectedDmYesNoData = selectedRecord.empList;

    this.displayDialog = !this.displayDialog;
    this.getEmpDataWithYesNoFilter();
  }

  getEmpDataWithYesNoFilter() {
    if (this.selectedYesNoOption == 'yesList') {
      this.empTable = this.selectedDmYesNoData?.yesList;
    } else if (this.selectedYesNoOption == 'noList') {
      this.empTable = this.selectedDmYesNoData?.noList;
    } else if (this.selectedYesNoOption == 'notApplicableList') {
      if (this.selectedDmYesNoData instanceof EmployeeYesNoNALists) {
        this.empTable = this.selectedDmYesNoData?.notApplicableList as any[];
        console.log(this.empTable);
      }
    }
  }

  applyDmFilter(event: any, field: any) {
    this.dmTableRef.filter(event.target.value, field, 'contains');
  }

  applyEmpFilter(event: any, field: any) {
    this.EmpTableRef.filter(event.target.value, field, 'contains');
  }

  addDmFilter(value: string) {
    this.DMTableDataHeaders.filter((ele: any) => {
      if (ele.value == value) {
        ele.filter = !ele.filter;
        return;
      }
    });
  }

  addEmpFilter(value: string) {
    this.empModalTableHeaders.filter((ele: any) => {
      if (ele.value == value) {
        ele.filter = !ele.filter;
        return;
      }
    });
  }

  getDmName(dmId: number) {
    return this.DMDataMap.get(dmId)?.dmName;
  }
}
