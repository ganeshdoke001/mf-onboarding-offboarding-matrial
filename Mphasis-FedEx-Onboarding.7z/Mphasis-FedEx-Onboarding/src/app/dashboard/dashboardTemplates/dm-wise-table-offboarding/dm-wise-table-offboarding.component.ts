import { Component, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import { EmployeeYesNoNALists, EmployeeYesNoLists, DMYesNoNAWithLists, DMYesNoWithLists, DMYesNoWithListsOff, DMYesNoNAWithListOff } from '../../dashboardInterfaces/TableElements ';
import { OffboardingService } from '../../dashboardServices/offboarding/offboarding.service';
import { saveAs } from 'file-saver';


@Component({
  selector: 'app-dm-wise-table-offboarding',
  templateUrl: './dm-wise-table-offboarding.component.html',
  styleUrls: ['./dm-wise-table-offboarding.component.scss']
})
export class DmWiseTableOffboardingComponent implements OnInit {


  displayDialog: boolean = false;
  bloackScrollValue: boolean = true;

  selectedYesNoOption = "noList";
  selectedDmEmpNo!: number;
  selectedDmYesNoData!: EmployeeYesNoNALists | EmployeeYesNoLists;

  DMTableData!: (DMYesNoNAWithListOff | DMYesNoWithListsOff)[];
  empTable: any[] = [];

  employeeMap = this.dashboardService.empMap;

  @ViewChild('dt') dmTableRef!: Table;
  @ViewChild('et') EmpTableRef!: Table;

  @Input()
  yesNoOpts!: IHeader[];

  @Input()
  tableName!: string;

  @Input()
  DMTableDataHeaders!: IHeader[];

  @Input()
  DMDataMap = new Map<number, DMYesNoWithListsOff | DMYesNoNAWithListOff>();

  @Input()
  empModalTableHeaders!: any;
  excelData: any[] = [];

  constructor(private dashboardService: OffboardingService) { }
  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
    if (changes.DMDataMap) {
      this.DMTableData = Array.from(this.DMDataMap.values());
    }
  }

  ngOnInit(): void {
    this.DMTableData = Array.from(this.DMDataMap.values());
  }

  loadDmWiseEmpData(selectedDmId: any) {
    console.log(selectedDmId);
    this.selectedDmEmpNo = selectedDmId;

    let selectedRecord = this.DMDataMap.get(selectedDmId) as
      | DMYesNoWithListsOff


    console.log(selectedRecord);

    this.selectedDmYesNoData = selectedRecord.empList;

    this.displayDialog = !this.displayDialog;
    this.getEmpDataWithYesNoFilter();
  }

  getEmpDataWithYesNoFilter() {
    if (this.selectedYesNoOption == 'yesList') {
      this.empTable = this.selectedDmYesNoData?.yesList;
    } else if (this.selectedYesNoOption == 'noList') {
      this.empTable = this.selectedDmYesNoData?.noList;
    } else if (this.selectedYesNoOption == 'notApplicableList') {
      if (this.selectedDmYesNoData instanceof EmployeeYesNoNALists) {
        this.empTable = this.selectedDmYesNoData?.notApplicableList as any[];
        console.log(this.empTable);
      }
    }
  }

  exportExcel() {
    this.excelData = []; this.DMTableData.forEach((ele) => {
      if (ele.empList.noList.length > 0) this.excelData.push(...ele.empList.noList);
      if (ele.empList.yesList.length > 0) this.excelData.push(...ele.empList.yesList);

    });
    import('xlsx').then((xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet(this.excelData);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array', });
      this.saveAsExcelFile(excelBuffer, this.tableName);
    });
  } saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE, });
    saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }

  applyDmFilter(event: any, field: any) {
    this.dmTableRef.filter(event.target.value, field, 'contains');
  }

  applyEmpFilter(event: any, field: any) {
    this.EmpTableRef.filter(event.target.value, field, 'contains');
  }

  addDmFilter(value: string) {
    this.DMTableDataHeaders.filter((ele: any) => {
      if (ele.value == value) {
        ele.filter = !ele.filter;
        return;
      }
    });
  }

  addEmpFilter(value: string) {
    this.empModalTableHeaders.filter((ele: any) => {
      if (ele.value == value) {
        ele.filter = !ele.filter;
        return;
      }
    });
  }

  getDmName(dmId: number) {
    return this.DMDataMap.get(dmId)?.deliveryManagerName;
  }
}

