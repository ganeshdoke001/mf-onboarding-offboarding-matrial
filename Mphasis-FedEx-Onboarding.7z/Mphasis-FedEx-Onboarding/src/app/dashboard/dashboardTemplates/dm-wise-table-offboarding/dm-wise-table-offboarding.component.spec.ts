import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DmWiseTableOffboardingComponent } from './dm-wise-table-offboarding.component';

describe('DmWiseTableOffboardingComponent', () => {
  let component: DmWiseTableOffboardingComponent;
  let fixture: ComponentFixture<DmWiseTableOffboardingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DmWiseTableOffboardingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DmWiseTableOffboardingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
