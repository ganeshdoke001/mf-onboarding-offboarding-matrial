import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';

@Component({
  selector: 'app-attendance-bar',
  templateUrl: './attendance-bar.component.html',
  styleUrls: ['./attendance-bar.component.scss'],
})
export class AttendanceBarComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    const myChart = new Chart('attendance', {
      type: 'bar',

      data: {
        datasets: [
          {
            data: [50, 30, 20],
            backgroundColor: ['#4471c4','#ed7d31','#ffc000'],
            borderColor: ['#4471c4','#ed7d31','#ffc000'],
            borderWidth: 1,
          },
        ],
        labels: ['total', 'present', 'absent'],
      },
      plugins: [ChartDataLabels],

      options: {
        plugins: {
          title: {
            position: 'top',
            align: 'start',
            color: '#a4599a',
            display: true,
            text: 'Induction Programme Attendance - Weekly',
            font: {
              size: 16,
              weight: 'bold',
            },
            padding: {
              top: 10,
              bottom: 30,
            },
          },
         
          legend: {
            position: 'bottom',
            maxWidth: 50,
            labels: {
              // usePointStyle: true,
              boxHeight: 5,
              boxWidth: 16,
              font: {
                size: 14,
              },
            },
          },
          datalabels: {
            anchor: 'end',
            align: 'top',
            // formatter: Math.round,
            font: {
              size: 14,
            },
          },
          tooltip: {
            enabled: false,
          },
        },
        scales: {
          x: {
            grid: {
              display: false,
            },
            display: true,
            position: 'bottom',
            ticks: {
              includeBounds: true,
              autoSkip: false,
              maxRotation: 0,
              minRotation: 0,
              font: {
                size: 12,
                weight: 'bold',
              },
            },
          },
          y: {
            ticks: {
              font: {
                size: 12,
              },
            },
          },
        },
      },
    });
  }
}
