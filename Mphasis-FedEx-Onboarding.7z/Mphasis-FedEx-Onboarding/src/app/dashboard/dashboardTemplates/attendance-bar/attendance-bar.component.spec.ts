import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceBarComponent } from './attendance-bar.component';

describe('AttendanceBarComponent', () => {
  let component: AttendanceBarComponent;
  let fixture: ComponentFixture<AttendanceBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttendanceBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendanceBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
