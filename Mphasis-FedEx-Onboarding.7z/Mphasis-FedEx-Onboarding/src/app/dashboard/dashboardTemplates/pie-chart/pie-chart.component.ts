import { Component, OnInit } from '@angular/core';

import { Chart } from 'chart.js';
// import { Label, SingleDataSet } from 'ng2-charts';
import ChartDataLabels from 'chartjs-plugin-datalabels';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.scss'],
})
export class PieChartComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {
    const myChart = new Chart('pieChart', {
      type: 'pie',
      plugins: [ChartDataLabels],

      data: {
        labels: ['Less Than 30days', 'Between 30 and 45', 'More Than 60days'],

        datasets: [
          {
            label: 'My First Dataset',
            data: [40, 20, 30],
            backgroundColor: ['#b2ce76 ', '#f4e864', '#faa052 '],
          },
        ],
      },

      options: {
        responsive: true,
        aspectRatio: 1,
        plugins: {
          datalabels: {
            display: true,
            anchor: 'end',
            align: 'top',
            color: 'black',
            font: {
              weight: 400,
              size: 14,
            },
          },
          title: {
            display: true,
            text: 'WIP Timeline Category',
            font: {
              size: 17,
            },
          },

          legend: {
            align: 'center',
            display: true,
            position: 'bottom',
            labels: {
              usePointStyle: true,
              font: {
                size: 12,
              },
            },
          },
          tooltip: {
            enabled: true,
          },
        },
      },
    });
  }
}
