import {
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { Table } from 'primeng/table';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import { saveAs } from 'file-saver';
import {
  DMYesNoNAWithLists,
  DMYesNoWithLists,
  EmployeeYesNoNALists,
} from '../../dashboardInterfaces/TableElements ';

@Component({
  selector: 'app-basic-table',
  templateUrl: './basic-table.component.html',
  styleUrls: ['./basic-table.component.scss'],
})
export class BasicTableComponent implements OnInit {
  displayDialog: boolean = false;
  bloackScrollValue: boolean = true;
  lacus = 'sdfghj';
  cols!: any[];
  exportColumns!: any[];
  @ViewChild('dt') tableRef!: Table;

  @ViewChild('hoverBtn') hoverBtn!: ElementRef;

  @Input()
  showPopUp!: string;

  @Input()
  tableName!: String;

  @Input()
  tableHeaders!: IHeader[];

  @Input()
  tableData: any[] = [];

  @Input()
  showExport: boolean = false;

  hoverData: string =
    'WIP without FedExId : 28 WIP with FedExId:20              ';

  displayBasic: boolean = false;
  employeeDetails: any;
  constructor() { }


  getDetails(record: any, showPopUp: any) {
    this.employeeDetails = record;
    console.log(showPopUp);
    console.log(record);
    this.displayBasic = true;
  }
  mouseEnter() {
    console.log('mouseEnter', this.hoverBtn.nativeElement);
    this.hoverBtn.nativeElement.click();
  }

  mouseLeave() {
    this.hoverBtn.nativeElement.click();
  }

  ngOnInit(): void { }
  applyFilter(event: any, field: any) {
    this.tableRef.filter(event.target.value, field, 'contains');
  }
  showrecord(record: any) {
    console.log(record);
  }

  exportExcel() {
    import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.tableData);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: "xlsx",
        type: "array"
      });
      this.saveAsExcelFile(excelBuffer, "Table Data");
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
    let EXCEL_EXTENSION = ".xlsx";
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  }

  addFilter(value: string) {
    this.tableHeaders.filter((ele: any) => {
      if (ele.value == value) {
        ele.filter = !ele.filter;
        return;
      }
    });
  }
}
