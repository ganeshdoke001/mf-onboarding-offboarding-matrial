import {
  AfterViewInit,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { Observable } from 'rxjs';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { colors } from '../../dashboardUtilities/dashboardUtilities';
import { ChartElementData } from '../../dashboardInterfaces/ChartElementData';
import { ChartApiData } from '../../dashboardInterfaces/ChartApiData';
import { DashboardService } from '../../dashboardServices/dashboard.service';

Chart.register(...registerables);

@Component({
  selector: 'app-bar-line-chart',
  templateUrl: './bar-line-chart.component.html',
  styleUrls: ['./bar-line-chart.component.scss'],
})
export class BarLineChartComponent implements OnInit, AfterViewInit, OnChanges {
  @Input() public lineLabel!: string;
  @Input() public chartLable!: string;
  @Input() public headers: any;
  @Input() public apiData: ChartApiData[] = [];
  @Input() public aspectRatio: number = 1;

  chart!: Chart;
  labels: string[] = [];
  xAxis: any[] = [];
  chartData: ChartElementData[] = [];

  tempData: ChartApiData[] = [];
  lineData: ChartElementData = {
    label: '',
    data: [],
    order: 2,
    type: 'line',
    backgroundColor: colors.lineColor,
    borderColor: colors.lineColor,
  };

  fromDate = new Date(this.dashboardService.fromDate)
    .toUTCString()
    .slice(5, 16);

  toDate = new Date(this.dashboardService.toDate).toUTCString().slice(5, 16);

  @ViewChild('barLineChart') canvasRef!: ElementRef;

  constructor(private dashboardService: DashboardService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.apiData) {
      this.fillChartData();
    }
  }
  ngOnInit(): void {
    this.fillChartData();
    this.tempData.push(new ChartApiData());
  }

  ngAfterViewInit(): void {
    this.chartIt();
  }

  titleCaseWord(word: string) {
    if (!word) return word;
    return word[0].toUpperCase() + word.substring(1).toLowerCase();
  }

  chartIt() {
    var ctx = this.canvasRef.nativeElement.getContext('2d');
    this.chart = new Chart(ctx, {
      plugins: [ChartDataLabels],
      type: 'bar',
      data: {
        datasets: <any[]>this.chartData,
        labels: this.xAxis,
      },
      options: {
        maintainAspectRatio: true,
        aspectRatio: this.aspectRatio,
        plugins: {
          title: {
            position: 'top',
            align: 'center',
            color: '#a4599a',
            display: true,
            text: [this.chartLable, this.fromDate + ' to ' + this.toDate],

            font: {
              size: 16,
              weight: 'bold',
            },
            padding: {
              top: 10,
              bottom: 30,
            },
          },

          legend: {
            position: 'bottom',
            maxWidth: 50,
            labels: {
              // usePointStyle: true,
              boxHeight: 5,
              boxWidth: 16,
              font: {
                size: 14,
              },
            },
          },
          datalabels: {
            anchor: 'end',
            align: 'top',
            formatter: Math.round,
            font: {
              size: 14,
            },
          },
        },

        scales: {
          x: {
            grid: {
              display: false,
            },
            display: true,
            position: 'bottom',
            ticks: {
              includeBounds: true,
              autoSkip: false,
              maxRotation: 0,
              minRotation: 0,
              font: {
                size: 12,
                weight: 'bold',
              },
            },
          },
          y: {
            ticks: {
              font: {
                size: 12,
              },
            },
          },
        },
      },
    });
  }

  fillChartData() {
    this.labels = [];
    this.chartData = [];
    this.xAxis = [];
    if (this.headers) {
      this.headers.forEach((header: any) => {
        this.xAxis.push(header.viewValue.split('-'));
      });
    } else {
      this.apiData.forEach((obj) => this.xAxis.push(obj.label.split('-')));
    }
    this.labels = Object.keys(this.apiData[0].data);

    this.labels.forEach((label) => {
      let chartElement: ChartElementData = {
        label: '',
        data: [],
        order: 1,
        sum: 0,
        backgroundColor: '',
      };
      chartElement.label = label;
      chartElement.backgroundColor = colors[label];
      chartElement.data = this.apiData.map((ele) => (ele.data as any)[label]);
      this.chartData.push(chartElement);
    });

    if (this.lineLabel) {
      this.loadLineData();
    }
    this.chart?.update();
  }

  loadLineData() {
    let len = this.chartData[0].data.length;
    let elements = this.chartData.length;

    for (let i = 0; i < len; i++) {
      var sum = 0;
      for (let j = 0; j < elements; j++) {
        sum += this.chartData[j].data[i];
      }
      this.lineData.data.push(sum);
    }

    this.lineData.label = this.lineLabel;
    this.chartData.push(this.lineData);
  }
}
