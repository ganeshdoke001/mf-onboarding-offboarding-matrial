import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, NgControl } from '@angular/forms';

@Component({
  selector: 'app-custom-date-picker',
  templateUrl: './custom-date-picker.component.html',
  styleUrls: ['./custom-date-picker.component.scss'],
})
export class CustomDatePickerComponent implements OnInit {
  control: FormControl = new FormControl();
  year!: number;
  yearDefault = new Date().getFullYear();
  quarterDefault = 'Q' + (1 + Math.floor(new Date().getMonth() / 3));
  quarter: string | undefined;
  showQuarter: boolean = true;
  year10!: number;
  @ViewChild(NgControl, { static: false, read: ElementRef })
  controlID!: ElementRef;
  options: { value: string; months: string[] }[] = [
    { value: 'Q1', months: ['Jan ', 'Feb ', 'Mar'] },
    { value: 'Q2', months: ['Apr ', 'May ', 'Jun'] },
    { value: 'Q3', months: ['Jul ', 'Aug ', 'Sep'] },
    { value: 'Q4', months: ['Oct ', 'Nov ', 'Dec'] },
  ];

  minDate!: string;
  startDate: string = '2022-11-01';
  monthDate!: string;
  yearDate = this.yearDefault;
  todayDate = new Date().toISOString().slice(0, 10);
  endDate: string = new Date().toISOString().slice(0, 10);

  @Input()
  selectedFrequency="Yearly";

  @Input()
  dateFilter: string[] = ['Monthly', 'Quarterly', 'Yearly', 'Customize'];

  dashboardService: any;

  constructor() {}

  ngOnInit(): void {}
  selectDateRange() {
    console.log('demo');
    // Filter: string[] = [ 'Monthly','Quarterly', 'Yearly', 'Customize'];
    if (this.selectedFrequency == 'Quarterly') {
      let month = 0;
      if (this.quarter == 'Q1') {
        month = 0;
      } else if (this.quarter == 'Q2') {
        month = 3;
      } else if (this.quarter == 'Q3') {
        month = 6;
      } else {
        month = 9;
      }
      this.startDate = new Date(this.year, month, 2).toISOString().slice(0, 10);
      this.endDate = new Date(this.year, month + 3, 1)
        .toISOString()
        .slice(0, 10);
    } else if (this.selectedFrequency == 'Monthly') {
      this.startDate = new Date(this.monthDate).toISOString().slice(0, 10);
      console.log(this.startDate);

      this.endDate = new Date(
        new Date(this.monthDate).getFullYear(),
        new Date(this.monthDate).getMonth() + 1,
        1
      )
        .toISOString()
        .slice(0, 10);
      console.log(this.endDate);
    } else if (this.selectedFrequency == 'Yearly') {
      console.log('yearly');
      console.log([this.yearDate]);
      console.log(new Date(this.yearDate.toString()).getFullYear());
      this.startDate = new Date(
        new Date(this.yearDate.toString()).getFullYear() - 1,
        11,
        33
      )
        .toISOString()
        .slice(0, 10);
      console.log(this.startDate);
      this.endDate = new Date(
        new Date(this.yearDate.toString()).getFullYear(),
        11,
        32
      )
        .toISOString()
        .slice(0, 10);
      console.log(this.endDate);
    }

    this.dashboardService.fromDate = this.startDate;
    this.dashboardService.toDate = this.endDate;
  }
  getValuesOfMap(mapObj: Map<number, any>) {
    return Array.from(mapObj.values());
  }

  setStartAndEndDate() {
    let tempDate = this.startDate as unknown as Date;

    this.startDate = new Date(tempDate.getFullYear(), tempDate.getMonth(), 1)
      .toISOString()
      .slice(0, 10);

    console.log(this.startDate);
  }

  //quaterly
  changeYear(year: number) {
    this.year = year || this.yearDefault;
    this.quarter = this.quarter || this.quarterDefault;
    this.control.setValue(this.quarter + ' ' + this.year || this.yearDefault, {
      emitEvent: false,
    });
  }

  changeShowQuarter() {
    this.showQuarter = !this.showQuarter;
    if (!this.showQuarter)
      this.year10 = this.year
        ? 10 * Math.floor(this.year / 10)
        : 10 * Math.floor(this.yearDefault / 10);
  }

  selectQuarter(quarter: string, drop: { close: () => void }) {
    this.quarter = quarter;
    this.year = this.year || this.yearDefault;
    this.control.setValue(this.quarter + ' ' + this.year, { emitEvent: false });
    drop.close();
    this.selectDateRange();
  }
}
