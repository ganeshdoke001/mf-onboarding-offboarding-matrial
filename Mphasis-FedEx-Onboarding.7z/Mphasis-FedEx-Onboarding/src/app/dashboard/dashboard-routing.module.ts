import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { BgVerificationComponent } from './dashboardComponents/bg-verification/bg-verification.component';
import { InfoSecComponent } from './dashboardComponents/info-sec/info-sec.component';
import { OffboardingComponent } from './dashboardComponents/offboarding/offboarding.component';
import { OnboardingComponent } from './dashboardComponents/onboarding/onboarding.component';
import { MandatoryTrainingComponent } from './dashboardComponents/mandatory-training/mandatory-training.component';

const routes: Routes = [
  { path: '', redirectTo: 'onboarding', pathMatch: 'full' },
  { path: 'dash', component: DashboardComponent },
  { path: 'onboarding', component: OnboardingComponent },
  { path: 'offboarding', component: OffboardingComponent },
  { path: 'info-sec', component: InfoSecComponent },
  { path: 'bgv', component: BgVerificationComponent },
  {path: 'mandatory-training', component: MandatoryTrainingComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
