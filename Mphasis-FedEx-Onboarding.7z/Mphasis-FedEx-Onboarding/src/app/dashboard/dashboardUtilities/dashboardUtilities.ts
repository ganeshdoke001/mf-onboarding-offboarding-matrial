import { IHeader } from 'src/app/shared/shared-models/sharedModel';

export const colors: any = {
  lineColor: '#5b9bd4',
  Yes: ' #4471c4',
  No: '#ed7d31',
  InProgress: '#a4a4a4',
  NotApplicable: '#ffc000 ',
  Total: '#5b9bd4',
};

export const barLine: any = {
  fontSize: 8,
  titleColor: '#a4599a',
  colors: {
    lineColor: '#5b9bd4',
    Yes: ' #4471c4',
    No: '#ed7d31',
    InProgress: '#a4a4a4',
    NotApplicable: ' #ffc000 ',
  },
};

export const mandatoryDataHeaders: IHeader[] = [
  { value: 'empID', viewValue: 'Employee ID' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'pmName', viewValue: 'PM Name' },
  { value: 'dmName', viewValue: 'DM Name' },
  { value: 'email', viewValue: 'Email' },
  { value: 'theCodeOfBusinessConduct', viewValue: 'The Code Of Business Conduct' },
  { value: 'dataPrivacyGDPRCCPAawareness', viewValue: 'Data Privacy GDPR & CCPA Awareness' },
  { value: 'infromationSecurityManagementSystem', viewValue: 'Infromation Security Management System' },
  { value: 'mandatoryTrainingStatus', viewValue: 'Mandatory Training Status' },
];
export const OnboardingStatusHeaders: IHeader[] = [
  { value: 'ODCAccess', viewValue: 'ODC-Access' },
  { value: 'laptopAllocated', viewValue: 'Laptop-Allocated' },
  { value: 'accountInduction', viewValue: 'Account-Induction' },
  { value: 'ndaSigned', viewValue: 'NDA-Signed' },
  { value: 'wfhAttestation', viewValue: 'WFH-Attestation' },
];

export const YesNo: IHeader[] = [
  { value: 'yesList', viewValue: 'Yes' },
  { value: 'noList', viewValue: 'No' },
];

export const YesNoNA: IHeader[] = [
  { value: 'yesList', viewValue: 'Yes' },
  { value: 'noList', viewValue: 'No' },
  { value: 'notApplicableList', viewValue: 'NA' },
];

export const ProjectStatusHeaders: IHeader[] = [
  { value: 'dmEmpId', viewValue: 'DM Employee ID' },
  { value: 'dmName', viewValue: 'DM Name' },
  { value: 'inTransfer', viewValue: 'In-Transfer' },
  { value: 'newHire', viewValue: 'New Hire' },
  { value: 'outTransfer', viewValue: 'Out-Transfer' },
  { value: 'separated', viewValue: 'Separated' },
  { value: 'total', viewValue: 'Total' },
];

export const LaptopStatusHeaders: IHeader[] = [
  { value: 'dmEmpId', viewValue: 'DM Employee ID' },
  { value: 'dmName', viewValue: 'DM Name' },
  { value: 'yes', viewValue: 'Yes' },
  { value: 'no', viewValue: 'No' },
  // { value: 'notApplicable', viewValue: 'NA' },
  { value: 'total', viewValue: 'Total' },
];

export const LaptopModalHeaders: IHeader[] = [
  { value: 'empId', viewValue: 'Employee ID' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'gradeDesc', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'locationType', viewValue: 'Location Type' },
  { value: 'mphasisVPN', viewValue: 'Mphasis VPN' },
  { value: 'serialNumber', viewValue: 'Serial Number' },
  { value: 'hostName', viewValue: 'Host Name' },
  { value: 'pmName', viewValue: 'Project Manager' },
  { value: 'assignmentStartDate', viewValue: 'Assignment Start Date' },
];

export const NDAStatusHeaders: IHeader[] = [
  { value: 'dmEmpId', viewValue: 'DM Employee ID' },
  { value: 'dmName', viewValue: 'DM Name' },
  { value: 'yes', viewValue: 'Yes' },
  { value: 'no', viewValue: 'No' },
  { value: 'notApplicable', viewValue: 'NA' },
  { value: 'total', viewValue: 'Total' },
];

export const ODCModalHeaders: IHeader[] = [
  { value: 'empId', viewValue: 'Employee ID' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'gradeDesc', viewValue: 'Grade Desc' },
  //off-on
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'locationType', viewValue: 'Location Type' },

  { value: 'pmName', viewValue: 'Project Manager' },
  { value: 'assignmentStartDate', viewValue: 'Assignment Start Date' },
  { value: 'dateOfJoining', viewValue: 'Date Of Joining' },
];

export const AccountInductionModalHeaders: IHeader[] = [
  { value: 'empId', viewValue: 'Employee ID' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'gradeDesc', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'locationType', viewValue: 'Location Type' },

  { value: 'pmName', viewValue: 'Project Manager' },
  { value: 'assignmentStartDate', viewValue: 'Assignment Start Date' },
];

export const NDAModalHeaders: IHeader[] = [
  { value: 'empId', viewValue: 'Employee ID' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'gradeDesc', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'locationType', viewValue: 'Location Type' },

  { value: 'pmName', viewValue: 'Project Manager' },
  { value: 'assignmentStartDate', viewValue: 'Assignment Start Date' },
];

export const WFHModalHeaders: IHeader[] = [
  { value: 'empId', viewValue: 'Employee ID' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'gradeDesc', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'locationType', viewValue: 'Location Type' },

  { value: 'pmName', viewValue: 'Project Manager' },
  { value: 'assignmentStartDate', viewValue: 'Assignment Start Date' },
];

export const WFHStatusDataHeaders: IHeader[] = [
  { value: 'dmEmpId', viewValue: 'DM Employee ID' },
  { value: 'dmName', viewValue: 'DM Name' },
  { value: 'yes', viewValue: 'Yes' },
  { value: 'no', viewValue: 'No' },
  // { value: 'notApplicable', viewValue: 'NA' },
  { value: 'total', viewValue: 'Total' },
];

export const ODCStatusDataHeaders: IHeader[] = [
  { value: 'dmEmpId', viewValue: 'DM Employee ID' },
  { value: 'dmName', viewValue: 'DM Name' },
  { value: 'yes', viewValue: 'Yes' },
  { value: 'no', viewValue: 'No' },
  { value: 'notApplicable', viewValue: 'NA' },
  { value: 'total', viewValue: 'Total' },
];

export const InductionStatusDataHeaders: IHeader[] = [
  { value: 'dmEmpId', viewValue: 'DM Employee ID' },
  { value: 'dmName', viewValue: 'DM Name' },
  { value: 'yes', viewValue: 'Yes' },
  { value: 'no', viewValue: 'No' },
  { value: 'total', viewValue: 'Total' },
];

export const InformationSecurityDataHeaders: IHeader[] = [
  { value: 'empID', viewValue: 'Employee ID' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'email', viewValue: 'Email' },
  {
    value: 'attestationcompletionstatus',
    viewValue: 'Attestation Completion Status',
  },
];

export const ChartLableValues = [
  'Onboarding Status (New-Hire,In-Transfer)',
  'Account Transition Status',
  'Offboarding Status (Separated,Out-Transfered)',
  'Account Offboarding Status (Out-Transfered)',
  'Mphasis Offboarding Status (Absconded,Resigned & Terminated)',
];

export const OffboardingStatusHeaders: IHeader[] = [
  { value: 'FedExLDAPId', viewValue: 'FedEx-LDAP ID-De Activated' },
  { value: 'FedExEmailId', viewValue: 'FedEx-Email ID(OSV)-De Activated' },
  { value: 'MphasisVPN', viewValue: 'Mphasis VPN-De Activated' },
  { value: 'FedExMVOIP', viewValue: 'FedEx MVOIP-De Activated' },
  { value: 'FedExLaptop', viewValue: 'FedEx-Laptop-Received' },
  {
    value: 'AnyCustomersuppliedDevice',
    viewValue: 'Any Customer-supplied-Device Received',
  },
  { value: 'AccesstoFedExODC', viewValue: 'Access to-FedEx ODC-De Activated' },
  { value: 'MphasisEmailId', viewValue: 'Mphasis-Email ID-De Activated' },
  { value: 'MphasisUserId', viewValue: 'Mphasis-User ID-De Activated' },
  { value: 'MphasisLaptop', viewValue: 'Mphasis-Laptop-Handed Over' },
  { value: 'AccesstoMainGate', viewValue: 'Access to-Main Gate-De Activated' },
];

export const AccountoffboardingStatusHeaders: IHeader[] = [
  { value: 'FedExLDAPId', viewValue: 'FedEx-LDAP ID-De Activated' },
  { value: 'FedExEmailId', viewValue: 'FedEx-Email ID(OSV)-De Activated' },
  { value: 'FedExMVOIP', viewValue: 'FedEx MVOIP-De Activated' },
  { value: 'FedExLaptop', viewValue: 'FedEx-Laptop-Received' },
  {
    value: 'AnyCustomersuppliedDevice',
    viewValue: 'Any Customer-supplied-Device Received',
  },
  { value: 'AccesstoFedExODC', viewValue: 'Access to-FedEx ODC-De Activated' },
]

export const MphasisoffboardingStatusHeaders: IHeader[] = [
  { value: 'MphasisVPN', viewValue: 'Mphasis VPN-De Activated' },
  { value: 'AccesstoFedExODC', viewValue: 'Access to-FedEx ODC-De Activated' },
  { value: 'MphasisEmailId', viewValue: 'Mphasis-Email ID-De Activated' },
  { value: 'MphasisUserId', viewValue: 'Mphasis-User ID-De Activated' },
  { value: 'MphasisLaptop', viewValue: 'Mphasis-Laptop-Handed Over' },
  { value: 'AccesstoMainGate', viewValue: 'Access to-Main Gate-De Activated' },

]
export const OffboardingCategories: IHeader[] = [
  {
    viewValue: 'Out-Transfer',
    value: 'Out-Transfer',
  },
  {
    viewValue: 'Resigned',
    value: 'Separated_Resigned',
  },
  {
    viewValue: 'Terminated',
    value: 'Separated_Terminated',
  },
  {
    viewValue: 'Absconded',
    value: 'Separated_Absconded',
  },
  {
    viewValue: 'All',
    value: 'total',
  },
];

export const OnboardingCategories: IHeader[] = [
  {
    viewValue: 'in-transfer',
    value: 'In-Transfer',
  },
  {
    viewValue: 'new-hire',
    value: 'New Hire',
  },
  {
    viewValue: 'All',
    value: 'total',
  },
];

export const OffboardingTablesList: IHeader[] = [
  {
    id: 1,
    viewValue: 'FedEx LDAP ID De Activated',
    value: 'ldapDeActivated',
  },
  {
    id: 2,
    viewValue: 'FedEx Email ID(OSV) De Activated',
    value: 'emailDeActivated',
  },
  {
    id: 3,
    viewValue: 'Mphasis VPN De Activated',
    value: 'vpnDeActivated',
  },
  {
    id: 4,
    viewValue: 'FedEx MVOIP De Activated',
    value: 'mvoipDeActivated',
  },
  {
    id: 5,
    viewValue: 'FedEx Laptop Received',
    value: 'laptopReceived',
  },
  {
    id: 6,
    viewValue: 'Any Customer supplied Device Received',
    value: 'deviceRecevied',
  },
  {
    id: 7,
    viewValue: 'Access to FedEx ODC De Activated',
    value: 'odcDeActivated',
  },
  {
    id: 8,
    viewValue: 'Mphasis Email ID De Activated',
    value: 'mphasisEmailDeActivated',
  },
  {
    id: 9,
    viewValue: 'Mphasis User ID De Activated',
    value: 'userIdDeActivated',
  },
  {
    id: 10,
    viewValue: 'Mphasis Laptop Handed Over',
    value: 'laptopHandOver',
  },
  {
    id: 11,
    viewValue: 'Access to Main Gate De Activated',
    value: 'gateAccessDeActivated',
  },
];

export const OnboardingTablesList: IHeader[] = [
  {
    id: 1,
    viewValue: 'ODC Access Status',
    value: 'ODCAccessStatus',
  },
  {
    id: 2,
    viewValue: 'Laptop Status',
    value: 'laptopStatus',
  },
  {
    id: 3,
    viewValue: 'Account Induction Status',
    value: 'accountInductionStatus',
  },
  {
    id: 4,
    viewValue: 'NDA Status',
    value: 'NDAStatus',
  },
  {
    id: 5,
    viewValue: ' WFH Status',
    value: ' WFHStatus',
  },
];

export const BGVHeaders: IHeader[] = [
  {
    value: 'location',
    viewValue: 'Location',
    viewTittle: 'Location',
    rowSpan: 2,
  },
  {
    value: 'totalEmployees',
    viewValue: 'Total Employees',
    viewTittle: 'Total Employeesa',
    rowSpan: 1,
  },
  {
    value: 'green',
    viewValue: 'Green',
    viewTittle: 'Green',
    backgroundColor: '#7ba97b',
    rowSpan: 1,
  },
  {
    value: 'reinitiatedToGreen',
    viewValue: 'Green Reinitiated',
    viewTittle: 'Reinitiated to Green',
    backgroundColor: '#7ba97b',
    rowSpan: 1,
  },
  {
    value: 'redDeviation',
    viewValue: 'Red Deviation',
    viewTittle: 'Red Deviation',
    backgroundColor: '#e5b151',
    rowSpan: 1,
  },
  {
    value: 'bgvIncompleteEmployeesDOJBefore2010',
    viewValue: 'BGV Incomplete 2010',
    viewTittle: 'BGV Incomplete for the Employees joined before 2010',
    backgroundColor: '#e5b151',
    rowSpan: 1,
  },
  {
    value: 'WIP',
    viewValue: 'WIP',
    viewTittle: 'WIP',
    backgroundColor: '#e1e142',
    rowSpan: 1,
  },
  {
    value: 'red',
    viewValue: 'Red',
    viewTittle: 'Red',
    backgroundColor: ' #dd5858',
    rowSpan: 1,
  },
  {
    value: 'redReinitiated',
    viewValue: 'Red-Reinitiated',
    viewTittle: 'Red Reinitiated',
    backgroundColor: ' #dd5858',
    rowSpan: 1,
  },
  {
    value: 'bgvCompliant',
    viewValue: 'BGV%',
    viewTittle: 'BGV Compliant%',
    rowSpan: 1,
  },
];
export const FedExBGVDashbord: IHeader[] = [
  {
    value: 'dm',
    viewValue: 'DM',
    viewTittle: 'Category',
    rowSpan: 2,
  },
  {
    value: 'location',
    viewValue: 'Location',
    viewTittle: 'Location',
  },
  {
    value: 'totalEmployees',
    viewValue: 'Total Employees',
    viewTittle: 'Total Employees',
  },
  {
    value: 'green',
    viewValue: 'Green',
    viewTittle: 'Green',
  },
  {
    value: 'reinitiatedToGreen',
    viewValue: 'Reinitiated to Green',
    viewTittle: 'Reinitiated to Green',
  },
  {
    value: 'redDeviation',
    viewValue: 'Red Deviation',
    viewTittle: 'Red Deviation',
  },
  {
    value: 'WIP',
    viewValue: 'WIP',
    viewTittle: 'WIP',
  },
  {
    value: 'red',
    viewValue: 'Red',
    viewTittle: 'Red',
  },
  {
    value: 'redReinitiated',
    viewValue: 'Red Reinitiated',
    viewTittle: 'Red Reinitiated',
  },
  {
    value: 'bgvCompliant',
    viewValue: 'BGV%',
    viewTittle: 'BGV Compliant%',
  },
];

export const BGVNewHireHeaders: IHeader[] = [
  {
    value: 'employeeNumber',
    viewValue: 'Employee Number',
    viewTittle: 'Employee Number',
  },
  { value: 'fedEXId', viewValue: 'FedEX ID', viewTittle: 'FedEx ID' },
  {
    value: 'employeeName',
    viewValue: 'Employee Name',
    viewTittle: 'Employee Name',
  },
  { value: 'doj', viewValue: 'DOJ', viewTittle: 'Date Of Joining' },
  {
    value: 'posLocName',
    viewValue: 'Pos Loc Name',
    viewTittle: 'POS LOC NAME',
  },
  { value: 'location', viewValue: 'Location', viewTittle: 'Location' },
  { value: 'dm', viewValue: 'DM/CEM', viewTittle: 'DM/CEM' },
  { value: 'pm', viewValue: 'PM', viewTittle: 'PM' },
  { value: 'bgvStatus', viewValue: 'BGV Status', viewTittle: 'BGV Status' },
  { value: 'redReason', viewValue: 'Red Reason', viewTittle: 'Red Reason' },
  { value: 'bgvAging', viewValue: 'BGV Aging', viewTittle: 'BGV Aging' },
];

//** OffBoarding */
export const AccountOffboardingStatusHeaders: IHeader[] = [
  { value: 'deliveryManagerId', viewValue: 'DM Employee ID' },
  { value: 'deliveryManagerName', viewValue: 'DM Employee Name' },
  { value: 'yes', viewValue: 'Activated' },
  { value: 'no', viewValue: 'DeActivated' },
  { value: 'total', viewValue: 'Total' },
];

export const MphasisOffboradingStatusHeaders: IHeader[] = [
  { value: 'deliveryManagerId', viewValue: 'DM Employee ID' },
  { value: 'deliveryManagerName', viewValue: 'DM Employee Name' },
  { value: 'yes', viewValue: 'Activated' },
  { value: 'no', viewValue: 'DeActivated' },
  //{ value: 'notApplicable', viewValue: 'NA' },
  { value: 'total', viewValue: 'Total' },
];
export const LaptopoffStatusHeaders: IHeader[] = [
  { value: 'deliveryManagerId', viewValue: 'DM Employee ID' },
  { value: 'deliveryManagerName', viewValue: 'DM Employee Name' },
  { value: 'yes', viewValue: "Submitted" },
  { value: 'no', viewValue: "Not Submitted" },
  { value: 'total', viewValue: 'Total' },
];
export const YesNof: IHeader[] = [
  { value: 'yesList', viewValue: 'Activated' },
  { value: 'noList', viewValue: 'Deactivated' },
];
export const SubNotSub: IHeader[] = [
  { value: 'yesList', viewValue: "Submitted" },
  { value: 'noList', viewValue: "Not Submitted" },
];

export const YesNoNAof: IHeader[] = [
  { value: 'yesList', viewValue: 'yes' },
  { value: 'noList', viewValue: 'no' },
  { value: 'notApplicableList', viewValue: 'NA' },
];
export const FedExLDAPIdModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'userId', viewValue: 'FedExLDAPId' },
 
];

export const FedExEmailIdModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status'},
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'email', viewValue: 'FedEx Email Id' },
];

export const MphasisVPNModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status'},
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'vpn', viewValue: ' Mphasis VPN' },
];

export const FedExMVOIPModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'vpn', viewValue: 'FedEx MVOIP' },
];

export const FedExLaptopModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'fedExLaptop', viewValue: 'FedEx Laptop Submited' },
];

export const AnyCustomersuppliedDeviceModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'anyCustomersuppliedDevice', viewValue: 'AnyCustomer Supplied Device Submited' },
];

export const AccesstoFedExODCModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'accesstoFedExODC', viewValue: 'FedEx ODC Access' },
];

export const MphasisEmailIdModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: ' mphasisEmailId', viewValue: 'Mphasis Email Id' },
];

export const MphasisUserIdModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'mphasisUserId', viewValue: 'Mphasis UserId' },
];

export const MphasisLaptopModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },
  { value: 'mphasisLaptop', viewValue: 'Mphasis Laptop Submited' },
];

export const AccesstoMainGateModalHeaders: IHeader[] = [
  { value: 'employeeNumber', viewValue: 'Employee ID' },
  { value: 'employeeName', viewValue: 'Employee Name' },
  { value: 'gradeDescription', viewValue: 'Grade Desc' },
  { value: 'projectNumber', viewValue: 'Project Number' },
  { value: 'projectName', viewValue: 'Project Name' },
  { value: 'projectManagerName', viewValue: 'Project Manager Name' },
  { value: 'position', viewValue: 'Position' },
  { value: 'resourceAllocationStatus', viewValue: 'Resource Allocation Status' },
  { value: 'releaseDate', viewValue: 'ReleaseDate' },
  { value: 'offboardingStatus', viewValue: 'Offboarding Status' },
  { value: 'separationReason', viewValue: 'Separation Reason' },           
  { value: 'accesstoMainGate', viewValue: 'Access to Main Gate' },
];