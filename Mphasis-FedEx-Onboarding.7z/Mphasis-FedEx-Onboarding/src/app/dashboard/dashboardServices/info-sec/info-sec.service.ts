import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class InfoSecService {
  private _fromDate: string = '2022-01-01';
  private _toDate: string = new Date().toISOString().slice(0, 10);

  public get fromDate(): string {
    return this._fromDate;
  }

  public set fromDate(date: string) {
    this._fromDate = date;
  }

  public get toDate(): string {
    return this._toDate;
  }

  public set toDate(date: string) {
    this._toDate = date;
  }

  constructor() {}
}
