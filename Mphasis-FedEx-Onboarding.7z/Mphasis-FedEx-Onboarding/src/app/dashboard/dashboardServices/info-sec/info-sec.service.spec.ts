import { TestBed } from '@angular/core/testing';

import { InfoSecService } from './info-sec.service';

describe('InfoSecService', () => {
  let service: InfoSecService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InfoSecService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
