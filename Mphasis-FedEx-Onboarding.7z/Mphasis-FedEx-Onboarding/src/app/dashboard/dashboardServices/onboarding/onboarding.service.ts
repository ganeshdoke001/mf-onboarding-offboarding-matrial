import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CardData } from '../../dashboardInterfaces/CardData';
import {
  Employee,
  DMWiseOnboardingData,
  DMWiseEmployeeInductionStatus,
  DMWiseEmployeeLaptopStatus,
  DMWiseEmployeeNDAStatus,
  DMWiseEmployeeODCStatus,
  DMWiseEmployeeWFHStatus,
} from '../../dashboardInterfaces/TableElements ';

@Injectable({
  providedIn: 'root',
})
export class OnboardingService {
  constructor(private http: HttpClient) {}
  dmDataList: Employee[] = [];
  dmDataListOnboarding: Employee[] = [];
  dmDataListOffboarding: Employee[] = [];
  dmDataListTransition: Employee[] = [];

  private _fromDate: string = '2022-01-01';
  private _toDate: string = new Date().toISOString().slice(0, 10);

  empMap = new Map<number, Employee>();

  dmWiseLaptopMap = new Map<number, DMWiseEmployeeLaptopStatus>();
  dmWiseNdaMap = new Map<number, DMWiseEmployeeNDAStatus>();
  dmWiseWFHMap = new Map<number, DMWiseEmployeeWFHStatus>();
  dmWiseODCMap = new Map<number, DMWiseEmployeeODCStatus>();
  dmWiseInductionMap = new Map<number, DMWiseEmployeeInductionStatus>();

  dmDataMapOnboarding = new Map<number, DMWiseOnboardingData>();

  empData: any;
  jsonUrl = 'http://localhost:3000/';
  url = 'http://localhost:8083/';

  public get fromDate(): string {
    return this._fromDate;
  }

  public set fromDate(date: string) {
    this._fromDate = date;
  }

  public get toDate(): string {
    return this._toDate;
  }

  public set toDate(date: string) {
    this._toDate = date;
  }

  getOnboardingStatus(): Observable<any> {
    return this.http.get<any>(
      this.url +
        `onboardings/v1/status/count?startDate=${this._fromDate}&endDate=${this._toDate}`
    );
  }

  getOnboardingStatusCard(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'Onboarding-Status-card');
  }

  getAttendanceCard(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'Attendance-card');
  }

  getLDAPStatusCard(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'LDAP-Status-card');
  }

  getOnboardingCategories(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'Onboarding-Categories');
  }

  getOnboardingLocationType(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'locationTypeCount');
  }

  getOnboardingEmployeeCount(): Observable<any> {
    return this.http.get<any>(
      this.url +
        `onboardings/v1/count?startDate=${this._fromDate}&endDate=${this._toDate}`
    );
  }

  getTransitionEmployeeCount(): Observable<any> {
    return this.http.get<any>(
      this.url +
        `transition/v1/count?startDate=${this._fromDate}&endDate=${this._toDate}`
    );
  }
}
