import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class BgVerificationService {
  private _fromDate: string = '2022-01-01';
  private _toDate: string = new Date().toISOString().slice(0, 10);

  public get fromDate(): string {
    return this._fromDate;
  }

  public set fromDate(date: string) {
    this._fromDate = date;
  }

  public get toDate(): string {
    return this._toDate;
  }

  public set toDate(date: string) {
    this._toDate = date;
  }

  constructor(private http: HttpClient) {}

  getDashbordData() {
    return this.http.get<any>(
      'http://localhost:8082/api/v1/background-verification/analytics/dashboard?startDate=01/01/2000&endDate=30/01/2023'
    );
  }

  getEmployeeStatusData() {
    return this.http.get(
      'http://localhost:8082/api/v1/background-verification/getAll'
    );
  }

  getDMWiseData() {
    return this.http.get(
      'http://localhost:8082/api/v1/background-verification/analytics/dashboard/count/dm?startDate=1990-01-10&endDate=2023-01-11'
    );
  }
}
