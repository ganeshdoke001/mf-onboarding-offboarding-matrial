import { TestBed } from '@angular/core/testing';

import { BgVerificationService } from './bg-verification.service';

describe('BgVerificationService', () => {
  let service: BgVerificationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BgVerificationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
