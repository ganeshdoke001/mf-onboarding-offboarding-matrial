import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { forkJoin } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/operators';
import {
  DMWiseEmployeeProjectStatus,
  CardData,
} from '../dashboardInterfaces/CardData';
import { ChartApiData } from '../dashboardInterfaces/ChartApiData';
import {
  DMWiseEmployeeInductionStatus,
  DMWiseEmployeeLaptopStatus,
  DMWiseEmployeeNDAStatus,
  DMWiseEmployeeODCStatus,
  DMWiseEmployeeWFHStatus,
  DMWiseOnboardingData,
  Employee,
  IAccountInductionModal,
  ILaptopModal,
  INDAModal,
  IODCModal,
  IWFHModal,
  PMWiseCount,
} from '../dashboardInterfaces/TableElements ';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  constructor(private http: HttpClient) {}
  dmDataList: Employee[] = [];
  dmDataListOnboarding: Employee[] = [];
  dmDataListOffboarding: Employee[] = [];
  dmDataListTransition: Employee[] = [];

  private _fromDate: string = '2022-01-01';
  private _toDate: string = new Date().toISOString().slice(0, 10);

  empMap = new Map<number, Employee>();

  dmWiseProjectMap = new Map<number, DMWiseEmployeeProjectStatus>();
  dmWiseLaptopMap = new Map<number, DMWiseEmployeeLaptopStatus>();
  dmWiseNdaMap = new Map<number, DMWiseEmployeeNDAStatus>();
  dmWiseWFHMap = new Map<number, DMWiseEmployeeWFHStatus>();
  dmWiseODCMap = new Map<number, DMWiseEmployeeODCStatus>();
  dmWiseInductionMap = new Map<number, DMWiseEmployeeInductionStatus>();

  dmWiseNdaMapoff = new Map<number, DMWiseEmployeeNDAStatus>();
  dmWiseProjectMapoff = new Map<number, DMWiseEmployeeProjectStatus>();
  dmWiseLaptopMapoff = new Map<number, DMWiseEmployeeLaptopStatus>();
  dmWiseWFHMapoff = new Map<number, DMWiseEmployeeWFHStatus>();
  dmWiseODCMapoff = new Map<number, DMWiseEmployeeODCStatus>();
  dmWiseInductionMapoff = new Map<number, DMWiseEmployeeInductionStatus>();

  dmDataMapOnboarding = new Map<number, DMWiseOnboardingData>();
  dmDataMapOffboarding = new Map<number, DMWiseOnboardingData>();

  
  jsonUrl = 'http://localhost:3000/';
  urlOnboarding = 'http://localhost:8084/';
  urlOffboarding = 'http://localhost:8085/';

  public get fromDate(): string {
    return this._fromDate;
  }

  public set fromDate(date: string) {
    this._fromDate = date;
  }

  public get toDate(): string {
    return this._toDate;
  }

  public set toDate(date: string) {
    this._toDate = date;
  }

  getOnboardingStatus(): Observable<any> {
    // return this.http.get<any>(this.jsonUrl + 'Onboarding-Status');
    return this.http.get<any>(
      this.urlOnboarding +
        `onboardings/v1/status/count?startDate=${this._fromDate}&endDate=${this._toDate}`
    );
  }

  getOnboardingStatusCard(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'Onboarding-Status-card');
  }

  getOffboardingStatusCard(): Observable<CardData> {
    const newLocal = 'Offboarding-Status-card';
    return this.http.get<any>(this.jsonUrl + newLocal);
  }

  getAttendanceCard(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'Attendance-card');
  }

  getLDAPStatusCard(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'LDAP-Status-card');
  }

  getOnboardingCategories(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'Onboarding-Categories');
  }

  getOnboardingLocationType(): Observable<CardData> {
    return this.http.get<any>(this.jsonUrl + 'locationTypeCount');
  }

  getOnboardingEmployeeCount(): Observable<any> {
    return this.http.get<any>(
      this.urlOnboarding +
        `onboardings/v1/count?startDate=${this._fromDate}&endDate=${this._toDate}`
    );
  }
  getOffboardingStatus(category: string): Observable<any> {
    return this.http.get<any>(
      this.urlOffboarding +
        `api/v1/offboardings/analytics/dashboard/count?endDate=${this._toDate}&filter=${category}&startDate=${this._fromDate}`
    );
  }
  getOffboardingStatus1(): Observable<any> {
    return this.http.get<any>(this.jsonUrl + 'offboarding');
  }
  getOffboardingEmployeeCount(): Observable<any> {
    return this.http.get<any>(
      this.urlOnboarding +
        `offboardings/v1/count?startDate=${this._fromDate}&endDate=${this._toDate}`
    );
  }

  getTransitionEmployeeCount(): Observable<any> {
    return this.http.get<any>(
      this.urlOnboarding +
        `transition/v1/count?startDate=${this._fromDate}&endDate=${this._toDate}`
    );
  }

  getAllStatusesEmployee(): Observable<CardData> {
    let onboardingStatusCard: CardData;
    return forkJoin({
      onboarding: this.getOnboardingEmployeeCount(),
      offboarding: this.getOffboardingEmployeeCount(),
      transition: this.getTransitionEmployeeCount(),
    }).pipe(
      map((res) => {
        this.dmDataList = [];
        onboardingStatusCard = {
          label: 'Onboarding Status',
          data: {
            total:
              res['onboarding']['data']['count'] +
              res['offboarding']['data']['count'] +
              res['transition']['data']['count'],
            onboarding: res['onboarding']['data']['count'],
            offboarding: res['offboarding']['data']['count'],
            transition: res['transition']['data']['count'],
          },
        };

        this.dmDataListOnboarding = res['onboarding']['data']['empList'];
        this.dmDataListOffboarding = res['offboarding']['data']['empList'];
        this.dmDataListTransition = res['transition']['data']['empList'];

        this.dmDataList = this.dmDataList.concat(
          res['onboarding']['data']['empList'],
          res['offboarding']['data']['empList'],
          res['transition']['data']['empList']
        );

        // this.mapDMWiseData();

        this.setOnbOfbMap();
        this.setEmpMap();
        this.setLaptopMap();
        this.setNdaMap();
        this.setWFHMap();
        this.setODCMap();
        this.setInductionMap();

        this.setNdaMapoff();
        this.setLaptopMapoff();
        this.setODCMapoff();
        this.setWFHMapoff();
        this.setInductionMapoff();

        return onboardingStatusCard;
      })
    );
  }

  mapDMWiseData() {
    this.dmDataListOnboarding.forEach((ele) => {
      if (!this.dmDataMapOnboarding.has(ele.dmEmpId)) {
        this.dmDataMapOnboarding.set(ele.dmEmpId, new DMWiseOnboardingData());
      }

      let tempEle = this.dmDataMapOnboarding.get(
        ele.dmEmpId
      ) as DMWiseOnboardingData;

      //Laptop
      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.laptop.yes += 1;
        tempEle.laptop.empList.yesList.push(ele.empNumber);
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.laptop.no += 1;
        tempEle.laptop.empList.noList.push(ele.empNumber);
      }

      //NDA
      if (ele.accountOnboarding.accountNdaSigned == 'yes') {
        tempEle.nda.yes += 1;
        tempEle.nda.empList.yesList.push(ele.empNumber);
      } else if (ele.accountOnboarding.accountNdaSigned == 'no') {
        tempEle.nda.no += 1;
        tempEle.nda.empList.noList.push(ele.empNumber);
      } else if (ele.accountOnboarding.accountNdaSigned == 'NA') {
        tempEle.nda.notApplicable += 1;
        tempEle.nda.empList.notApplicableList?.push(ele.empNumber);
      }

      //ODC
      ele.mphasisOnBoarding.access.forEach((accessItem) => {
        if ((accessItem.accessName = 'ODC Access')) {
          if (accessItem.accessStatus == 'yes') {
            tempEle.odc.yes += 1;
            tempEle.odc.empList.yesList.push(ele.empNumber);
          } else if (accessItem.accessStatus == 'no') {
            tempEle.odc.no += 1;
            tempEle.odc.empList.noList.push(ele.empNumber);
          } else if (accessItem.accessStatus == 'NA') {
            tempEle.odc.notApplicable += 1;
            tempEle.odc.empList.notApplicableList?.push(ele.empNumber);
          }
        }
      });

      //Account Onboarding
      if (ele.accountOnboarding.accountInduction == 'yes') {
        tempEle.accountInduction.yes += 1;
        tempEle.accountInduction.empList.yesList.push(ele.empNumber);
      } else if (ele.accountOnboarding.accountInduction == 'no') {
        tempEle.accountInduction.no += 1;
        tempEle.accountInduction.empList.noList.push(ele.empNumber);
      }

      //WFH
      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.wfh.yes += 1;
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.wfh.no += 1;
      }

      tempEle.total += 1;
      this.dmDataMapOnboarding.set(ele.dmEmpId, tempEle);
    });

    // console.log(this.dmDataMapOnboarding);

    this.dmDataListOffboarding.forEach((ele) => {
      if (!this.dmDataMapOffboarding.has(ele.dmEmpId)) {
        this.dmDataMapOffboarding.set(ele.dmEmpId, new DMWiseOnboardingData());
      }

      let tempEle = this.dmDataMapOffboarding.get(
        ele.dmEmpId
      ) as DMWiseOnboardingData;

      //Laptop
      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.laptop.yes += 1;
        tempEle.laptop.empList.yesList.push(ele.empNumber);
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.laptop.no += 1;
        tempEle.laptop.empList.noList.push(ele.empNumber);
      }

      //NDA
      if (ele.accountOnboarding.accountNdaSigned == 'yes') {
        tempEle.nda.yes += 1;
        tempEle.nda.empList.yesList.push(ele.empNumber);
      } else if (ele.accountOnboarding.accountNdaSigned == 'no') {
        tempEle.nda.no += 1;
        tempEle.nda.empList.noList.push(ele.empNumber);
      } else if (ele.accountOnboarding.accountNdaSigned == 'NA') {
        tempEle.nda.notApplicable += 1;
        tempEle.nda.empList.notApplicableList?.push(ele.empNumber);
      }

      //ODC
      ele.mphasisOnBoarding.access.forEach((accessItem) => {
        if ((accessItem.accessName = 'ODC Access')) {
          if (accessItem.accessStatus == 'yes') {
            tempEle.odc.yes += 1;
            tempEle.odc.empList.yesList.push(ele.empNumber);
          } else if (accessItem.accessStatus == 'no') {
            tempEle.odc.no += 1;
            tempEle.odc.empList.noList.push(ele.empNumber);
          } else if (accessItem.accessStatus == 'NA') {
            tempEle.odc.notApplicable += 1;
            tempEle.odc.empList.notApplicableList?.push(ele.empNumber);
          }
        }
      });

      //Account Onboarding
      if (ele.accountOnboarding.accountInduction == 'yes') {
        tempEle.accountInduction.yes += 1;
        tempEle.accountInduction.empList.yesList.push(ele.empNumber);
      } else if (ele.accountOnboarding.accountInduction == 'no') {
        tempEle.accountInduction.no += 1;
        tempEle.accountInduction.empList.noList.push(ele.empNumber);
      }

      //WFH
      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.wfh.yes += 1;
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.wfh.no += 1;
      }

      tempEle.total += 1;
      this.dmDataMapOnboarding.set(ele.dmEmpId, tempEle);
      console.log(this.dmDataMapOnboarding);
      
    });
  }

  setOnbOfbMap() {
    this.dmWiseProjectMap.clear();
    this.dmDataList.forEach((ele) => {
      if (!this.dmWiseProjectMap.has(ele.dmEmpId)) {
        this.dmWiseProjectMap.set(
          ele.dmEmpId,
          new DMWiseEmployeeProjectStatus(ele.dmEmpId, ele.dmName)
        );
      }

      let tempEle = this.dmWiseProjectMap.get(
        ele.dmEmpId
      ) as DMWiseEmployeeProjectStatus;

      if (ele.transitionType == 'Seperated') {
        tempEle.separated += 1;
      } else if (ele.transitionType == 'Out-Transfer') {
        tempEle.outTransfer += 1;
      } else if (ele.transitionType == 'New Hire') {
        tempEle.newHire += 1;
      } else if (ele.transitionType == 'In-Transfer') {
        tempEle.inTransfer += 1;
      }

      tempEle.total += 1;
      tempEle.empId.push(ele.empNumber);
      this.dmWiseProjectMap.set(ele.dmEmpId, tempEle);
    });
  }

  setEmpMap() {
    this.empMap.clear();
    this.dmDataList.forEach((ele) => {
      if (!this.empMap.has(ele.empNumber)) {
        this.empMap.set(ele.empNumber, ele);
      }
    });
  }

  setLaptopMap() {
    this.dmWiseLaptopMap.clear();
    this.dmDataListOnboarding.forEach((ele) => {
      if (!this.dmWiseLaptopMap.has(ele.dmEmpId)) {
        this.dmWiseLaptopMap.set(
          ele.dmEmpId,
          new DMWiseEmployeeLaptopStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseLaptopMap.get(
        ele.dmEmpId
      ) as DMWiseEmployeeLaptopStatus;

      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.yes += 1;
        let obj: ILaptopModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,

          mphasisVPN: ele.mphasisOnBoarding.mphasisVpnActivated,
          laptopStatus: ele.mphasisOnBoarding.laptop.status,
          serialNumber: ele.mphasisOnBoarding.laptop.serialNumber,

          hostName: ele.mphasisOnBoarding.laptop.hostName,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.no += 1;
        let obj: ILaptopModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,

          mphasisVPN: ele.mphasisOnBoarding.mphasisVpnActivated,
          laptopStatus: ele.mphasisOnBoarding.laptop.status,
          serialNumber: null,
          hostName: 'NA',
        };
        tempEle.empList.noList.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseLaptopMap.set(ele.dmEmpId, tempEle);
    });
  }

  setNdaMap() {
    this.dmWiseNdaMap.clear();
    this.dmDataListOnboarding.forEach((ele) => {
      if (!this.dmWiseNdaMap.has(ele.dmEmpId)) {
        this.dmWiseNdaMap.set(
          ele.dmEmpId,
          new DMWiseEmployeeNDAStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseNdaMap.get(
        ele.dmEmpId
      ) as DMWiseEmployeeNDAStatus;

      if (ele.accountOnboarding.accountNdaSigned == 'yes') {
        tempEle.yes += 1;
        let obj: INDAModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.accountOnboarding.accountNdaSigned == 'no') {
        tempEle.no += 1;
        let obj: INDAModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,
        };
        tempEle.empList.noList.push(obj);
      } else if (ele.accountOnboarding.accountNdaSigned == 'NA') {
        tempEle.notApplicable += 1;
        let obj: INDAModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,
        };
        tempEle.empList.notApplicableList?.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseNdaMap.set(ele.dmEmpId, tempEle);
    });

    console.log(this.dmWiseNdaMap);
  }

  setWFHMap() {
    this.dmWiseWFHMap.clear();
    this.dmDataListOnboarding.forEach((ele) => {
      if (!this.dmWiseWFHMap.has(ele.dmEmpId)) {
        this.dmWiseWFHMap.set(
          ele.dmEmpId,
          new DMWiseEmployeeWFHStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseWFHMap.get(
        ele.dmEmpId
      ) as DMWiseEmployeeWFHStatus;

      if (!tempEle.pmList.has(ele.pmEmpId)) {
        let PMObj = new PMWiseCount(ele.pmName);
        tempEle.pmList.set(ele.pmEmpId, PMObj);
      } else {
        let tempPmWiseCount = tempEle.pmList.get(ele.pmEmpId) as PMWiseCount;
        tempPmWiseCount.count += 1;
        tempEle.pmList.set(ele.pmEmpId, tempPmWiseCount);
      }

      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.yes += 1;
        let obj: IWFHModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          // pmEmpId: ele.pmEmpId,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.no += 1;
        let obj: IWFHModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          // pmEmpId: ele.pmEmpId,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,
        };
        tempEle.empList.noList.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseWFHMap.set(ele.dmEmpId, tempEle);
    });

    console.log(this.dmWiseWFHMap);
  }

  setODCMap() {
    this.dmWiseODCMap.clear();
    this.dmDataListOnboarding.forEach((ele) => {
      if (!this.dmWiseODCMap.has(ele.dmEmpId)) {
        this.dmWiseODCMap.set(
          ele.dmEmpId,
          new DMWiseEmployeeODCStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseODCMap.get(
        ele.dmEmpId
      ) as DMWiseEmployeeODCStatus;

      ele.mphasisOnBoarding.access.forEach((accessItem) => {
        if ((accessItem.accessName = 'ODC Access')) {
          if (accessItem.accessStatus == 'yes') {
            tempEle.yes += 1;
            let obj: IODCModal = {
              empId: ele.empNumber,
              empName: ele.empName,
              gradeDesc: ele.gradeDesc,
              projectName: ele.projectName,
              pmName: ele.pmName,
              assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
              locationType: ele.locationPosition,

              dateOfJoining: ele.dateOfJoining,
              projectNumber: ele.projectNumber,
            };
            tempEle.empList.yesList.push(obj);
          } else if (accessItem.accessStatus == 'no') {
            tempEle.no += 1;
            let obj: IODCModal = {
              empId: ele.empNumber,
              empName: ele.empName,
              gradeDesc: ele.gradeDesc,
              projectName: ele.projectName,
              pmName: ele.pmName,
              assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
              locationType: ele.locationPosition,

              dateOfJoining: ele.dateOfJoining,
              projectNumber: ele.projectNumber,
            };
            tempEle.empList.noList.push(obj);
          } else if (accessItem.accessStatus == 'NA') {
            tempEle.notApplicable += 1;
            let obj: IODCModal = {
              empId: ele.empNumber,
              empName: ele.empName,
              gradeDesc: ele.gradeDesc,
              projectName: ele.projectName,
              pmName: ele.pmName,
              assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
              locationType: ele.locationPosition,

              dateOfJoining: ele.dateOfJoining,
              projectNumber: ele.projectNumber,
            };
            tempEle.empList.notApplicableList?.push(obj);
          }
        }
      });

      tempEle.total += 1;
      this.dmWiseODCMap.set(ele.dmEmpId, tempEle);
    });
  }

  setInductionMap() {
    this.dmWiseInductionMap.clear();
    this.dmDataListOnboarding.forEach((ele) => {
      if (!this.dmWiseInductionMap.has(ele.dmEmpId)) {
        this.dmWiseInductionMap.set(
          ele.dmEmpId,
          new DMWiseEmployeeInductionStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseInductionMap.get(
        ele.dmEmpId
      ) as DMWiseEmployeeInductionStatus;

      if (ele.accountOnboarding.accountInduction == 'yes') {
        tempEle.yes += 1;
        let obj: IAccountInductionModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.accountOnboarding.accountInduction == 'no') {
        tempEle.no += 1;
        let obj: IAccountInductionModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          projectNumber: ele.projectNumber,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          locationType: ele.locationPosition,
        };
        tempEle.empList.noList.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseInductionMap.set(ele.dmEmpId, tempEle);
    });
  }

  setNdaMapoff() {
    this.dmWiseNdaMapoff.clear();
    this.dmDataListOffboarding.forEach((ele) => {
      if (!this.dmWiseNdaMapoff.has(ele.dmEmpId)) {
        this.dmWiseNdaMapoff.set(
          ele.dmEmpId,
          new DMWiseEmployeeNDAStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseNdaMapoff.get(
        ele.dmEmpId
      ) as DMWiseEmployeeNDAStatus;

      if (ele.accountOnboarding.accountNdaSigned == 'yes') {
        tempEle.yes += 1;
        let obj: INDAModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.accountOnboarding.accountNdaSigned == 'no') {
        tempEle.no += 1;
        let obj: INDAModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.noList.push(obj);
      } else if (ele.accountOnboarding.accountNdaSigned == 'NA') {
        tempEle.notApplicable += 1;
        let obj: INDAModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.notApplicableList?.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseNdaMapoff.set(ele.dmEmpId, tempEle);
    });
    console.log(this.dmWiseNdaMapoff);
  }
  setLaptopMapoff() {
    this.dmWiseLaptopMapoff.clear();
    this.dmDataListOffboarding.forEach((ele) => {
      if (!this.dmWiseLaptopMapoff.has(ele.dmEmpId)) {
        this.dmWiseLaptopMapoff.set(
          ele.dmEmpId,
          new DMWiseEmployeeLaptopStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseLaptopMapoff.get(
        ele.dmEmpId
      ) as DMWiseEmployeeLaptopStatus;

      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.yes += 1;
        let obj: ILaptopModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,

          mphasisVPN: ele.mphasisOnBoarding.mphasisVpnActivated,
          laptopStatus: ele.mphasisOnBoarding.laptop.status,
          serialNumber: ele.mphasisOnBoarding.laptop.serialNumber,

          hostName: ele.mphasisOnBoarding.laptop.hostName,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.no += 1;
        let obj: ILaptopModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,

          mphasisVPN: ele.mphasisOnBoarding.mphasisVpnActivated,
          laptopStatus: ele.mphasisOnBoarding.laptop.status,
          serialNumber: null,
          hostName: 'NA',
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.noList.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseLaptopMapoff.set(ele.dmEmpId, tempEle);
    });
    console.log(this.dmWiseLaptopMapoff);
  }

  setODCMapoff() {
    this.dmWiseODCMapoff.clear();
    this.dmDataListOffboarding.forEach((ele) => {
      if (!this.dmWiseODCMapoff.has(ele.dmEmpId)) {
        this.dmWiseODCMapoff.set(
          ele.dmEmpId,
          new DMWiseEmployeeODCStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseODCMapoff.get(
        ele.dmEmpId
      ) as DMWiseEmployeeODCStatus;

      ele.mphasisOnBoarding.access.forEach((accessItem) => {
        if ((accessItem.accessName = 'ODC Access')) {
          if (accessItem.accessStatus == 'yes') {
            tempEle.yes += 1;
            let obj: IODCModal = {
              empId: ele.empNumber,
              empName: ele.empName,
              gradeDesc: ele.gradeDesc,
              projectName: ele.projectName,
              pmName: ele.pmName,
              assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,

              dateOfJoining: ele.dateOfJoining,
              projectNumber: ele.projectNumber,
              locationType: ele.locationPosition,
            };
            tempEle.empList.yesList.push(obj);
          } else if (accessItem.accessStatus == 'no') {
            tempEle.no += 1;
            let obj: IODCModal = {
              empId: ele.empNumber,
              empName: ele.empName,
              gradeDesc: ele.gradeDesc,
              projectName: ele.projectName,
              pmName: ele.pmName,
              assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,

              dateOfJoining: ele.dateOfJoining,
              projectNumber: ele.projectNumber,
              locationType: ele.locationPosition,
            };
            tempEle.empList.noList.push(obj);
          } else if (accessItem.accessStatus == 'NA') {
            tempEle.notApplicable += 1;
            let obj: IODCModal = {
              empId: ele.empNumber,
              empName: ele.empName,
              gradeDesc: ele.gradeDesc,
              projectName: ele.projectName,
              pmName: ele.pmName,
              assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,

              dateOfJoining: ele.dateOfJoining,
              projectNumber: ele.projectNumber,
              locationType: ele.locationPosition,
            };
            tempEle.empList.notApplicableList?.push(obj);
          }
        }
      });

      tempEle.total += 1;
      this.dmWiseODCMapoff.set(ele.dmEmpId, tempEle);
    });
    console.log(this.dmWiseODCMapoff);
  }

  setInductionMapoff() {
    this.dmWiseInductionMapoff.clear();
    this.dmDataListOffboarding.forEach((ele) => {
      if (!this.dmWiseInductionMapoff.has(ele.dmEmpId)) {
        this.dmWiseInductionMapoff.set(
          ele.dmEmpId,
          new DMWiseEmployeeInductionStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseInductionMapoff.get(
        ele.dmEmpId
      ) as DMWiseEmployeeInductionStatus;

      if (ele.accountOnboarding.accountInduction == 'yes') {
        tempEle.yes += 1;
        let obj: IAccountInductionModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.accountOnboarding.accountInduction == 'no') {
        tempEle.no += 1;
        let obj: IAccountInductionModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.noList.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseInductionMapoff.set(ele.dmEmpId, tempEle);
    });
    console.log(this.dmWiseInductionMapoff);
  }

  setWFHMapoff() {
    this.dmWiseWFHMapoff.clear();
    this.dmDataListOffboarding.forEach((ele) => {
      if (!this.dmWiseWFHMapoff.has(ele.dmEmpId)) {
        this.dmWiseWFHMapoff.set(
          ele.dmEmpId,
          new DMWiseEmployeeWFHStatus({
            dmEmpId: ele.dmEmpId,
            dmName: ele.dmName,
          })
        );
      }

      let tempEle = this.dmWiseWFHMapoff.get(
        ele.dmEmpId
      ) as DMWiseEmployeeWFHStatus;

      if (ele.mphasisOnBoarding.laptop.status == 'yes') {
        tempEle.yes += 1;
        let obj: IWFHModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.yesList.push(obj);
      } else if (ele.mphasisOnBoarding.laptop.status == 'no') {
        tempEle.no += 1;
        let obj: IWFHModal = {
          empId: ele.empNumber,
          empName: ele.empName,
          gradeDesc: ele.gradeDesc,
          projectName: ele.projectName,
          pmName: ele.pmName,
          assignmentStartDate: ele.mphasisOnBoarding.assignmentStartDate,
          projectNumber: ele.projectNumber,
          locationType: ele.locationPosition,
        };
        tempEle.empList.noList.push(obj);
      }

      tempEle.total += 1;
      this.dmWiseWFHMapoff.set(ele.dmEmpId, tempEle);
    });
    console.log(this.dmWiseWFHMapoff);
  }
}

export interface ReportsServiceInterface {
  getOnboardingStatus(): Observable<any[]>;
  getaccountTransactionStatus(): Observable<any[]>;
}
