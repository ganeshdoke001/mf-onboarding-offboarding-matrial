import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DMWiseEmployeeAccesstoFedExODC, DMWiseEmployeeAccesstoMainGate, DMWiseEmployeeAnyCustomersuppliedDevice, DMWiseEmployeeFedExEmailId, DMWiseEmployeeFedExLaptop, DMWiseEmployeeFedExLDAPId, DMWiseEmployeeFedExMVOIP, DMWiseEmployeeMphasisEmailId, DMWiseEmployeeMphasisLaptop, DMWiseEmployeeMphasisUserId, DMWiseEmployeeMphasisVPN, DMWiseOnboardingData, DmEmpList, Employee, EmployeeDetails, Emplist, FedExData, MphasisData, OffboardingDetails, DMWiseOffboardingData, ILaptopModal, FedExLDAPIdModel, FedExEmailIdModel, MphasisVPNModel, FedExMVOIPModel, FedExLaptopModel, AnyCustomersuppliedDeviceModel, AccesstoFedExODCModel, MphasisEmailIdModel, MphasisUserIdModel, MphasisLaptopModel, AccesstoMainGateModel } from '../../dashboardInterfaces/TableElements ';
import { DatePipe } from '@angular/common';


@Injectable({
  providedIn: 'root',
})
export class OffboardingService {
  offBoardingData: [] = [];

  employeeDetails: EmployeeDetails[] = [];
  offboardingDetails: OffboardingDetails[] = [];
  dmEmpList: DmEmpList[] = [];
  fedExData: FedExData[] = [];
  mphasisData: MphasisData[] = [];
  dmDataSatus: any;
  status="offboarding";
  dmId=0;
  filter="total";


  dmDataOffboarding = new Map<number, Emplist[]>();
  dmDataEmployee = new Map<number, DmEmpList[]>();
  empMap = new Map<number, Emplist>();


  dMWiseFedExLDAPId = new Map<number, DMWiseEmployeeFedExLDAPId>();
  dMWiseFedExEmailId = new Map<number, DMWiseEmployeeFedExEmailId>();
  dMWiseMphasisVPN = new Map<number, DMWiseEmployeeMphasisVPN>();
  dMWiseFedExMVOIP = new Map<number, DMWiseEmployeeFedExMVOIP>();
  dMWiseFedExLaptop = new Map<number, DMWiseEmployeeFedExLaptop>();
  dMWiseAnyCustomersuppliedDevice = new Map<number, DMWiseEmployeeAnyCustomersuppliedDevice>();
  dMWiseAccesstoFedExODC = new Map<number, DMWiseEmployeeAccesstoFedExODC>();
  dMWiseMphasisEmailId = new Map<number, DMWiseEmployeeMphasisEmailId>();
  dMWiseMphasisUserId = new Map<number, DMWiseEmployeeMphasisUserId>();
  dMWiseMphasisLaptop = new Map<number, DMWiseEmployeeMphasisLaptop>();
  dMWiseAccesstoMainGate = new Map<number, DMWiseEmployeeAccesstoMainGate>();

  dmDataMapOffboarding = new Map<number, DMWiseOffboardingData>();

  private _fromDate: string = '2022-01-01';
  private _toDate: string = new Date().toISOString().slice(0, 10);



  constructor(private http: HttpClient,public datepipe: DatePipe) { }
  urlOffboarding = 'http://localhost:8085/';
  jsonUrlo = 'http://localhost:3001/';



  public get fromDate(): string {
    return this._fromDate;
  }

  public set fromDate(date: string) {
    this._fromDate = date;
  }

  public get toDate(): string {
    return this._toDate;
  }

  public set toDate(date: string) {
    this._toDate = date;
  }
  getOffboardingStatus(category: string): Observable<any> {
    return this.http.get<any>(
      this.urlOffboarding +
      `api/v1/offboardings/analytics/dashboard/count?endDate=${this._toDate}&filter=${category}&startDate=${this._fromDate}`
    );
  }

  getOffboardingData(): Observable<any> {
    return this.http.get<any>(this.jsonUrlo + 'data');
  }
  getOffboardingEmployee(category:string): Observable<any> {
    return this.http.get<any>(this.urlOffboarding+`api/v1/offboardings/employeeOffboardingSummary/0?Status=${this.status}&endDate=${this._toDate}&filter=${category}&startDate=${this._fromDate}`);
  }


  getAllStatusesEmployeeOffboarding(category:string): Observable<any> {
    let offbordedData: any;
    let dmdataSatus: any
    let dataof:any
    return forkJoin({
      offbordedData: this.getOffboardingData(),
      dmdataSatus: this.getOffboardingStatus(category),
      dataof:this.getOffboardingEmployee(category)
    }).pipe(
      map((res => {
        console.log(res['offbordedData']);
        console.log(res['dmdataSatus']);
        console.log(res['dataof'][1]['EmployeeDetails']['data']);
        console.log(res['dataof'][2]['OffboardingDetails']['data']);
        this.dmDataSatus;
        // this.employeeDetails = res['offbordedData']['EmployeeDetails'];
        // this.offboardingDetails = res['offbordedData']['OffboardingDetails'];
        this.employeeDetails=res['dataof'][1]['EmployeeDetails']['data'];
        this.offboardingDetails=res['dataof'][2]['OffboardingDetails']['data'];
        console.log(this.employeeDetails);
        console.log(this.offboardingDetails);


        this.mapDMWiseData();
        this.setEmpMap();
        this.setFedExLDAPIdMap();
        this.setFedExEmailIdMap();
        this.setMphasisVPNMap();
        this.setFedExMVOIPMap();
        this.setFedExLaptopMap();
        this.setAnyCustomersuppliedDeviceMap();
        this.setAccesstoFedExODCMap();
        this.setMphasisEmailIdMap();
        this.setMphasisUserIdMap();
        this.setMphasisLaptopMap();
        this.setAccesstoMainGateMap();
      }))
    )

  }

  mapDMWiseData() {

    this.employeeDetails.forEach(e => {
      if (!this.dmDataOffboarding.has(e.DeliveryManagerId)) {
        this.dmDataOffboarding.set(e.DeliveryManagerId, e.Emplist);
      }
    })
    console.log(this.dmDataOffboarding);

    this.offboardingDetails.forEach(e => {
      if (!this.dmDataEmployee.has(e.DeliveryManagerId)) {
        this.dmDataEmployee.set(e.DeliveryManagerId, e.DmEmpList);
      }
    })

    console.log(this.dmDataEmployee);

    this.offboardingDetails.forEach(ele => {
      if (!this.dmDataMapOffboarding.has(ele.DeliveryManagerId)) {
        this.dmDataMapOffboarding.set(ele.DeliveryManagerId, new DMWiseOffboardingData());
      }

      let tempEle = this.dmDataMapOffboarding.get(
        ele.DeliveryManagerId
      ) as DMWiseOffboardingData;

      if (!this.dmDataMapOffboarding.has(ele.DeliveryManagerId)) {
        ele.DmEmpList.forEach(e => {
          e.fedExData.forEach(e1 => {
            console.log(e1);

            if (!this.dmDataMapOffboarding.has(e1.deliveryManagerId)) {
              //*FedExLDAPId
              if (e1.userId == 'Activated') {
                tempEle.fedExLDAPId.yes += 1;
                tempEle.fedExLDAPId.empList.yesList.push(e1.employeeNumber);
              }
              else if (e1.userId == 'Deactivated') {
                tempEle.fedExLDAPId.no += 1;
                tempEle.fedExLDAPId.empList.noList.push(e1.employeeNumber)
              }
              //*FedExEmailId
              if (e1.email == 'Activated') {
                tempEle.fedExEmailId.yes += 1;
                tempEle.fedExEmailId.empList.yesList.push(e1.employeeNumber);
              }
              else if (e1.email == 'Deactivated') {
                tempEle.fedExEmailId.no += 1;
                tempEle.fedExEmailId.empList.noList.push(e1.employeeNumber)
              }
              //* FedExMVOIP
              if (e1.vpn == 'Activated') {
                tempEle.fedExMVOIP.yes += 1;
                tempEle.fedExMVOIP.empList.yesList.push(e1.employeeNumber);
              }
              else if (e1.vpn == 'Deactivated') {
                tempEle.fedExMVOIP.no += 1;
                tempEle.fedExMVOIP.empList.noList.push(e1.employeeNumber)
              }

              e1.assets.forEach(e2 => {
                //* FedExLaptop
                if (e2.assetName == "FedEx Laptop") {
                  if (e2.assetStatus == 'Submitted') {
                    tempEle.fedExLaptop.yes += 1;
                    tempEle.fedExLaptop.empList.yesList.push(e1.employeeNumber);
                  } else if (e2.assetStatus == 'Not Submitted') {
                    tempEle.fedExLaptop.no += 1;
                    tempEle.fedExLaptop.empList.yesList.push(e1.employeeNumber);
                  }
                }
                //* AnyCustomersuppliedDevice
                if (e2.assetName == "CustomerSuppliedDevice") {
                  if (e2.assetStatus == 'Submitted') {
                    tempEle.anyCustomersuppliedDevice.yes += 1;
                    tempEle.anyCustomersuppliedDevice.empList.yesList.push(e1.employeeNumber);
                  } else if (e2.assetStatus == 'Not Submitted') {
                    tempEle.anyCustomersuppliedDevice.no += 1;
                    tempEle.anyCustomersuppliedDevice.empList.yesList.push(e1.employeeNumber);
                  }
                }
              })

              // //*AccesstoFedExODC
              if (e1.access.accessStatus == 'Activated') {
                tempEle.accesstoFedExODC.yes += 1;
                tempEle.accesstoFedExODC.empList.yesList.push(e1.employeeNumber);
              }
              else if (e1.access.accessStatus == 'Deactivated') {
                tempEle.accesstoFedExODC.no += 1;
                tempEle.accesstoFedExODC.empList.noList.push(e1.employeeNumber)
              }

            }
          })

          // MphasisOffBoarding
          e.mphasisData.forEach(e1 => {

            //* MphasisVPN
            if (e1.vpn == 'Activated') {
              tempEle.mphasisVPN.yes += 1;
              tempEle.mphasisVPN.empList.yesList.push(e1.employeeNumber);
            }
            else if (e1.vpn == 'Deactivated') {
              tempEle.mphasisVPN.no += 1;
              tempEle.mphasisVPN.empList.noList.push(e1.employeeNumber)
            }

            //*MphasisEmailId
            if (e1.email == 'Activated') {
              tempEle.mphasisEmailId.yes += 1;
              tempEle.mphasisEmailId.empList.yesList.push(e1.employeeNumber);
            }
            else if (e1.email == 'Deactivated') {
              tempEle.mphasisEmailId.no += 1;
              tempEle.mphasisEmailId.empList.noList.push(e1.employeeNumber)
            }

            //*MphasisUserId
            if (e1.userId == 'Activated') {
              tempEle.mphasisUserId.yes += 1;
              tempEle.mphasisUserId.empList.yesList.push(e1.employeeNumber);
            }
            else if (e1.userId == 'Deactivated') {
              tempEle.mphasisUserId.no += 1;
              tempEle.mphasisUserId.empList.noList.push(e1.employeeNumber)
            }

            e1.assets.forEach(e2 => {

              //*MphasisLaptop
              if (e2.assetName == "Mphasis Laptop") {
                if (e2.assetStatus == 'Submitted') {
                  tempEle.mphasisLaptop.yes += 1;
                  tempEle.mphasisLaptop.empList.yesList.push(e1.employeeNumber);
                } else if (e2.assetStatus == 'Not Submitted') {
                  tempEle.mphasisLaptop.no += 1;
                  tempEle.mphasisLaptop.empList.yesList.push(e1.employeeNumber);
                }
              }
            })

            //*AccesstoMainGate
            if (e1.access.accessStatus == 'Activated') {
              tempEle.accesstoMainGate.yes += 1;
              tempEle.accesstoMainGate.empList.yesList.push(e1.employeeNumber);
            }
            else if (e1.access.accessStatus == 'Deactivated') {
              tempEle.accesstoMainGate.no += 1;
              tempEle.accesstoMainGate.empList.noList.push(e1.employeeNumber)
            }
          })
          tempEle.total += 1;
          this.dmDataMapOffboarding.set(ele.DeliveryManagerId, tempEle);
        })
      }
    })
    console.log(this.dmDataMapOffboarding);
  }

  setEmpMap() {
    this.empMap.clear();
    // this.dmDataOffboarding.forEach((ele) => {
    //   if (!this.empMap.has(ele.employeeNumber)) {
    //     this.empMap.set(ele.employeeNumber, ele);
    //   }
    // });
    // console.log(this.empMap);
  }

  //* FedExLDAPId
  setFedExLDAPIdMap() {
    let ldapId = '';
    let reason = '';
    this.dMWiseFedExLDAPId.clear();

    this.dmDataOffboarding.forEach((ed) => {
      if (ed != null)
        ed.forEach(ele => {
          if (!this.dMWiseFedExLDAPId.has(ele.deliveryManagerId)) {
            this.dMWiseFedExLDAPId.set(
              ele.deliveryManagerId,
              new DMWiseEmployeeFedExLDAPId({
                deliveryManagerId: ele.deliveryManagerId,
                deliveryManagerName: ele.deliveryManagerName,
              })
            );
          }

          let tempEle = this.dMWiseFedExLDAPId.get(
            ele.deliveryManagerId
          ) as DMWiseEmployeeFedExLDAPId;


          this.offboardingDetails.forEach(o => {
            if (this.dMWiseFedExLDAPId.has(o.DeliveryManagerId))
              o.DmEmpList.forEach(e => {
                if(e.employeeNumber==ele.employeeNumber)
                e.fedExData.forEach(e1 => {
                  ldapId = e1.userId;
                  reason = e1.separationReason;

                  if (ldapId == "Activated") {
                    tempEle.yes += 1;
                    let obj: FedExLDAPIdModel = {
                      employeeNumber: ele.employeeNumber,
                      employeeName: ele.employeeName,
                      dateOfJoining: ele.dateOfJoining,
                      transition: ele.transition,
                      workLocation: ele.workLocation,
                      position: ele.position,
                      gradeDescription: ele.gradeDescription,
                      employeeCategory: ele.employeeCategory,
                      projectManagerId: ele.projectManagerId,
                      projectManagerName: ele.projectManagerName,
                      projectManagerContact: ele.projectManagerContact,
                      deliveryManagerId: ele.deliveryManagerId,
                      deliveryManagerName: ele.deliveryManagerName,
                      projectNumber: ele.projectNumber,
                      projectName: ele.projectName,
                      resourceAllocationStatus: ele.resourceAllocationStatus,
                     // releaseDate: this.datepipe.transform(ele.releaseDate, 'dd/MM/yyyy'),
                      releaseDate: ele.releaseDate.toString().slice(0,10) ,
                      offboardingStatus: ele.offboardingStatus,
                      userId: ldapId,
                      separationReason: reason,
                    };
                    tempEle.empList.yesList.push(obj);
                    tempEle.total += 1;
                  } else if (ldapId == "Deactivated") {
                    tempEle.no += 1;
                    let obj: FedExLDAPIdModel = {
                      employeeNumber: ele.employeeNumber,
                      employeeName: ele.employeeName,
                      dateOfJoining: ele.dateOfJoining,
                      transition: ele.transition,
                      workLocation: ele.workLocation,
                      position: ele.position,
                      gradeDescription: ele.gradeDescription,
                      employeeCategory: ele.employeeCategory,
                      projectManagerId: ele.projectManagerId,
                      projectManagerName: ele.projectManagerName,
                      projectManagerContact: ele.projectManagerContact,
                      deliveryManagerId: ele.deliveryManagerId,
                      deliveryManagerName: ele.deliveryManagerName,
                      projectNumber: ele.projectNumber,
                      projectName: ele.projectName,
                      resourceAllocationStatus: ele.resourceAllocationStatus,
                      releaseDate: ele.releaseDate.toString().slice(0,10) ,
                      offboardingStatus: ele.offboardingStatus,
                      userId: ldapId,
                      separationReason: reason,
                    };
                    tempEle.empList.noList.push(obj);
                    tempEle.total += 1;
                  }
                })
              })
          })
         
          this.dMWiseFedExLDAPId.set(ele.deliveryManagerId, tempEle);
          console.log(this.dMWiseFedExLDAPId);
        })

    })


  }

  //*FedExEmailId
  setFedExEmailIdMap() {
    let mail = '';
    let reason = '';
    this.dMWiseFedExEmailId.clear();

    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseFedExEmailId.has(ele.deliveryManagerId)) {
          this.dMWiseFedExEmailId.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeFedExEmailId({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseFedExEmailId.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeFedExEmailId;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseFedExEmailId.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e0 => {
              if(e0.employeeNumber == ele.employeeNumber)
              e0.fedExData.forEach(e1 => {
                mail = e1.email;
                reason = e1.separationReason;

                if (e1.email == "Activated") {
                  tempEle.yes += 1;
                  let obj: FedExEmailIdModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    email: e1.email,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (e1.email == "Deactivated") {
                  tempEle.no += 1;
                  let obj: FedExEmailIdModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    email: e1.email,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }

              })
            })
        })
console.log(tempEle);

        this.dMWiseFedExEmailId.set(ele.deliveryManagerId,tempEle);
      })
    })
    console.log(this.dMWiseFedExEmailId);
  }


  //* MphasisVPN
  setMphasisVPNMap() {
    let vpn = '';
    let reason = '';
    this.dMWiseMphasisVPN.clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseMphasisVPN.has(ele.deliveryManagerId)) {
          this.dMWiseMphasisVPN.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeMphasisVPN({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseMphasisVPN.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeMphasisVPN;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseFedExEmailId.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.mphasisData.forEach(e1 => {
                vpn = e1.vpn;
                reason = e1.separationReason;

                if (vpn == 'Activated') {
                  tempEle.yes += 1;
                  let obj: MphasisVPNModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    vpn: vpn,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (vpn == 'Deactivated') {
                  tempEle.no += 1;
                  let obj: MphasisVPNModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    vpn: vpn,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }

              })
            })
        })
       
        this.dMWiseMphasisVPN.set(ele.deliveryManagerId, tempEle);
      })

    });
    console.log(this.dMWiseMphasisVPN);

  }


  //* FedExMVOIP
  setFedExMVOIPMap() {
    let vpn = '';
    let reason = '';
    this.dMWiseFedExMVOIP.clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseFedExMVOIP.has(ele.deliveryManagerId)) {
          this.dMWiseFedExMVOIP.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeFedExMVOIP({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseFedExMVOIP.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeFedExMVOIP;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseFedExMVOIP.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.fedExData.forEach(e1 => {
                vpn = e1.vpn;
                reason = e1.separationReason;


                if (vpn == 'Activated') {
                  tempEle.yes += 1;
                  let obj: FedExMVOIPModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    vpn: vpn,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (vpn == 'Deactivated') {
                  tempEle.no += 1;
                  let obj: FedExMVOIPModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    vpn: vpn,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }


              })
            })
        })
        
        this.dMWiseFedExMVOIP.set(ele.deliveryManagerId, tempEle);
      })
    });
    console.log(this.dMWiseFedExMVOIP);

  }


  //*FedExLaptop

  setFedExLaptopMap() {
    let assetsStatus = '';
    let reason = '';
    this.dMWiseFedExLaptop.clear();

    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseFedExLaptop.has(ele.deliveryManagerId)) {
          this.dMWiseFedExLaptop.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeFedExLaptop({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseFedExLaptop.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeFedExLaptop;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseFedExLaptop.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.fedExData.forEach(e1 => {

                reason = e1.separationReason;
                e1.assets.forEach(a => {
                  if (a.assetName == "FedEx Laptop")
                    assetsStatus = a.assetStatus;
                })


                if (assetsStatus == "Submitted") {
                  tempEle.yes += 1;
                  let obj: FedExLaptopModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    fedExLaptop: assetsStatus,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (assetsStatus == "Not Submitted") {
                  tempEle.no += 1;
                  let obj: FedExLaptopModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    fedExLaptop: assetsStatus,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }


              })
            })
        })
       
        this.dMWiseFedExLaptop.set(ele.deliveryManagerId, tempEle);
      })
    });
    console.log(this.dMWiseFedExLaptop);

  }

  //*AnyCustomersuppliedDevice
  setAnyCustomersuppliedDeviceMap() {
    let assetsStatus = '';
    let reason = '';
    this.dMWiseAnyCustomersuppliedDevice.clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseAnyCustomersuppliedDevice.has(ele.deliveryManagerId)) {
          this.dMWiseAnyCustomersuppliedDevice.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeAnyCustomersuppliedDevice({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseAnyCustomersuppliedDevice.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeAnyCustomersuppliedDevice;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseAnyCustomersuppliedDevice.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.fedExData.forEach(e1 => {
                reason = e1.separationReason;
                e1.assets.forEach(a => {
                  if (a.assetName == "CustomerSuppliedDevice")
                    assetsStatus = a.assetStatus;
                })


                if (assetsStatus == "Submitted") {
                  tempEle.yes += 1;
                  let obj: AnyCustomersuppliedDeviceModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    anyCustomersuppliedDevice: assetsStatus,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (assetsStatus == "Not Submitted") {
                  tempEle.no += 1;
                  let obj: AnyCustomersuppliedDeviceModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    anyCustomersuppliedDevice: assetsStatus,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }

               
              })
            })
        })
       
        this.dMWiseAnyCustomersuppliedDevice.set(ele.deliveryManagerId, tempEle);
      })
    });
    console.log(this.dMWiseAnyCustomersuppliedDevice);

  }

  //* AccesstoFedExODC
  setAccesstoFedExODCMap() {
    let accesstoFedExODC = '';
    let reason = '';
    this.dMWiseAccesstoFedExODC.clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseAccesstoFedExODC.has(ele.deliveryManagerId)) {
          this.dMWiseAccesstoFedExODC.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeAccesstoFedExODC({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseAccesstoFedExODC.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeAccesstoFedExODC;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseAccesstoFedExODC.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.fedExData.forEach(e1 => {
                reason = e1.separationReason;
                accesstoFedExODC = e1.access.accessStatus;


                if (accesstoFedExODC == 'Activated') {
                  tempEle.yes += 1;
                  let obj: AccesstoFedExODCModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    accesstoFedExODC: accesstoFedExODC,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (accesstoFedExODC == 'Deactivated') {
                  tempEle.no += 1;
                  let obj: AccesstoFedExODCModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    accesstoFedExODC: accesstoFedExODC,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }


              })
            })
        })
        
        this.dMWiseAccesstoFedExODC.set(ele.deliveryManagerId, tempEle);
      })
    });
    console.log(this.dMWiseAccesstoFedExODC);

  }

  //* MphasisEmailId
  setMphasisEmailIdMap() {
    let mail = '';
    let reason = '';
    this.dMWiseMphasisEmailId.clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseMphasisEmailId.has(ele.deliveryManagerId)) {
          this.dMWiseMphasisEmailId.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeMphasisEmailId({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseMphasisEmailId.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeMphasisEmailId;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseMphasisEmailId.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.mphasisData.forEach(e1 => {
                reason = e1.separationReason;
                mail = e1.email;


                if (mail == 'Activated') {
                  tempEle.yes += 1;
                  let obj: MphasisEmailIdModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    mphasisEmailId: mail,

                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (mail == 'Deactivated') {
                  tempEle.no += 1;
                  let obj: MphasisEmailIdModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    mphasisEmailId: mail,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }

              })
            })
        })
        
        this.dMWiseMphasisEmailId.set(ele.deliveryManagerId, tempEle);
      })
    });
    console.log(this.dMWiseMphasisEmailId);

  }

  //* MphasisUserId
  setMphasisUserIdMap() {
    let userIdMaphasis = '';
    let reason = '';
    this.dMWiseMphasisUserId.clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseMphasisUserId.has(ele.deliveryManagerId)) {
          this.dMWiseMphasisUserId.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeMphasisUserId({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseMphasisUserId.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeMphasisUserId;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseMphasisUserId.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber == ele.employeeNumber)
              e.mphasisData.forEach(e1 => {
                reason = e1.separationReason;
                userIdMaphasis= e1.userId;
              
                if (e1.userId== "Activated") {
                  tempEle.yes += 1;
                  let obj: MphasisUserIdModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    mphasisUserId:e1.userId,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (e1.userId== "Deactivated") {
                  tempEle.no += 1;
                  let obj: MphasisUserIdModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    mphasisUserId: e1.userId,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }
            })
          })
        })
       
        this.dMWiseMphasisUserId.set(ele.deliveryManagerId,tempEle);
        
      })
    })
   console.log(this.dMWiseMphasisUserId);
   
  }

  //* MphasisLaptop
  setMphasisLaptopMap() {
    let mphasisLaptop = '';
    let reason = '';
    this.dMWiseMphasisLaptop .clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseMphasisLaptop.has(ele.deliveryManagerId)) {
          this.dMWiseMphasisLaptop.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeMphasisLaptop({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }
        let tempEle = this.dMWiseMphasisLaptop.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeMphasisLaptop;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseMphasisLaptop.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.mphasisData.forEach(e1 => {
                reason = e1.separationReason;
                e1.assets.forEach(e2 => {
                  if (e2.assetName == "Mphasis Laptop")
                    mphasisLaptop = e2.assetStatus;
                })


                if (mphasisLaptop == "Submitted") {
                  tempEle.yes += 1;
                  let obj: MphasisLaptopModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    mphasisLaptop: mphasisLaptop,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (mphasisLaptop == "Not Submitted") {
                  tempEle.no += 1;
                  let obj: MphasisLaptopModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    mphasisLaptop: mphasisLaptop,
                    separationReason: reason,
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }

              })
            })
        })
       
        this.dMWiseMphasisLaptop.set(ele.deliveryManagerId, tempEle);
      })
    });
    console.log(this.dMWiseMphasisLaptop);
  }

  //* AccesstoMainGate
  setAccesstoMainGateMap() {
    let accesstoMainGate = '';
    let reason = '';
    this.dMWiseAccesstoMainGate.clear();
    this.dmDataOffboarding.forEach((e) => {
      e.forEach(ele => {
        if (!this.dMWiseAccesstoMainGate.has(ele.deliveryManagerId)) {
          this.dMWiseAccesstoMainGate.set(
            ele.deliveryManagerId,
            new DMWiseEmployeeAccesstoMainGate({
              deliveryManagerId: ele.deliveryManagerId,
              deliveryManagerName: ele.deliveryManagerName,
            })
          );
        }

        let tempEle = this.dMWiseAccesstoMainGate.get(
          ele.deliveryManagerId
        ) as DMWiseEmployeeAccesstoMainGate;

        this.offboardingDetails.forEach(o => {
          if (this.dMWiseAccesstoMainGate.has(o.DeliveryManagerId))
            o.DmEmpList.forEach(e => {
              if(e.employeeNumber==ele.employeeNumber)
              e.mphasisData.forEach(e1 => {
                reason = e1.separationReason;
                accesstoMainGate = e1.access.accessStatus;

                if (accesstoMainGate == "Activated") {
                  tempEle.yes += 1;
                  let obj: AccesstoMainGateModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    accesstoMainGate: accesstoMainGate,
                    separationReason: reason
                  };
                  tempEle.empList.yesList.push(obj);
                  tempEle.total += 1;
                } else if (accesstoMainGate == "Deactivated") {
                  tempEle.no += 1;
                  let obj: AccesstoMainGateModel = {
                    employeeNumber: ele.employeeNumber,
                    employeeName: ele.employeeName,
                    dateOfJoining: ele.dateOfJoining,
                    transition: ele.transition,
                    workLocation: ele.workLocation,
                    position: ele.position,
                    gradeDescription: ele.gradeDescription,
                    employeeCategory: ele.employeeCategory,
                    projectManagerId: ele.projectManagerId,
                    projectManagerName: ele.projectManagerName,
                    projectManagerContact: ele.projectManagerContact,
                    deliveryManagerId: ele.deliveryManagerId,
                    deliveryManagerName: ele.deliveryManagerName,
                    projectNumber: ele.projectNumber,
                    projectName: ele.projectName,
                    resourceAllocationStatus: ele.resourceAllocationStatus,
                    releaseDate: ele.releaseDate.toString().slice(0,10) ,
                    offboardingStatus: ele.offboardingStatus,
                    accesstoMainGate: accesstoMainGate,
                    separationReason: reason
                  };
                  tempEle.empList.noList.push(obj);
                  tempEle.total += 1;
                }

              })
            })
        })
       
        this.dMWiseAccesstoMainGate.set(ele.deliveryManagerId, tempEle);
      })

    })
    console.log(this.dMWiseAccesstoMainGate);
  }
}
