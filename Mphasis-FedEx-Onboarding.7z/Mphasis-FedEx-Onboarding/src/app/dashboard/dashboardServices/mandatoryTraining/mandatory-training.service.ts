import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IMandatoryTrainingTable } from '../../dashboardInterfaces/TableElements ';

@Injectable({
  providedIn: 'root'
})
export class MandatoryTrainingService {
  jsonUrl = 'http://localhost:3000/';

  constructor(private http: HttpClient) { }

  getMandatoryTrainingStatusTableData():Observable<IMandatoryTrainingTable[]>{
    return this.http.get<IMandatoryTrainingTable[]>(this.jsonUrl+'mandatoryTrainingData')
  }
}
