import { TestBed } from '@angular/core/testing';

import { MandatoryTrainingService } from './mandatory-training.service';

describe('MandatoryTrainingService', () => {
  let service: MandatoryTrainingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MandatoryTrainingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
