export class ChartApiData {
  label: string;
  data: {
    Yes: number;
    No: number;
    NotApplicable?: number;
    //InProgress?: number;
  };

  constructor(
    label?: string,
    yes?: number,
    no?: number,
    notApplicable?: number,
    //inProgress?: number
  ) {
    this.label = label ?? '';
    this.data = {
      Yes: yes ?? 0,
      No: no ?? 0,
      NotApplicable: notApplicable ?? 0,
     // InProgress: inProgress ?? 0,
    };

    // if (notApplicable) {
    //   this.data.notApplicable = notApplicable;
    // }

    // if (inProgress) {
    //   this.data.inProgress = inProgress;
    // }
  }

  clear() {
    this.label = '';
    this.data.Yes = 0;
    this.data.No = 0;
    this.data.NotApplicable = 0;
   // this.data.InProgress = 0;
  }
}

export class BarchartApiData {
  ['Data privacy']!: {
    Yes?: Number;
    No?: number;
    InProgress?: number;
  };
  ISMS:
    | {
        Yes: Number;
        No: number;
        InProgress?: number;
      }
    | undefined;

  constructor(
    yes?: Number,
    no?: number,
    inProgressD?: number,
    yes1?: Number,
    no1?: number,
    inProgressI?: number
  ) {
    this['Data privacy'] = {
      Yes: yes ?? 0,
      No: no ?? 0,
      InProgress: inProgressD ?? 0,
    };

    this.ISMS = {
      Yes: yes1 ?? 0,
      No: no1 ?? 0,
      InProgress: inProgressI ?? 0,
    };
  }
}
