export class ChartElementData {
  label: string;
  data: number[];
  order: number;
  sum?: number;
  type?: string;
  backgroundColor?: string;
  borderColor?: string;

  constructor(
    label?: string,
    data?: number[],
    order?: number,
    sum?: number,
    type?: string,
    backgroundColor?: string,
    borderColor?: string
  ) {
    this.label = label ?? '';
    this.data = data ?? [];
    this.order = order ?? 0;
    this.sum = sum ?? 0;
    this.type = type ?? '';
    this.backgroundColor = backgroundColor ?? '';
    this.borderColor = borderColor ?? '';
  }
}
