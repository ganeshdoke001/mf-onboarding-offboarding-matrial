export class CardData {
  label: string;
  data: {
    total: number;
    Out_Transfer?: number;
    Terminated?: number;
    Absconded?: number;
    Resigned?: number;
    onboarding?: number;
    transition?: number;
    offboarding?: number;
    yes?: number;
    no?: number;
    yetToStart?: number;
    present?: number;
    absent?: number;
    onsite?: number;
    offshore?: number;
    completed?: number;
    'not Completed'?: number;
    'total employees'?: number;
  };

  constructor(
    label?: string,
    total?: number,
    Out_Transfer?: number,
    Terminated?: number,
    Absconded?: number,
    Resigned?: number,
    onboarding?: number,
    transition?: number,
    offboarding?: number,
    yes?: number,
    no?: number,
    yetToStart?: number,
    present?: number,
    absent?: number,
    completed?: number,
    notCompleted?: number,
    onsite?: number,
    offshore?: number,
    totalEmployees?: number
  ) {
    this.label = label ?? '';
    this.data = {
      total: total ?? 0,
      Out_Transfer: Out_Transfer ?? 0,
      Terminated: Terminated ?? 0,
      Absconded: Absconded ?? 0,
      Resigned: Resigned ?? 0,
      onboarding: onboarding ?? 0,
      transition: transition ?? 0,
      offboarding: offboarding ?? 0,
      yes: yes ?? 0,
      no: no ?? 0,
      yetToStart: yetToStart ?? 0,
      present: present ?? 0,
      absent: absent ?? 0,
      completed: completed ?? 0,
      'not Completed': notCompleted ?? 0,
      onsite: onsite ?? 0,
      offshore: offshore ?? 0,
      'total employees': totalEmployees ?? 0,
    };
  }
}

export class DMWiseEmployeeProjectStatus {
  dmName: string;
  dmEmpId: number;
  inTransfer: number;
  newHire: number;
  outTransfer: number;
  separated: number;
  total: number;
  empId: number[] = [];

  constructor(
    dmEmpId: number,
    dmName?: string,
    inTransfer?: number,
    newHire?: number,
    outTransfer?: number,
    separated?: number
  ) {
    this.dmName = dmName ?? '';
    this.dmEmpId = dmEmpId;
    this.inTransfer = inTransfer ?? 0;
    this.newHire = newHire ?? 0;
    this.outTransfer = outTransfer ?? 0;
    this.separated = separated ?? 0;
    this.total =
      this.inTransfer + this.newHire + this.outTransfer + this.separated;
  }
}

export class OffBoardingCardData {
  offboarding!: number;
  outTransfer!: number;
  terminated!: number;
  absconded!: number;
  resigned!: number;

  constructor(
    offboarding?: number,
    outTransfer?: number,
    terminated?: number,
    absconded?: number,
    resigned?: number
  ) {
    (offboarding = offboarding ?? 0),
      (outTransfer = outTransfer ?? 0),
      (terminated = terminated ?? 0),
      (absconded = absconded ?? 0),
      (resigned = resigned ?? 0);
  }
}
