import { DatePipe } from '@angular/common';
import { map } from 'rxjs/operators';

export interface Location {
  Location: string;
  Completed: number;
  NotCompleted: number;
  LaptopAwaited: number;
  MaternityLeave: number;
  ndrp: number;
  Resigned: number;
  Awoi: number;
  Grandtotal: number;
}
export interface Offshore {
  Leader: string;
  Completed: number;
  NotCompleted: number;
  LaptopAwaited: number;
  MaternityLeave: number;
  ndrp: number;
  Resigned: number;
  Awoi: number;
  Grandtotal: number;
}
export interface Onsite {
  Leader: string;
  Completed: number;
  NotCompleted: number;
  LaptopAwaited: number;
  MaternityLeave: number;
  ndrp: number;
  Resigned: number;
  Awoi: number;
  Grandtotal: number;
}

export interface Leader {
  employeeName?: string;
  status?: string;
  details: [];
}

export class Employee {
  date: string;
  empNumber: number;
  empName: string;
  dateOfJoining: string;
  transitionType: string;
  location: string;
  locationPosition: string;
  gradeDesc: string;
  empCategory: string;
  pmEmpId: number;
  pmName: string;
  pmContactEstablished: string;
  dmEmpId: number;
  dmName: string;
  projectNumber: string;
  projectName: string;
  resourceAllocationStatus: string;
  mphasisOnBoarding: MphasisOnBoarding;
  empListOffbarding!: DmEmpList;
  accountOnboarding: AccountOnboarding;
  mphasisDataOffBoarding!:MphasisData;
  fedExDataOffBoarding!: FedExData;
  employeeBGVdata: any;

  constructor(
    date?: string,
    empNumber?: number,
    empName?: string,
    dateOfJoining?: string,
    transitionType?: string,
    location?: string,
    locationPosition?: string,
    gradeDesc?: string,
    empCategory?: string,
    pmEmpId?: number,
    pmName?: string,
    pmContactEstablished?: string,
    dmEmpId?: number,
    dmName?: string,
    projectNumber?: string,
    projectName?: string,
    resourceAllocationStatus?: string,
    mphasisOnBoarding?: MphasisOnBoarding,
    
    accountOnboarding?: AccountOnboarding,
    mphasisDataOffBoarding?: MphasisData,
    fedExDataOffBoarding?: FedExData,
    employeeBGVdata?: any
  ) {
    this.date = date ?? '';
    this.empNumber = empNumber ?? 0;
    this.empName = empName ?? '';
    this.dateOfJoining = dateOfJoining ?? '';
    this.transitionType = transitionType ?? '';
    this.location = location ?? '';
    this.locationPosition = locationPosition ?? '';
    this.gradeDesc = gradeDesc ?? '';
    this.empCategory = empCategory ?? '';
    this.pmEmpId = pmEmpId ?? 0;
    this.pmName = pmName ?? '';
    this.pmContactEstablished = pmContactEstablished ?? '';
    this.dmEmpId = dmEmpId ?? 0;
    this.dmName = dmName ?? '';
    this.projectNumber = projectNumber ?? '';
    this.projectName = projectName ?? '';
    this.resourceAllocationStatus = resourceAllocationStatus ?? '';
    this.mphasisOnBoarding = mphasisOnBoarding ?? new MphasisOnBoarding();
    this.accountOnboarding = accountOnboarding ?? new AccountOnboarding();
    this.employeeBGVdata = employeeBGVdata ?? '';
  }
}
//FedExLDAPIdModalHeaders
export class MphasisOnBoarding {
  laptop: Laptop;
  access: AccessAndStatus[];
  assets: AssetAndStatus[];
  wfhAttestation: string;
  accesstoMandatoryCourse: string;
  mandatoryCourses: CourseAndStatus[];
  mphasisVpnActivated: string;
  certificateSubmited: string;
  assignmentStartDate: string;
  assignmentEndDate: string;

  constructor(
    laptop?: Laptop,
    access?: AccessAndStatus[],
    assets?: AssetAndStatus[],
    wfhAttestation?: string,
    accesstoMandatoryCourse?: string,
    mandatoryCourses?: CourseAndStatus[],
    mphasisVpnActivated?: string,
    certificateSubmited?: string,
    assignmentStartDate?: string,
    assignmentEndDate?: string
  ) {
    this.laptop = laptop ?? new Laptop();
    this.access = access ?? [];
    this.assets = assets ?? [];
    this.wfhAttestation = wfhAttestation ?? '';
    this.accesstoMandatoryCourse = accesstoMandatoryCourse ?? '';
    this.mandatoryCourses = mandatoryCourses ?? [];
    this.mphasisVpnActivated = mphasisVpnActivated ?? '';
    this.certificateSubmited = certificateSubmited ?? '';
    this.assignmentStartDate = assignmentStartDate ?? '';
    this.assignmentEndDate = assignmentEndDate ?? '';
  }
}

export class AccountOnboarding {
  accountInduction: string;
  accountNdaSigned: string;
  accountDateOfJoin: string;
  ldapIdActivated: string;
  ldapId: number;
  accountEmailIdActivated: string;
  accountEmailId: string;
  designation: string;
  accountMVOIPActivated: string;
  accountLaptop: Laptop;
  assets: AssetAndStatus[];

  constructor(
    accountInduction?: string,
    accountNdaSigned?: string,
    accountDateOfJoin?: string,
    ldapIdActivated?: string,
    ldapId?: number,
    accountEmailIdActivated?: string,
    accountEmailId?: string,
    designation?: string,
    accountMVOIPActivated?: string,
    accountLaptop?: Laptop,
    assets?: AssetAndStatus[]
  ) {
    this.accountInduction = accountInduction ?? '';
    this.accountNdaSigned = accountNdaSigned ?? '';
    this.accountDateOfJoin = accountDateOfJoin ?? '';
    this.ldapIdActivated = ldapIdActivated ?? '';
    this.ldapId = ldapId ?? 0;
    this.accountEmailIdActivated = accountEmailIdActivated ?? '';
    this.accountEmailId = accountEmailId ?? '';
    this.designation = designation ?? '';
    this.accountMVOIPActivated = accountMVOIPActivated ?? '';
    this.accountLaptop = accountLaptop ?? new Laptop();
    this.assets = assets ?? [];
  }
}

export class Laptop {
  status: string;
  hostName: string;
  serialNumber: number | null;

  constructor(status?: string, hostName?: string, serialNumber?: number) {
    this.status = status ?? '';
    this.hostName = hostName ?? 'NA';
    this.serialNumber = serialNumber ?? null;
  }
}

export class AccessAndStatus {
  accessName: string;
  accessStatus: string;

  constructor(accessName: string, accessStatus: string) {
    this.accessName = accessName ?? '';
    this.accessStatus = accessStatus ?? '';
  }
}

export class AssetAndStatus {
  assetName: string;
  assetStatus: string;

  constructor(assetName: string, assetStatus: string) {
    this.assetName = assetName ?? '';
    this.assetStatus = assetStatus ?? '';
  }
}

export class CourseAndStatus {
  courseName: string;
  status: string;

  constructor(courseName: string, status: string) {
    this.courseName = courseName ?? '';
    this.status = status ?? '';
  }
}

export interface IDMYesNoNAWithLists {
  dmName: string;
  dmEmpId: number;
  yes?: number;
  no?: number;
  notApplicable?: number;
  yesList?: any[];
  noList?: any[];
  notApplicableList?: any[];
  total?: number;
}

export class PMWiseCount {
  PMName: string;
  count: number;

  constructor(PMName: string) {
    this.PMName = PMName;
    this.count = 1;
  }
}

export class DMYesNoWithLists {
  dmName: string;
  dmEmpId: number;
  yes: number;
  no: number;
  total: number;

  empList!: {
    yesList: any[];
    noList: any[];
  };

  constructor(obj = {} as IDMYesNoNAWithLists) {
    this.dmEmpId = obj.dmEmpId;
    this.dmName = obj.dmName;
    this.yes = obj.yes ?? 0;
    this.no = obj.no ?? 0;
    this.total = obj.total ?? 0;
    if (!obj.notApplicableList) {
      this.empList = {
        yesList: obj.yesList ?? [],
        noList: obj.noList ?? [],
      };
    }
  }
}

export class DMYesNoNAWithLists extends DMYesNoWithLists {
  notApplicable: number;
  empList: EmployeeYesNoNALists;
  constructor(obj = {} as IDMYesNoNAWithLists) {
    super(obj);
    this.notApplicable = obj.notApplicable ?? 0;
    let yesList = obj.yesList ?? [];
    let noList = obj.noList ?? [];
    let notApplicableList = obj.notApplicableList ?? [];
    this.empList =
      new EmployeeYesNoNALists({
        yesList,
        noList,
        notApplicableList,
      }) ?? new EmployeeYesNoNALists();
  }
}

export class DMWiseEmployeeLaptopStatus extends DMYesNoWithLists {}

export class DMWiseEmployeeNDAStatus extends DMYesNoNAWithLists {}

export class DMWiseEmployeeODCStatus extends DMYesNoNAWithLists {}

export class DMWiseEmployeeInductionStatus extends DMYesNoWithLists {}

export class DMWiseEmployeeWFHStatus extends DMYesNoWithLists {
  pmList: Map<number, PMWiseCount>;

  constructor(obj = {} as IDMYesNoNAWithLists) {
    super(obj);
    this.pmList = new Map();
  }
}

export interface IDMWiseOnboardingData {
  laptop: DMWiseEmployeeLaptopStatus;
  nda: DMWiseEmployeeNDAStatus;
  odc: DMWiseEmployeeODCStatus;
  accountInduction: DMWiseEmployeeInductionStatus;
  wfh: DMWiseEmployeeWFHStatus;
}

export class DMWiseOnboardingData {
  laptop: DMWiseEmployeeLaptopStatus;
  nda: DMWiseEmployeeNDAStatus;
  odc: DMWiseEmployeeODCStatus;
  accountInduction: DMWiseEmployeeInductionStatus;
  wfh: DMWiseEmployeeWFHStatus;
  total: number = 0;

  constructor(obj = {} as IDMWiseOnboardingData) {
    this.laptop = obj?.laptop ?? new DMWiseEmployeeLaptopStatus();
    this.nda = obj?.nda ?? new DMWiseEmployeeNDAStatus();
    this.odc = obj?.odc ?? new DMWiseEmployeeODCStatus();
    this.accountInduction =
      obj?.accountInduction ?? new DMWiseEmployeeInductionStatus();
    this.wfh = obj?.wfh ?? new DMWiseEmployeeWFHStatus();
  }
}

export interface ICommonModal {
  empName: string;
  empId: number;
  gradeDesc: string;
  projectName: string;
  projectNumber: string;
  pmName: string;
  assignmentStartDate: string;
  locationType: string;
  // resourceAllocationStatus: string;
}

export class CommonModal {
  empName: string;
  empId: number;
  gradeDesc: string;
  projectName: string;
  projectNumber: string;
  pmName: string;
  assignmentStartDate: string;
  locationType: string;

  constructor(
    empName: string,
    empId: number,
    gradeDesc?: string,
    projectName?: string,
    pmName?: string,
    assignmentStartDate?: string,
    projectNumber?: string,
    locationType?: string
  ) {
    this.empName = empName;
    this.empId = empId;
    this.gradeDesc = gradeDesc ?? '';
    this.projectName = projectName ?? '';
    this.pmName = pmName ?? '';
    this.assignmentStartDate = assignmentStartDate ?? '';
    this.projectNumber = projectNumber ?? '';
    this.locationType = locationType ?? '';
  }
}

export interface ILaptopModal extends ICommonModal {
  mphasisVPN: string;
  laptopStatus: string;
  serialNumber?: number | null;
  hostName?: string;
}

export class LaptopModal extends CommonModal {
  mphasisVPN: string;
  laptopStatus: string;
  serialNumber: number | null;
  hostName: string;

  constructor(obj = {} as ILaptopModal) {
    super(
      obj.empName,
      obj.empId,
      obj.gradeDesc,
      obj.projectName,
      obj.pmName,
      obj.assignmentStartDate
    );
    this.mphasisVPN = obj.mphasisVPN;
    this.laptopStatus = obj.laptopStatus;
    this.serialNumber = obj.serialNumber ?? null;
    this.hostName = obj.hostName ?? 'NA';
  }
}

export interface IODCModal extends ICommonModal {
  dateOfJoining: string;
}

export class ODCModal extends CommonModal {
  dateOfJoining: string;
  constructor(obj = {} as IODCModal) {
    super(
      obj.empName,
      obj.empId,
      obj.gradeDesc,
      obj.projectName,
      obj.pmName,
      obj.assignmentStartDate
    );
    this.dateOfJoining = obj.dateOfJoining;
  }
}

export interface IAccountInductionModal extends ICommonModal {}

export class AccountInductionModal extends CommonModal {
  constructor(obj = {} as IAccountInductionModal) {
    super(
      obj.empName,
      obj.empId,
      obj.gradeDesc,
      obj.projectName,
      obj.pmName,
      obj.assignmentStartDate
    );
  }
}

export interface INDAModal extends ICommonModal {}

export class NDAModal extends CommonModal {
  constructor(obj = {} as IAccountInductionModal) {
    super(
      obj.empName,
      obj.empId,
      obj.gradeDesc,
      obj.projectName,
      obj.pmName,
      obj.assignmentStartDate
    );
  }
}

export interface IWFHModal extends ICommonModal {
  // pmEmpId: number;
}

export class WFHModal extends CommonModal {
  // pmEmpId: number;
  constructor(obj = {} as IWFHModal) {
    super(
      obj.empName,
      obj.empId,
      obj.gradeDesc,
      obj.projectName,
      obj.pmName,
      obj.assignmentStartDate
    );

    // this.pmEmpId = obj.pmEmpId;
  }
}

export interface IEmployeeYesNoLists {
  yesList: any[];
  noList: any[];
}

export interface IEmployeeYesNoNALists extends IEmployeeYesNoLists {
  notApplicableList: any[];
}

export class EmployeeYesNoLists {
  yesList: any[];
  noList: any[];

  constructor(obj = {} as IEmployeeYesNoLists) {
    this.yesList = obj.yesList ?? [];
    this.noList = obj.noList ?? [];
  }
}

export class EmployeeYesNoNALists extends EmployeeYesNoLists {
  notApplicableList: any[];

  constructor(obj = {} as IEmployeeYesNoNALists) {
    super(obj);
    this.notApplicableList = obj.notApplicableList ?? [];
  }
}

export class temporary extends DMYesNoNAWithLists {
  empList: {
    yesList: LaptopModal[];
    noList: LaptopModal[];
    notApplicableList: LaptopModal[];
  };

  constructor(obj = {} as IDMYesNoNAWithLists) {
    super();
    this.empList = {
      yesList: obj.yesList ?? [],
      noList: obj.noList ?? [],
      notApplicableList: obj.notApplicableList ?? [],
    };
  }
}
export interface IBGVDashboardElement {
  value?: number | string;
  backgroundColor?: string;
  width?: string;
  height?: string;
}

export class BGVDashboardElement {
  value: number | string;
  backgroundColor: string;
  width: string;
  height: string;

  constructor(obj = {} as IBGVDashboardElement) {
    this.value = obj.value ?? 0;
    this.backgroundColor = obj.backgroundColor ?? 'white';
    this.width = obj.width ?? '';
    this.height = obj.height ?? '';
  }
}

export class BGVEmpData {
  employeeNumber: number;
  fedEXId: number;
  employeeName: string;
  doj: string;
  posLocName: string;
  location: string;
  dm: string;
  pm: string;
  bgvStatus: string;
  redReason: string;
  bgvAging: number;
  backgroundverificationId: number;

  constructor(
    employeeNumber: number,
    fedEXId: number,
    employeeName: string,
    doj: string,
    posLocName: string,
    location: string,
    dm: string,
    pm: string,
    redReason: string,
    bgvAging: number,
    backgroundverificationId: number,
    bgvStatus?: string
  ) {
    this.bgvAging = bgvAging;
    this.dm = dm;
    this.doj = doj;
    this.employeeName = employeeName;
    this.employeeNumber = employeeNumber;
    this.fedEXId = fedEXId;
    this.location = location;
    this.pm = pm;
    this.posLocName = posLocName;
    this.redReason = redReason;
    this.backgroundverificationId = backgroundverificationId;
    this.bgvStatus = bgvStatus ?? 'na';

    if (this.bgvStatus == null) {
      this.bgvStatus = 'NA';
      console.log('sd');
    }
  }
}

export class BGVDashboardData {
  location: string;
  totalEmployees: number;
  green: number;
  reinitiatedToGreen: number;
  redDeviation: number;
  bgvIncompleteEmployeesDOJBefore2010: number;
  WIP: number;
  red: number;
  redReinitiated: number;
  bgvCompliant: number;

  constructor(
    location?: string,
    totalEmployees?: number,
    green?: number,
    reinitiatedToGreen?: number,
    redDeviation?: number,
    bgvIncompleteEmployeesDOJBefore2010?: number,
    WIP?: number,
    red?: number,
    redReinitiated?: number,
    bgvCompliant?: number
  ) {
    this.location = location ?? 'Grand Total';
    this.totalEmployees = totalEmployees ?? 0;
    this.green = green ?? 0;
    this.reinitiatedToGreen = reinitiatedToGreen ?? 0;
    this.redDeviation = redDeviation ?? 0;
    this.bgvIncompleteEmployeesDOJBefore2010 =
      bgvIncompleteEmployeesDOJBefore2010 ?? 0;
    this.WIP = WIP ?? 0;
    this.red = red ?? 0;
    this.redReinitiated = redReinitiated ?? 0;
    this.bgvCompliant = bgvCompliant ?? 0;
  }
}

export class BgvDmWiseData {
  dm: string;
  location: string;
  totalEmployees: number;
  green: number;
  redinintiatedToGreen: number;
  redDeviation: number;
  WIP: number;
  red: number;
  redReintiated: number;
  bgvCompliant: number;

  constructor(
    dm?: string,
    location?: string,
    totalEmployees?: number,
    green?: number,
    redinintiatedToGreen?: number,
    redDeviation?: number,
    WIP?: number,
    red?: number,
    redReintiated?: number,
    bgvCompliant?: number
  ) {
    (this.dm = dm ?? 'NA'), (this.location = location ?? 'NA');
    this.totalEmployees = totalEmployees ?? 0;
    this.green = green ?? 0;
    this.redinintiatedToGreen = redinintiatedToGreen ?? 0;
    this.redDeviation = redDeviation ?? 0;
    this.WIP = WIP ?? 0;
    this.red = red ?? 0;
    this.redReintiated = redReintiated ?? 0;
    this.bgvCompliant = bgvCompliant ?? 0;
  }
}

export interface IMandatoryTrainingTable {
  empName: string;
  email: string;
  empID: number,
  theCodeOfBusinessConduct: string,
  dataPrivacyGDPRCCPAawareness: string,
  infromationSecurityManagementSystem: string,
  mandatoryTrainingStatus: string,
  pmName: string,
  dmName: string,
}
//--****----****Offboarding***----*****--



export class EmployeeDetails {
  DeliveryManagerId!: number;
  Emplist!: Emplist[];
  constructor(DeliveryManagerId: number,
    Emplist: Emplist[]) {
    this.DeliveryManagerId = DeliveryManagerId;
    this.Emplist = Emplist;

  }
}
export class Emplist {
  employeeNumber!: number;
  employeeName!: string;
  dateOfJoining!: string;
  transition!: string;
  workLocation!: string;
  position!: string;
  gradeDescription!: string;
  employeeCategory!: string;
  projectManagerId!: string;
  projectManagerName!: string;
  projectManagerContact!: string;
  deliveryManagerId!: number;
  deliveryManagerName!: string;
  projectNumber!: string;
  projectName!: string;
  resourceAllocationStatus!: string;
  releaseDate!: string;
  offboardingStatus!: string;
  constructor(
    employeeNumber: number,
    employeeName: string,
    dateOfJoining: string,
    transition: string,
    workLocation: string,
    position: string,
    gradeDescription: string,
    employeeCategory: string,
    projectManagerId: string,
    projectManagerName: string,
    projectManagerContact: string,
    deliveryManagerId: number,
    deliveryManagerName: string,
    projectNumber: string,
    projectName: string,
    resourceAllocationStatus: string,
    releaseDate: string,
    offboardingStatus: string
  ) {
    this.employeeNumber = employeeNumber;
    this.employeeName = employeeName;
    this.dateOfJoining = dateOfJoining;
    this.transition = transition;
    this.workLocation = workLocation;
    this.position = position;
    this.gradeDescription = gradeDescription;
    this.employeeCategory = employeeCategory;
    this.projectManagerId = projectManagerId;
    this.projectManagerName = projectManagerName;
    this.projectManagerContact = projectManagerContact;
    this.deliveryManagerId = deliveryManagerId;
    this.deliveryManagerName = deliveryManagerName;
    this.projectNumber = projectNumber;
    this.projectName = projectName;
    this.resourceAllocationStatus = resourceAllocationStatus;
    this.releaseDate = releaseDate;
    this.offboardingStatus = offboardingStatus;
  }
}


export class OffboardingDetails {
  DeliveryManagerId!: number;
  DmEmpList!: DmEmpList[];

  constructor(DeliveryManagerId: number,
    DmEmpList: DmEmpList[]) {
    this.DeliveryManagerId = DeliveryManagerId;
    this.DmEmpList= DmEmpList;
  }
}
export class DmEmpList{
  employeeNumber!: number;
  fedExData!: FedExData[];
  mphasisData!: MphasisData [];

  constructor(employeeNumber: number,
    fedExData: FedExData[],
    mphasisData: MphasisData[]){
    this.employeeNumber=employeeNumber;
    this.fedExData=fedExData;
    this.mphasisData=mphasisData;
  }
}
export class OffboardingData  {
  offboardingId!: string;
  employeeNumber!: number;
  deliveryManagerId!: number;
  projectManagerId!: number;
  organisation!: string;
  releaseDate!: string;
  email!: string;
  userId!: string;
  access!: {
    accessID: string;
    accessName: string;
    accessStatus: string;
  };
  vpn!: string;
  assets!:Assets [];
  otherAssets!: string;
  separationReason!: string;
  status!: string;

  constructor(offboardingId: string,
    employeeNumber: number,
    deliveryManagerId: number,
    projectManagerId: number,
    organisation: string,
    releaseDate: string,
    email: string,
    userId: string,
    access: {
      accessID: string;
      accessName: string;
      accessStatus: string;
    },
    vpn: string,
    assets: Assets[],
    otherAssets: string,
    separationReason: string,
    status: string) {

    this.offboardingId = offboardingId ?? '',
      this.employeeNumber = employeeNumber ?? 0,
      this.deliveryManagerId = deliveryManagerId ?? 0,
      this.projectManagerId = projectManagerId ?? 0,
      this.organisation = organisation ?? '',
      this.releaseDate = releaseDate ?? '',
      this.email = email ?? '',
      this.userId = userId ?? '',
      this.access = access;
    this.vpn = vpn ?? '',
      this.assets = assets?? [],
      this.otherAssets = otherAssets,
      this.separationReason = separationReason ?? '',
      this.status = status ?? ''

  }

}
export class Assets {
  assetId!: string;
  assetName!: string;
  assetStatus!: string;
  assetCategory!: string;

  constructor() { }
}

export class FedExData extends OffboardingData {
 
}

export class MphasisData extends OffboardingData {
}

export interface DmData{
  deliveryManagerName: string;
  deliveryManagerId: number;
  yes?: number;
  no?: number;
  notApplicable?: number;
  yesList?: any[];
  noList?: any[];
  notApplicableList?: any[];
  total?: number;
}
export class DMYesNoWithListsOff {
  deliveryManagerName: string;
  deliveryManagerId: number;
  yes: number;
  no: number;
  total: number;
  empList!: {
    yesList: any[];
    noList: any[];
  };

  constructor(obj = {} as DmData) {
    this.deliveryManagerId = obj.deliveryManagerId;
    this.deliveryManagerName = obj.deliveryManagerName;
    this.yes = obj.yes ?? 0;
    this.no = obj.no ?? 0;
    this.total = obj.total ?? 0;
    if (!obj.notApplicableList) {
      this.empList = {
        yesList: obj.yesList ?? [],
        noList: obj.noList ?? [],
      };
    }
  }
}

export class DMYesNoNAWithListOff extends DMYesNoWithListsOff {
  notApplicable: number;
  empList: EmployeeYesNoNALists;
  constructor(obj = {} as DmData) {
    super(obj);
    this.notApplicable = obj.notApplicable ??0;
    let yesList = obj.yesList ?? [];
    let noList = obj.noList ?? [];
    let notApplicableList = obj.notApplicableList ?? [];
    this.empList =
      new EmployeeYesNoNALists({
        yesList,
        noList,
        notApplicableList,
      }) ?? new EmployeeYesNoNALists();
  }
}


export class DMWiseEmployeeFedExLDAPId extends DMYesNoWithListsOff { }
export class DMWiseEmployeeFedExEmailId extends DMYesNoWithListsOff { }

export class DMWiseEmployeeMphasisVPN extends DMYesNoNAWithListOff { }
export class DMWiseEmployeeFedExMVOIP extends DMYesNoWithListsOff { }

export class DMWiseEmployeeFedExLaptop extends DMYesNoWithListsOff { }
export class DMWiseEmployeeAnyCustomersuppliedDevice extends DMYesNoWithListsOff { }

export class DMWiseEmployeeAccesstoFedExODC extends DMYesNoWithListsOff { }
export class DMWiseEmployeeMphasisEmailId extends DMYesNoNAWithListOff { }

export class DMWiseEmployeeMphasisUserId extends DMYesNoNAWithListOff { }
export class DMWiseEmployeeMphasisLaptop extends DMYesNoNAWithListOff { }
export class DMWiseEmployeeAccesstoMainGate extends DMYesNoNAWithListOff { }




export interface IDMWiseOffboardingData{
  fedExLDAPId:DMWiseEmployeeFedExLDAPId;
  fedExEmailId:DMWiseEmployeeFedExEmailId;
  mphasisVPN:DMWiseEmployeeMphasisVPN;
  fedExMVOIP:DMWiseEmployeeFedExMVOIP;
  fedExLaptop:DMWiseEmployeeFedExLaptop;
  anyCustomersuppliedDevice:DMWiseEmployeeAnyCustomersuppliedDevice;
  accesstoFedExODC:DMWiseEmployeeAccesstoFedExODC;
  mphasisEmailId:DMWiseEmployeeMphasisEmailId;
  mphasisUserId:DMWiseEmployeeMphasisUserId;
  mphasisLaptop:DMWiseEmployeeMphasisLaptop;
  accesstoMainGate:DMWiseEmployeeAccesstoMainGate;
}

export class DMWiseOffboardingData {
  fedExLDAPId:DMWiseEmployeeFedExLDAPId;
  fedExEmailId:DMWiseEmployeeFedExEmailId;
  mphasisVPN:DMWiseEmployeeMphasisVPN;
  fedExMVOIP:DMWiseEmployeeFedExMVOIP;
  fedExLaptop:DMWiseEmployeeFedExLaptop;
  anyCustomersuppliedDevice:DMWiseEmployeeAnyCustomersuppliedDevice;
  accesstoFedExODC:DMWiseEmployeeAccesstoFedExODC;
  mphasisEmailId:DMWiseEmployeeMphasisEmailId;
  mphasisUserId:DMWiseEmployeeMphasisUserId;
  mphasisLaptop:DMWiseEmployeeMphasisLaptop;
  accesstoMainGate:DMWiseEmployeeAccesstoMainGate;
  total: number = 0;

  constructor(obj = {} as IDMWiseOffboardingData){
    this.fedExLDAPId=obj?.fedExLDAPId?? new DMWiseEmployeeFedExLDAPId();
    this.fedExEmailId=obj?.fedExEmailId?? new DMWiseEmployeeFedExEmailId();
    this.mphasisVPN=obj?.mphasisVPN?? new DMWiseEmployeeMphasisVPN();
    this.fedExMVOIP=obj?.fedExMVOIP?? new DMWiseEmployeeFedExMVOIP();
    this.fedExLaptop=obj?.fedExLaptop?? new DMWiseEmployeeFedExLaptop();
    this.anyCustomersuppliedDevice=obj?.anyCustomersuppliedDevice?? new DMWiseEmployeeAnyCustomersuppliedDevice();
    this.accesstoFedExODC=obj?.accesstoFedExODC?? new DMWiseEmployeeAccesstoFedExODC();
    this.mphasisEmailId=obj?.mphasisEmailId?? new DMWiseEmployeeMphasisEmailId();
    this.mphasisUserId=obj?.mphasisUserId?? new DMWiseEmployeeMphasisUserId();
    this.mphasisLaptop=obj?.mphasisLaptop?? new DMWiseEmployeeMphasisLaptop();
    this.accesstoMainGate=obj?.accesstoMainGate?? new DMWiseEmployeeAccesstoMainGate();
  }
  
}


export class FedExLDAPIdModel extends Emplist{
  userId!: string;
  separationReason!: string;
}

export class FedExEmailIdModel extends Emplist{
  email!: string;
  separationReason!: string;
}
export class MphasisVPNModel extends Emplist{
  vpn!: string;
  separationReason!: string;
}

export class FedExMVOIPModel extends Emplist{
  vpn!: string;
  separationReason!: string;
}

export class FedExLaptopModel extends Emplist{
  fedExLaptop!: string;
  separationReason!: string;
}
export class AnyCustomersuppliedDeviceModel extends Emplist{
  anyCustomersuppliedDevice!: string;
  separationReason!: string;
}
export class AccesstoFedExODCModel extends Emplist{
  accesstoFedExODC!: string;
  separationReason!: string;
}

export class MphasisEmailIdModel extends Emplist{
  mphasisEmailId!: string;
  separationReason!: string;
}
export class MphasisUserIdModel extends Emplist{
  mphasisUserId!: string;
  separationReason!: string;
}

export class MphasisLaptopModel extends Emplist{
  mphasisLaptop!: string;
  separationReason!: string;
}
export class AccesstoMainGateModel extends Emplist{
  accesstoMainGate!: string;
  separationReason!: string;
}

