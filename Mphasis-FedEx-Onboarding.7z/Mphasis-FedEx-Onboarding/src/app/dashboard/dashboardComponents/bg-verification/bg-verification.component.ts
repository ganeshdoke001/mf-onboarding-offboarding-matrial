import { Component, OnInit, ViewChild } from '@angular/core';
import {
  BGVDashboardData,
  BgvDmWiseData,
} from '../../dashboardInterfaces/TableElements ';
import {
  BGVHeaders,
  FedExBGVDashbord,
} from '../../dashboardUtilities/dashboardUtilities';
import { BGVNewHireHeaders } from '../../dashboardUtilities/dashboardUtilities';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import { Table } from 'primeng/table';
import { CardData } from '../../dashboardInterfaces/CardData';
import { PrimeNGConfig } from 'primeng/api';
import { BGVEmpData } from '../../dashboardInterfaces/TableElements ';
import { BgVerificationService } from '../../dashboardServices/bg-verification/bg-verification.service';

@Component({
  selector: 'app-bg-verification',
  templateUrl: './bg-verification.component.html',
  styleUrls: ['./bg-verification.component.scss'],
})
export class BgVerificationComponent implements OnInit {
  tableHeaders: IHeader[] = FedExBGVDashbord;
  @ViewChild('dt') tableRef!: Table;
  dashboardTableName = "FedEx BGV Dashboard - 23rd Jan'23";
  BGVHeaders = BGVHeaders;
  grandTotalData = new BGVDashboardData();
  tableData!: any;
  cardColorValue1 = '#358590';
  cardColorValue2 = '#6f8032da';
  cardColorValue3 = '#83477b';
  cardData!: CardData;
  bgvCompliant!: CardData;
  BGVNewHireHeaders = BGVNewHireHeaders;
  dateFilter1: string[] = ['Monthly', 'Quarterly', 'Yearly', 'Customize'];

  constructor(
    private bgvService: BgVerificationService,
    private primengConfig: PrimeNGConfig
  ) {}
  dashbordAPIResponse!: {
    bgvDashbordOffshoreData: BGVDashboardData;
    bgvDashbordOnbordData: BGVDashboardData;
  };
  BGVDmWiseData!: BgvDmWiseData[];
  BGVEmployeesData!: BGVEmpData[];
  BGVData!: BGVDashboardData[];
  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.setData();
    this.setEmployeeData();
    this.setDMWiseData();
  }
  setDMWiseData() {
    this.bgvService.getDMWiseData().subscribe((res: any) => {
      res.data.forEach((ele: any) => {
        ele.DmData.forEach((data: any) => {
          data['dm'] = ele.dm;
        });
        delete ele.dm;
      });
      let bgvDmData: BgvDmWiseData[] = [];
      res.data.forEach((data: any) => {
        data.DmData.forEach((element: BgvDmWiseData) => {
          bgvDmData.push(element);
        });
      });
      this.BGVDmWiseData = bgvDmData;
    });
  }

  setData() {
    this.bgvService.getDashbordData().subscribe((res) => {
      res.data.forEach((ele: any) => {
        delete ele['bgvWaived'];
      });
      this.BGVData = this.addData(res.data as BGVDashboardData[]);
    });
  }
  roundOffValues(res: any) {
    res.forEach((ele: BGVDashboardData) => {
      ele.bgvCompliant = parseFloat(ele.bgvCompliant.toFixed(2));
    });
  }

  addData(bgvData: BGVDashboardData[]): BGVDashboardData[] {
    let x = 0;
    bgvData.forEach((entry: BGVDashboardData) => {
      x++;
      this.grandTotalData.WIP += entry.WIP;
      this.grandTotalData.bgvIncompleteEmployeesDOJBefore2010 =
        entry.bgvIncompleteEmployeesDOJBefore2010;
      this.grandTotalData.green += entry.green;
      this.grandTotalData.red += entry.red;
      this.grandTotalData.redDeviation += entry.redDeviation;
      this.grandTotalData.redReinitiated += entry.redReinitiated;
      this.grandTotalData.reinitiatedToGreen += entry.reinitiatedToGreen;
      this.grandTotalData.totalEmployees += entry.totalEmployees;
    });
    this.grandTotalData.bgvCompliant =
      (this.grandTotalData.green / this.grandTotalData.totalEmployees) * 100;
    bgvData.push(this.grandTotalData);
    this.roundOffValues(bgvData);
    this.setCardData(bgvData);

    return bgvData;
  }

  setCardData(bgvData: BGVDashboardData[]) {
    this.cardData = {
      label: 'Employees Count',
      data: {
        total: bgvData[2].totalEmployees,
        onsite: bgvData[1].totalEmployees,
        offshore: bgvData[0].totalEmployees,
      },
    };
    this.bgvCompliant = {
      label: 'BGV Completion%',
      data: {
        total: bgvData[2].bgvCompliant,
        onsite: bgvData[1].bgvCompliant,
        offshore: bgvData[0].bgvCompliant,
      },
    };
  }

  setEmployeeData() {
    this.bgvService.getEmployeeStatusData().subscribe((res) => {
      this.BGVEmployeesData = res as BGVEmpData[];
    });
  }

  applyFilter(event: any, field: any) {
    this.tableRef.filter(event.target.value, field, 'contains');
  }
  showrecord(record: any) {
    console.log(record);
  }
  addFilter(value: string) {
    this.tableHeaders.filter((ele: any) => {
      if (ele.value == value) {
        ele.filter = !ele.filter;
        return;
      }
    });
  }
}
