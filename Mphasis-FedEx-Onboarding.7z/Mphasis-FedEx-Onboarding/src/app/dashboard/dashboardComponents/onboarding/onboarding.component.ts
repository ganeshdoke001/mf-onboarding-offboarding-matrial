import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription, forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import { NotifierService } from 'src/app/shared/shared-services/notifier-service/notifier.service';
import { CardData } from '../../dashboardInterfaces/CardData';
import { ChartApiData } from '../../dashboardInterfaces/ChartApiData';
import { DashboardService } from '../../dashboardServices/dashboard.service';
import {
  YesNoNA,
  YesNo,
  ChartLableValues,
  OnboardingStatusHeaders,
  ProjectStatusHeaders,
  LaptopStatusHeaders,
  LaptopModalHeaders,
  NDAStatusHeaders,
  NDAModalHeaders,
  WFHStatusDataHeaders,
  WFHModalHeaders,
  ODCStatusDataHeaders,
  ODCModalHeaders,
  InductionStatusDataHeaders,
  AccountInductionModalHeaders,
  OnboardingCategories,
  OnboardingTablesList,
} from '../../dashboardUtilities/dashboardUtilities';

@Component({
  selector: 'app-onboarding',
  templateUrl: './onboarding.component.html',
  styleUrls: ['./onboarding.component.scss'],
})
export class OnboardingComponent implements OnInit, OnDestroy {
  tableHeaders: IHeader[] = OnboardingTablesList;
  types: IHeader[] = OnboardingCategories;
  startDate: string = '2022-11-01';
  todayDate = new Date().toISOString().slice(0, 10);
  endDate: string = new Date().toISOString().slice(0, 10);
  dateFilter: string[] = ['Monthly', 'Quarterly', 'Yearly', 'Customize'];

  selectedtypes: IHeader = {
    viewValue: 'All',
    value: 'total',
  };

  selectedTables: IHeader[] = [
    {
      id: 1,
      viewValue: 'ODC Access Status',
      value: 'ODCAccessStatus',
    },
  ];

  apiResponse!: {
    onboardingStatus: ChartApiData[];
    offboardingStatus: ChartApiData[];
    onboardingStatusCard: CardData;
    locationTypeCard: CardData;
    onboardingCategories: CardData;
    attendanceCard: CardData;
    LDAPStatusCard: CardData;
  };
  barchartData!: ChartApiData[];

  tableName1: string = 'Summary of Status - All Locations';
  tableName2: string = 'Location-based Status - OFFSHORE';
  tableName3: string = 'Location-based Status - ONSITE';

  cardColorValue1 = '#358590';
  cardColorValue2 = '#6f8032da';
  cardColorValue3 = '#83477b';

  pageSize = [5, 10, 15];

  yesNoNA = YesNoNA;
  yesNo = YesNo;

  chartLableValues = ChartLableValues;
  onboardingHeaders = OnboardingStatusHeaders;

  projectData = this.dashboardService.dmWiseProjectMap;
  projectStatusHeaders = ProjectStatusHeaders;

  laptopStatusData = this.dashboardService.dmWiseLaptopMap;
  laptopStatusHeaders = LaptopStatusHeaders;
  laptopModalHeaders = LaptopModalHeaders;

  NDAStatusData = this.dashboardService.dmWiseNdaMap;
  NDAStatusHeaders = NDAStatusHeaders;
  NDAModalHeaders = NDAModalHeaders;

  WFHStatusData = this.dashboardService.dmWiseWFHMap;
  WFHStatusDataHeaders = WFHStatusDataHeaders;
  WFHModalHeaders = WFHModalHeaders;

  ODCStatusData = this.dashboardService.dmWiseODCMap;
  ODCStatusDataHeaders = ODCStatusDataHeaders;
  ODCModalHeaders = ODCModalHeaders;

  inductionData = this.dashboardService.dmWiseInductionMap;
  inductionStatusDataHeaders = InductionStatusDataHeaders;
  inductionModalHeaders = AccountInductionModalHeaders;
  barchartData2: ChartApiData[] = [];
  dashBoardDataSubs!: Subscription;

  constructor(
    private dashboardService: DashboardService,
    private toast: NotifierService
  ) {}

  ngOnDestroy(): void {
    this.dashBoardDataSubs.unsubscribe();
  }

  ngOnInit(): void {
    this.onboardingApiCall();
    console.log(this.NDAStatusData);
    
  }

  onboardingtype(event: any) {
    console.log(event);
    console.log(this.selectedtypes.value);
    this.onboardingApiCall();
  }

  onboardingApiCall() {
    this.dashBoardDataSubs = forkJoin({
      onboardingStatus: this.mapOnboardingStatus(),
      offboardingStatus: this.dashboardService.getOffboardingStatus1(),
      onboardingStatusCard: this.dashboardService.getAllStatusesEmployee(),
      locationTypeCard: this.dashboardService.getOnboardingLocationType(),
      onboardingCategories: this.dashboardService.getOnboardingCategories(),
      attendanceCard: this.dashboardService.getAttendanceCard(),
      LDAPStatusCard: this.dashboardService.getLDAPStatusCard(),
    }).subscribe(
      (res) => {
        this.apiResponse = res;
        // console.log(res);
      },
      (error: any) => {
        this.toast.showError('No Data Found');
      }
    );
  }

  mapOnboardingStatus(): Observable<ChartApiData[]> {
    return this.dashboardService.getOnboardingStatus().pipe(
      map((ele) => {
        let data = ele['data'];
        let keys = Object.keys(data);
        let tempData: ChartApiData[] = [];

        keys.forEach((key) => {
          let modifiedKey = key.replace(
            /[A-Z]/g,
            (letter) => `-${letter.toLowerCase()}`
          );
          if (key == 'mandatoryTraining') {
            // let bar: BarchartApiData = new BarchartApiData(
            //   data[key]['Data privacy']['Yes'],
            //   data[key]['Data privacy']['No'],
            //   data[key]['Data privacy']['inProgress'],
            //   data[key]['ISMS']['Yes'],
            //   data[key]['ISMS']['No'],
            //   data[key]['ISMS']['inProgress']
            // );
            // this.barchartData = bar;

            let bar1: ChartApiData = new ChartApiData(
              'Data privacy',
              data[key]['Data privacy']['Yes'],
              data[key]['Data privacy']['No'],
              data[key]['Data privacy']['inProgress']
            );

            let bar2: ChartApiData = new ChartApiData(
              'ISMS',
              data[key]['ISMS']['Yes'],
              data[key]['ISMS']['No'],
              data[key]['ISMS']['inProgress']
            );

            this.barchartData2.push(bar1);
            this.barchartData2.push(bar2);

            this.barchartData = this.barchartData2;
          } else {
            let tempEle: ChartApiData = new ChartApiData(
              modifiedKey,
              data[key]['Yes'],
              data[key]['No'],
              data[key]['NA']
            );

            tempData.push(tempEle);
          }
        });
        return tempData;
      })
    );
  }

  getValuesOfMap(mapObj: Map<number, any>) {
    return Array.from(mapObj.values());
  }

  setStartAndEndDate() {
    let tempDate = this.startDate as unknown as Date;

    this.startDate = new Date(tempDate.getFullYear(), tempDate.getMonth(), 1)
      .toISOString()
      .slice(0, 10);

    console.log(this.startDate);
  }
}
