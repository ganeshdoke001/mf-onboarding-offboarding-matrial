import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription, forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import { NotifierService } from 'src/app/shared/shared-services/notifier-service/notifier.service';
import { CardData } from '../../dashboardInterfaces/CardData';
import {
  ChartApiData,
} from '../../dashboardInterfaces/ChartApiData';
import { DmData } from '../../dashboardInterfaces/TableElements ';
import { DashboardService } from '../../dashboardServices/dashboard.service';
import { OffboardingService } from '../../dashboardServices/offboarding/offboarding.service';
import {
  YesNoNA,
  YesNo,
  ChartLableValues,
  OffboardingStatusHeaders,
  OffboardingCategories,
  OffboardingTablesList,
  AccountOffboardingStatusHeaders,
  MphasisOffboradingStatusHeaders,
  FedExLDAPIdModalHeaders,
  FedExEmailIdModalHeaders,
  MphasisVPNModalHeaders,
  FedExMVOIPModalHeaders,
  FedExLaptopModalHeaders,
  AnyCustomersuppliedDeviceModalHeaders,
  AccesstoFedExODCModalHeaders,
  MphasisEmailIdModalHeaders,
  MphasisUserIdModalHeaders,
  MphasisLaptopModalHeaders,
  AccesstoMainGateModalHeaders,
  YesNof,
  LaptopoffStatusHeaders,
  SubNotSub,
  AccountoffboardingStatusHeaders,
  MphasisoffboardingStatusHeaders,
} from '../../dashboardUtilities/dashboardUtilities';

@Component({
  selector: 'app-offboarding',
  templateUrl: './offboarding.component.html',
  styleUrls: ['./offboarding.component.scss'],
})
export class OffboardingComponent implements OnInit, OnDestroy {
  // dmApiData: any = []
  tableHeaders: IHeader[] = OffboardingTablesList;
  selected: IHeader[] = [
    {
      id: 1,
      viewValue: 'FedEx LDAP ID De Activated',
      value: 'ldapDeActivated',
    },
  ];
  selectedItems: any;
  tableValues: String[] = [];

  //filter for offboarding
  types: IHeader[] = OffboardingCategories;
  selectedtypes: IHeader = {
    viewValue: 'All',
    value: 'total',
  };
  category!: string;
  statusData!: CardData;
  

  startDate: string = '2022-11-01';
  todayDate = new Date().toISOString().slice(0, 10);
  endDate: string = new Date().toISOString().slice(0, 10);
  selectedFrequency!: string;
  lineLabelValue = 'Total';
  offBoardDataSubs!: Subscription;
  dateFilter: string[] = ['Monthly', 'Quarterly', 'Yearly', 'Customize'];
  apiResponse!: {
    offboardingStatus: ChartApiData[];
    offboardingData:any;
  };

  cardColorValue2 = '#6f8032da';
  pageSize = [5, 10, 15];

  yesNof= YesNof;
  subNotSub=SubNotSub;
  
  chartLableValues = ChartLableValues;
  offboardingHeaders = OffboardingStatusHeaders;
  accountOffboardingHeaders=AccountoffboardingStatusHeaders;
  mphasisOffboardingHeaders=MphasisoffboardingStatusHeaders;
//* DM Headers
  accountOffboardingStatusHeaders=AccountOffboardingStatusHeaders;
  mphasisOffboradingStatusHeaders=MphasisOffboradingStatusHeaders;
  laptopoffStatusHeaders=LaptopoffStatusHeaders;
  //*FedExLDAPId*****
  fedExLDAPIdStatus=this.offboardingService.dMWiseFedExLDAPId;
  fedExLDAPIdModalHeaders=FedExLDAPIdModalHeaders;
  
  //*FedExEmailId
  fedExEmailIdStatus=this.offboardingService.dMWiseFedExEmailId;
  fedExEmailIdModalHeaders=FedExEmailIdModalHeaders;

  //*MphasisVPN
  mphasisVPNStatus=this.offboardingService.dMWiseMphasisVPN;
  mphasisVPNModalHeaders=MphasisVPNModalHeaders;

  //*FedExMVOIP
  fedExMVOIPStatus=this.offboardingService.dMWiseFedExMVOIP;
  fedExMVOIPModalHeaders=FedExMVOIPModalHeaders;

  //*FedExLaptop
  fedExLaptopStatus=this.offboardingService.dMWiseFedExLaptop;
  fedExLaptopModalHeaders=FedExLaptopModalHeaders;

  //*AnyCustomersuppliedDevice
  anyCustomersuppliedDevice=this.offboardingService.dMWiseAnyCustomersuppliedDevice;
  anyCustomersuppliedDeviceModalHeaders=AnyCustomersuppliedDeviceModalHeaders;

  //*AccesstoFedExODC
  accesstoFedExODCStatus=this.offboardingService.dMWiseAccesstoFedExODC;
  accesstoFedExODCModalHeaders=AccesstoFedExODCModalHeaders;

  //*MphasisEmailId
  mphasisEmailIdStatus=this.offboardingService.dMWiseMphasisEmailId;
  mphasisEmailIdModalHeaders=MphasisEmailIdModalHeaders;

  //*MphasisUserId
  mphasisUserIdStatus=this.offboardingService.dMWiseMphasisUserId;
  mphasisUserIdModalHeaders=MphasisUserIdModalHeaders;

  //*MphasisLaptop
  mphasisLaptopStatus=this.offboardingService.dMWiseMphasisLaptop;
  mphasisLaptopModalHeaders=MphasisLaptopModalHeaders;

  //*AccesstoMainGate
  accesstoMainGate=this.offboardingService.dMWiseAccesstoMainGate;
  accesstoMainGateModalHeaders=AccesstoMainGateModalHeaders;

 
  constructor(
    private toast: NotifierService,
    private offboardingService:OffboardingService,
    private cd: ChangeDetectorRef
  ) {}
  
 

  ngOnDestroy(): void {
    this.offBoardDataSubs.unsubscribe();
  }

  ngOnInit(): void {
    console.log(this.selectedtypes.value);
    console.log(this.fedExLDAPIdStatus);
    this.category = this.selectedtypes.value;
    this.offboardingApiCall();
  }
  
  onElementChange(event: any) {
    // console.log(event);
    console.log(this.selected);

    // for (var key in this.selected) {
    //   this.selectedItems = this.selected[key].value;

    //   this.tableValues.push(this.selectedItems);
    //   console.log(this.tableValues);
    // }
  }

  offBoardingtype(event: any) {
    console.log(event);
    console.log(this.selectedtypes.value);
   // this.offboardingApiCall();
  }
  onSubmit() {
    this.category = this.selectedtypes.value;
    this.offboardingApiCall();
    
  }
  offboardingApiCall() {
    this.offBoardDataSubs = forkJoin({
      offboardingStatus: this.mapOffboardingStatus(this.selectedtypes.value),
      offboardingData:this.offboardingService.getAllStatusesEmployeeOffboarding(this.category),
    
    }).subscribe(
      (res) => {
        this.apiResponse = res;
        this.cd.detectChanges();
      },
      (error: any) => {
        this.toast.showError('No Data Found');
      }
    );
  }

  mapOffboardingStatus(category: string): Observable<ChartApiData[]> {
    return this.offboardingService.getOffboardingStatus(category).pipe(
      map((ele) => {
        let data = ele['data'][0];
        let keys = Object.keys(data);
        let tempData: ChartApiData[] = [];

        keys.forEach((key) => {
          let modifiedKey = key.replace(
            /[A-Z]/g,
            (letter) => `-${letter.toLowerCase()}`
          );
          console.log(data[key]);

          if (key == 'Category') {
            console.log(data[key]);

            let card: CardData = {
              label: 'Offboarding Status',
              data: data[key],
            };
            this.statusData = card;
            console.log(this.statusData);
          } else {
            let tempEle: ChartApiData = new ChartApiData(
              modifiedKey,
              data[key]['Deactivated'],
              data[key]['Activated'],
              data[key]['NA']
            );

            tempData.push(tempEle);
            console.log(tempData);
          }
        });
        return tempData;
      })
    );
  }

  getValuesOfMap(mapObj: Map<number, any>) {
    return Array.from(mapObj.values());
  }

  setStartAndEndDate() {
    let tempDate = this.startDate as unknown as Date;

    this.startDate = new Date(tempDate.getFullYear(), tempDate.getMonth(), 1)
      .toISOString()
      .slice(0, 10);

    console.log(this.startDate);
  }

  //table dropdown
  showTable() {}
}
