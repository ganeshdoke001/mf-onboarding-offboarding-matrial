import { Component, OnInit } from '@angular/core';
import { CardData } from '../../dashboardInterfaces/CardData';
import { InformationSecurityDataHeaders } from '../../dashboardUtilities/dashboardUtilities';

@Component({
  selector: 'app-info-sec',
  templateUrl: './info-sec.component.html',
  styleUrls: ['./info-sec.component.scss'],
})
export class InfoSecComponent implements OnInit {
  selectedFrequency: string = '';
  displayMontly: boolean = false;

  informationHeaders = InformationSecurityDataHeaders;
  informationData: {
    email: string;
    empName: string;
    empID: number;
    attestationcompletionstatus: string;
  }[] = [
    {
      empName: 'chiranjeevi',
      email: 'chiranjeevi@mphasis.com',
      empID: 2452920,
      attestationcompletionstatus: 'Completed',
    },
    {
      empName: 'sai kumar',
      email: 'sai@mphasis.com',
      empID: 2452921,
      attestationcompletionstatus: 'Completed',
    },
    {
      empName: 'vamsi',
      email: 'vamsi@mphasis.com',
      empID: 2452931,
      attestationcompletionstatus: 'Completed',
    },
    {
      empName: 'pranavi',
      email: 'pranavi@mphasis.com',
      empID: 2452920,
      attestationcompletionstatus: 'Not Completed',
    },
    {
      empName: 'venkat',
      email: 'venkat@mphasis.com',
      empID: 2452921,
      attestationcompletionstatus: 'Completed',
    },
    {
      empName: 'kumar',
      email: 'kumar@mphasis.com',
      empID: 2452931,
      attestationcompletionstatus: 'Not Completed',
    },
    {
      empName: 'Teja',
      email: 'Teja@mphasis.com',
      empID: 2452991,
      attestationcompletionstatus: 'Completed',
    },
    {
      empName: 'Shashi',
      email: 'Shashi@mphasis.com',
      empID: 2452935,
      attestationcompletionstatus: 'Completed',
    },
    {
      empName: 'Dheera',
      email: 'Dheera@mphasis.com',
      empID: 2452925,
      attestationcompletionstatus: 'Not Completed',
    },
    {
      empName: 'Ganesh',
      email: 'ganesh@mphasis.com',
      empID: 2452911,
      attestationcompletionstatus: 'Completed',
    },
  ];
  constructor() {}

  ngOnInit(): void {}
  cardColorValue1 = '#83477b';

  cardDataValues1: CardData = {
    label: 'Information Security Attestation Status',
    data: {
      total: 53,
      completed: 30,
      'not Completed': 23,
    },
  };
  ok() {
    console.log('ssss');
  }

  dateFilter1: string[] = ['Monthly'];
}
