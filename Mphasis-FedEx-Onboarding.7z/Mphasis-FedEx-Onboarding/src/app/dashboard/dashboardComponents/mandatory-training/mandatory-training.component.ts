import { Component, OnInit } from '@angular/core';
import { CardData } from '../../dashboardInterfaces/CardData';
import { InformationSecurityDataHeaders, mandatoryDataHeaders } from '../../dashboardUtilities/dashboardUtilities';

import { MandatoryTrainingService } from '../../dashboardServices/mandatoryTraining/mandatory-training.service';
import { IMandatoryTrainingTable } from '../../dashboardInterfaces/TableElements ';

@Component({
  selector: 'app-mandatory-training',
  templateUrl: './mandatory-training.component.html',
  styleUrls: ['./mandatory-training.component.scss']
})
export class MandatoryTrainingComponent implements OnInit {

  selectedFrequency: string = '';
  displayMontly: boolean = false;
  mandatoryHeaders = mandatoryDataHeaders;
  mandatoryData!: IMandatoryTrainingTable[];
  constructor(private mandatoryService : MandatoryTrainingService) { }

  ngOnInit(): void {
    // this.productService.getProductsSmall().then(data => (this. = data));

    this.mandatoryService.getMandatoryTrainingStatusTableData().subscribe((data:IMandatoryTrainingTable[])=>{
      this.mandatoryData = data;
    })

  }
  cardColorValue1 = '#6f8032da';

  cardDataValues1: CardData = {
    label: 'Mandatory Training Status',
    data: {
      total: 53,
      completed: 30,
      'not Completed': 23,
    },

  };
  dateFilter1: string[] = ['Monthly'];


}







