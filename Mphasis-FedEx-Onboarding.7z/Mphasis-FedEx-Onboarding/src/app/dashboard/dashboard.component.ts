import { BlockScrollStrategy, Overlay } from '@angular/cdk/overlay';
import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { FormControl, NgControl } from '@angular/forms';
import { MAT_SELECT_SCROLL_STRATEGY } from '@angular/material/select';
import { forkJoin, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { NotifierService } from '../shared/shared-services/notifier-service/notifier.service';
import { CardData } from './dashboardInterfaces/CardData';
import {
  BarchartApiData,
  ChartApiData,
} from './dashboardInterfaces/ChartApiData';
import { DashboardService } from './dashboardServices/dashboard.service';
import {
  AccountInductionModalHeaders,
  ChartLableValues,
  InductionStatusDataHeaders,
  LaptopModalHeaders,
  LaptopStatusHeaders,
  NDAModalHeaders,
  NDAStatusHeaders,
  ODCModalHeaders,
  ODCStatusDataHeaders,
  OnboardingStatusHeaders,
  ProjectStatusHeaders,
  WFHModalHeaders,
  WFHStatusDataHeaders,
  YesNo,
  YesNoNA,
} from './dashboardUtilities/dashboardUtilities';

// export function scrollFactory(overlay: Overlay): () => BlockScrollStrategy {
//   return () => overlay.scrollStrategies.block();
// }

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  // providers: [
  //   {
  //     provide: MAT_SELECT_SCROLL_STRATEGY,
  //     useFactory: scrollFactory,
  //     deps: [Overlay],
  //   },
  // ],
})
export class DashboardComponent implements OnInit, OnDestroy {
  // dmApiData: any = []

  //quaterly
  // alive: boolean = true;
  control: FormControl = new FormControl();
  year!: number;
  yearDefault = new Date().getFullYear();
  quarterDefault = 'Q' + (1 + Math.floor(new Date().getMonth() / 3));
  quarter: string | undefined;
  showQuarter: boolean = true;
  year10!: number;
  @ViewChild(NgControl, { static: false, read: ElementRef })
  controlID!: ElementRef;
  options: { value: string; months: string[] }[] = [
    { value: 'Q1', months: ['Jan ', 'Feb ', 'Mar'] },
    { value: 'Q2', months: ['Apr ', 'May ', 'Jun'] },
    { value: 'Q3', months: ['Jul ', 'Aug ', 'Sep'] },
    { value: 'Q4', months: ['Oct ', 'Nov ', 'Dec'] },
  ];
  //quaterly

  barchartData2: ChartApiData[] = [];
  minDate!: string;
  startDate: string = '2022-11-01';
  monthDate!: string;
  yearDate = this.yearDefault;
  todayDate = new Date().toISOString().slice(0, 10);
  endDate: string = new Date().toISOString().slice(0, 10);
  selectedFrequency!: string;
  lineLabelValue = 'Total';
  dashBoardDataSubs!: Subscription;
  Filter: string[] = ['Monthly', 'Quarterly', 'Yearly', 'Customize'];
  apiResponse!: {
    onboardingStatus: ChartApiData[];
    offboardingStatus: ChartApiData[];
    onboardingStatusCard: CardData;
    attendanceCard: CardData;
    LDAPStatusCard: CardData;
  };
  barchartData!: ChartApiData[];

  tableName1: string = 'Summary of Status - All Locations';
  tableName2: string = 'Location-based Status - OFFSHORE';
  tableName3: string = 'Location-based Status - ONSITE';

  cardColorValue1 = '#358590';
  cardColorValue2 = '#6f8032da';
  cardColorValue3 = '#83477b';

  pageSize = [5, 10, 15];

  yesNoNA = YesNoNA;
  yesNo = YesNo;

  chartLableValues = ChartLableValues;
  onboardingHeaders = OnboardingStatusHeaders;

  projectData = this.dashboardService.dmWiseProjectMap;
  projectStatusHeaders = ProjectStatusHeaders;

  laptopStatusData = this.dashboardService.dmWiseLaptopMap;
  laptopStatusHeaders = LaptopStatusHeaders;
  laptopModalHeaders = LaptopModalHeaders;

  NDAStatusData = this.dashboardService.dmWiseNdaMap;
  NDAStatusHeaders = NDAStatusHeaders;
  NDAModalHeaders = NDAModalHeaders;

  WFHStatusData = this.dashboardService.dmWiseWFHMap;
  WFHStatusDataHeaders = WFHStatusDataHeaders;
  WFHModalHeaders = WFHModalHeaders;

  ODCStatusData = this.dashboardService.dmWiseODCMap;
  ODCStatusDataHeaders = ODCStatusDataHeaders;
  ODCModalHeaders = ODCModalHeaders;

  inductionData = this.dashboardService.dmWiseInductionMap;
  inductionStatusDataHeaders = InductionStatusDataHeaders;
  inductionModalHeaders = AccountInductionModalHeaders;

  constructor(
    private dashboardService: DashboardService,
    private toast: NotifierService
  ) {}

  ngOnDestroy(): void {
    this.dashBoardDataSubs.unsubscribe();
  }

  ngOnInit(): void {
    this.dashboardApiCall();
  }

  dashboardApiCall() {
    this.dashBoardDataSubs = forkJoin({
      onboardingStatus: this.mapOnboardingStatus(),
      offboardingStatus: this.dashboardService.getOffboardingStatus1(),
      onboardingStatusCard: this.dashboardService.getAllStatusesEmployee(),
      attendanceCard: this.dashboardService.getAttendanceCard(),
      LDAPStatusCard: this.dashboardService.getLDAPStatusCard(),
    }).subscribe(
      (res) => {
        this.apiResponse = res;
        // console.log(res);
      },
      (error: any) => {
        this.toast.showError('No Data Found');
      }
    );
  }

  mapOnboardingStatus(): Observable<ChartApiData[]> {
    return this.dashboardService.getOnboardingStatus().pipe(
      map((ele) => {
        let data = ele['data'];
        let keys = Object.keys(data);
        let tempData: ChartApiData[] = [];

        keys.forEach((key) => {
          let modifiedKey = key.replace(
            /[A-Z]/g,
            (letter) => `-${letter.toLowerCase()}`
          );
          if (key == 'mandatoryTraining') {
            // let bar: BarchartApiData = new BarchartApiData(
            //   data[key]['Data privacy']['Yes'],
            //   data[key]['Data privacy']['No'],
            //   data[key]['Data privacy']['inProgress'],
            //   data[key]['ISMS']['Yes'],
            //   data[key]['ISMS']['No'],
            //   data[key]['ISMS']['inProgress']
            // );

            let bar1: ChartApiData = new ChartApiData(
              'Data privacy',
              data[key]['Data privacy']['Yes'],
              data[key]['Data privacy']['No'],
              data[key]['Data privacy']['inProgress']
            );

            let bar2: ChartApiData = new ChartApiData(
              'ISMS',
              data[key]['ISMS']['Yes'],
              data[key]['ISMS']['No'],
              data[key]['ISMS']['inProgress']
            );

            this.barchartData2.push(bar1);
            this.barchartData2.push(bar2);

            this.barchartData = this.barchartData2;
          } else {
            let tempEle: ChartApiData = new ChartApiData(
              modifiedKey,
              data[key]['Yes'],
              data[key]['No'],
              data[key]['NA']
            );

            tempData.push(tempEle);
          }
        });
        return tempData;
      })
    );
  }

  selectDateRange() {
    console.log('demo');
    // Filter: string[] = [ 'Monthly','Quarterly', 'Yearly', 'Customize'];
    if (this.selectedFrequency == 'Quarterly') {
      let month = 0;
      if (this.quarter == 'Q1') {
        month = 0;
      } else if (this.quarter == 'Q2') {
        month = 3;
      } else if (this.quarter == 'Q3') {
        month = 6;
      } else {
        month = 9;
      }
      this.startDate = new Date(this.year, month, 2).toISOString().slice(0, 10);
      this.endDate = new Date(this.year, month + 3, 1)
        .toISOString()
        .slice(0, 10);
    } else if (this.selectedFrequency == 'Monthly') {
      this.startDate = new Date(this.monthDate).toISOString().slice(0, 10);
      console.log(this.startDate);

      this.endDate = new Date(
        new Date(this.monthDate).getFullYear(),
        new Date(this.monthDate).getMonth() + 1,
        1
      )
        .toISOString()
        .slice(0, 10);
      console.log(this.endDate);
    } else if (this.selectedFrequency == 'Yearly') {
      console.log('yearly');
      console.log([this.yearDate]);
      console.log(new Date(this.yearDate.toString()).getFullYear());
      this.startDate = new Date(
        new Date(this.yearDate.toString()).getFullYear() - 1,
        11,
        33
      )
        .toISOString()
        .slice(0, 10);
      console.log(this.startDate);
      this.endDate = new Date(
        new Date(this.yearDate.toString()).getFullYear(),
        11,
        32
      )
        .toISOString()
        .slice(0, 10);
      console.log(this.endDate);
    }

    this.dashboardService.fromDate = this.startDate;
    this.dashboardService.toDate = this.endDate;

    this.dashboardApiCall();
  }
  getValuesOfMap(mapObj: Map<number, any>) {
    return Array.from(mapObj.values());
  }

  setStartAndEndDate() {
    let tempDate = this.startDate as unknown as Date;

    this.startDate = new Date(tempDate.getFullYear(), tempDate.getMonth(), 1)
      .toISOString()
      .slice(0, 10);

    console.log(this.startDate);
  }

  //quaterly
  changeYear(year: number) {
    this.year = year || this.yearDefault;
    this.quarter = this.quarter || this.quarterDefault;
    this.control.setValue(this.quarter + ' ' + this.year || this.yearDefault, {
      emitEvent: false,
    });
  }
  changeShowQuarter() {
    this.showQuarter = !this.showQuarter;
    if (!this.showQuarter)
      this.year10 = this.year
        ? 10 * Math.floor(this.year / 10)
        : 10 * Math.floor(this.yearDefault / 10);
  }
  click(quarter: string, drop: { close: () => void }) {
    this.quarter = quarter;
    this.year = this.year || this.yearDefault;
    this.control.setValue(this.quarter + ' ' + this.year, { emitEvent: false });
    drop.close();
    this.selectDateRange();
  }
  //quaterly
}
