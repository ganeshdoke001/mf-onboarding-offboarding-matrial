import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { TableModule } from 'primeng/table';
import { MultiSelectModule } from 'primeng/multiselect';
import { DropdownModule } from 'primeng/dropdown';
import { AccordionModule } from 'primeng/accordion';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { DashboardService } from './dashboardServices/dashboard.service';
import { FilterService } from 'primeng/api';
import { SharedModule } from '../shared/shared.module';
import { AttendanceBarComponent } from './dashboardTemplates/attendance-bar/attendance-bar.component';
import { BarChartComponent } from './dashboardTemplates/bar-chart/bar-chart.component';
import { BarLineChartComponent } from './dashboardTemplates/bar-line-chart/bar-line-chart.component';
import { PieChartComponent } from './dashboardTemplates/pie-chart/pie-chart.component';
import { StatusCardComponent } from './dashboardTemplates/status-card/status-card.component';
import { DialogModule } from 'primeng-lts/dialog';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OnboardingComponent } from './dashboardComponents/onboarding/onboarding.component';
import { OffboardingComponent } from './dashboardComponents/offboarding/offboarding.component';
import { DmWiseTableComponent } from './dashboardTemplates/dm-wise-table/dm-wise-table.component';
import { InfoSecComponent } from './dashboardComponents/info-sec/info-sec.component';
import { BasicTableComponent } from './dashboardTemplates/basic-table/basic-table.component';
import { OrgChartComponent } from './dashboardTemplates/org-chart/org-chart.component';
import { BgVerificationComponent } from './dashboardComponents/bg-verification/bg-verification.component';
import { CustomDatePickerComponent } from './dashboardTemplates/custom-date-picker/custom-date-picker.component';
import { OnboardingService } from './dashboardServices/onboarding/onboarding.service';
import { OffboardingService } from './dashboardServices/offboarding/offboarding.service';
import { BgVerificationService } from './dashboardServices/bg-verification/bg-verification.service';
import { InfoSecService } from './dashboardServices/info-sec/info-sec.service';
import { DmWiseTableOffboardingComponent } from './dashboardTemplates/dm-wise-table-offboarding/dm-wise-table-offboarding.component';
import { MandatoryTrainingComponent } from './dashboardComponents/mandatory-training/mandatory-training.component';
import { MandatoryTrainingService } from './dashboardServices/mandatoryTraining/mandatory-training.service';


// import { ChartsModule } from 'ng2-charts';

@NgModule({
  declarations: [
    DashboardComponent,
    PieChartComponent,
    BarChartComponent,
    BarLineChartComponent,
    StatusCardComponent,
    AttendanceBarComponent,
    OnboardingComponent,
    OffboardingComponent,
    InfoSecComponent,
    DmWiseTableComponent,
    BasicTableComponent,
    OrgChartComponent,
    CustomDatePickerComponent,
    BgVerificationComponent,
    DmWiseTableOffboardingComponent,
    MandatoryTrainingComponent,
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule,
    HttpClientModule,
    TableModule,
    DialogModule,
    ButtonModule,
    MultiSelectModule,
    DropdownModule,
    NgbModule,
    RadioButtonModule,
    AccordionModule,
  ],
  providers: [DatePipe,
    DashboardService,
    FilterService,
    OnboardingService,
    OffboardingService,
    BgVerificationService,
    InfoSecService,
    HttpClient,
    MandatoryTrainingService
  ],
})
export class DashboardModule {}
