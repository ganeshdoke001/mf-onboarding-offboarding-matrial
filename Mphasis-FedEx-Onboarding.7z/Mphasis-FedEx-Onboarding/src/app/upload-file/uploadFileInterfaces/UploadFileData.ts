import { compileDeclareClassMetadata } from '@angular/compiler';

export class ExcelUploadApiResponse {
  empNumber!: number | null;
  employeeName!: string;
  dateOfJoining!: string;
  location1!: string;
  location2!: string;
  posLocName!: string;
  posOnsiteOffsure!: string;
  gradeDesc!: string;
  pm!: string;
  dmEmpName!: string;
  status!: string;
  fedExLDAPIdDeactivated!: string;
  fedExEmailIdDeactivated!: string;
  mphasisVPNDeactivated!: string;
  fedExMVOIPDeactivated!: string;
  fedExLaptopHandedOver!: string;
  anyCustomerSuppliedDevicesHandedOver!: string;
  accessToFedExODCDeactivated!: string;
  mphasisEmailIdDeactivated!: string;
  userIdDeactivated!: string;
  mphasisLaptopHandedOver!: string;
  others!: string;
  accesstoMainGateDeactivated!: string;

  constructor() {
    this.clear();
  }

  clear() {
    this.empNumber = null;
    this.employeeName = '';
    this.dateOfJoining = '';
    this.location1 = '';
    this.location2 = '';
    this.posLocName = '';
    this.posOnsiteOffsure = '';
    this.gradeDesc = '';
    this.dmEmpName = '';
    this.pm = '';
    this.status = '';
    this.fedExLDAPIdDeactivated = '';
    this.fedExEmailIdDeactivated = '';
    this.mphasisVPNDeactivated = '';
    this.fedExMVOIPDeactivated = '';
    this.fedExLaptopHandedOver = '';
    this.anyCustomerSuppliedDevicesHandedOver = '';
    this.accessToFedExODCDeactivated = '';
    this.mphasisEmailIdDeactivated = '';
    this.userIdDeactivated = '';
    this.mphasisLaptopHandedOver = '';
    this.others = '';
    this.accesstoMainGateDeactivated = '';
  }
}

export class ExcelTableData {
  id!: number;
  records!: {
    excel: ExcelUploadApiResponse;
    db: ExcelUploadApiResponse;
  };

  constructor(id: number) {
    this.id = id;
    this.records = {
      excel: new ExcelUploadApiResponse(),
      db: new ExcelUploadApiResponse(),
    };
  }
}

export class ExcelErrors {
  code: string;
  row?: number | null;
  column?: number | null;
  message: string;
  timestamp: string;

  constructor(
    code: string,
    message: string,
    timestamp: string,
    row?: number,
    column?: number
  ) {
    this.code = code ?? null;
    this.row = row ?? null;
    this.column = column ?? null;
    this.message = message ?? null;
    this.timestamp = timestamp ?? null;
  }
}
