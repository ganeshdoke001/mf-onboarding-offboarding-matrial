import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { ExcelUploadApiResponse } from '../uploadFileInterfaces/UploadFileData';

@Injectable({
  providedIn: 'root',
})
export class UploadFileService {
  private baseURL = 'http://localhost:8181';
  private bgvURL = 'http://localhost:8182';
  private dummyURL = 'http://localhost:3001';
  constructor(private httpClient: HttpClient) {}
  attachFile(file: File, category: string): Observable<any> {
    let formData = new FormData();
    formData.append('file', file);
    console.log(formData);
    if (category === 'HCR' || category === 'WPS') {
      return this.httpClient.post<any>(
        `${this.baseURL}/excel/validate`,
        formData,
        {
          headers: {
            'File-Type': category,
          },
        }
      );
    } else if (category === 'BGV') {
      return this.httpClient.post<any>(
        `${this.bgvURL}/background-verification/api/v1/excel/validate`,
        formData,
        {
          headers: {
            'File-Type': category,
          },
        }
      );
    } else if (category === 'infoSecurityAttestation') {
      return this.httpClient.post<any>(
        `${this.baseURL}/info-security/api/v1/excel/validate`,
        formData,
        {
          headers: {
            'File-Type': category,
          },
        }
      );
    }
    return this.httpClient.post<any>(
      `${this.baseURL}/excel/validate`,
      formData,
      {
        headers: {
          'File-Type': category,
        },
      }
    );
  }
  submitFile(file: File, category: string): Observable<any> {
    let formData = new FormData();
    formData.append('file', file);
    console.log(formData);
    if (category === 'HCR' || category === 'WPS') {
      return this.httpClient.post<any>(
        `${this.baseURL}/excel/upload`,
        formData,
        {
          params: {
            operation: 'upload',
          },
          headers: {
            'File-Type': category,
          },
        }
      );
    } else if (category === 'BGV') {
      return this.httpClient.post<any>(
        `${this.bgvURL}/background-verification/api/v1/excel/upload`,
        formData,
        {
          params: {
            operation: 'upload',
          },
          headers: {
            'File-Type': category,
          },
        }
      );
    } else if (category === 'infoSecurityAttestation') {
      return this.httpClient.post<any>(
        `${this.baseURL}/info-security/api/v1/excel/upload`,
        formData,
        {
          params: {
            operation: 'upload',
          },
          headers: {
            'File-Type': category,
          },
        }
      );
    }
    return this.httpClient.post<any>(`${this.baseURL}/excel/upload`, formData, {
      params: {
        operation: 'upload',
      },
      headers: {
        'File-Type': category,
      },
    });
  }
  // public getFileById(id: number) {
  //   return this.httpClient.get('http://localhost:8181/getFile/' + id);
  // }
  getUpdateData(): Observable<ExcelUploadApiResponse[]> {
    return this.httpClient.get<ExcelUploadApiResponse[]>(
      this.dummyURL + '/update'
    );
  }
}
