import { IHeader } from 'src/app/shared/shared-models/sharedModel';

export const updateHeadersHCR: IHeader[] = [
  { value: 'empNumber', viewValue: 'Employee Id' },
  { value: 'status', viewValue: 'Source' },
  { value: 'empName', viewValue: 'Employee Name' },
  { value: 'dateOfJoining', viewValue: 'Date Of Joining' },
  { value: 'location1', viewValue: 'Location 1' },
  { value: 'location2', viewValue: 'Location 2' },
  { value: 'posLocName', viewValue: 'POS Location' },
  { value: 'posOnsiteOffsure', viewValue: 'POS Onsite-Offshore' },
  { value: 'gradeDesc', viewValue: 'Grade Description' },
  { value: 'pm', viewValue: 'Project Manager' },
  { value: 'dmempName', viewValue: 'Delivery Manager' },
];

export const updateHeadersWPS: IHeader[] = [
  { value: 'empNumber', viewValue: 'Employee Id' },
  { value: 'status', viewValue: 'Source' },
  { value: 'fedExLDAPIdDeactivated', viewValue: 'LDAPId Deactivated' },
  { value: 'fedExEmailIdDeactivated', viewValue: 'fedEx EmailID Deactivated' },
  { value: 'mphasisVPNDeactivated', viewValue: 'Mphasis VPN Deactivated' },
  { value: 'fedExMVOIPDeactivated', viewValue: 'FedEx MVOIP Deactivated' },
  { value: 'fedExLaptopHandedOver', viewValue: 'FedEx Laptop HandedOver' },
  {
    value: 'anyCustomerSuppliedDevicesHandedOver',
    viewValue: 'Any Customer Supplied Devices Handed Over',
  },
  {
    value: 'accessToFedExODCDeactivated',
    viewValue: 'Access To FedEx ODC Deactivated',
  },
  {
    value: 'mphasisEmailIdDeactivated',
    viewValue: 'Mphasis EmailID Deactivated',
  },
  { value: 'userIdDeactivated', viewValue: 'User ID Deactivated' },
  { value: 'mphasisLaptopHandedOver', viewValue: 'Mphasis Laptop Handed Over' },
  { value: 'others', viewValue: 'Others' },

  {
    value: 'accesstoMainGateDeactivated',
    viewValue: 'Access to Main Gate Deactivated',
  },
];

export const ErrorTableHeaders: IHeader[] = [
  { value: 'code', viewValue: 'Error Code' },

  { value: 'row', viewValue: ' Excel Row Number' },
  { value: 'column', viewValue: 'Column' },
  { value: 'message', viewValue: 'Error Message' },
  { value: 'timestamp', viewValue: 'Time Stamp' },
];

export const FileCategories = [
  { value: 'HCR', viewValue: 'HCR' },
  { value: 'WPS', viewValue: 'WPS' },
  { value: 'FLEX', viewValue: 'FLEX' },
  { value: 'NDA', viewValue: 'FedEx NDA' },
  { value: 'CRO', viewValue: 'CRO' },
  { value: 'IND', viewValue: 'FedEx INDUCTION' },
  { value: 'BGV', viewValue: 'BACKGROUND VERIFICATION' },
];
