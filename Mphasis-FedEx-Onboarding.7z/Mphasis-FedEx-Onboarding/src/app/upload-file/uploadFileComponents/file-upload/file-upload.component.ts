import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { IHeader } from 'src/app/shared/shared-models/sharedModel';
import { NotifierService } from 'src/app/shared/shared-services/notifier-service/notifier.service';
import { OverlayService } from 'src/app/shared/shared-services/overlay-service/overlay.service';
import {
  ExcelErrors,
  ExcelTableData,
  ExcelUploadApiResponse,
} from '../../uploadFileInterfaces/UploadFileData';
import { UploadFileService } from '../../uploadFileServices/upload-file.service';
import {
  ErrorTableHeaders,
  FileCategories,
  updateHeadersHCR,
  updateHeadersWPS,
} from '../../uploadFileUtilities/uploadFileConstants';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
})
export class FileUploadComponent implements OnInit, OnDestroy {
  loadedFile!: File | null;
  errors: string[] = [];
  validFile: boolean = false;
  selectedCategory!: string | null;
  // hidden: boolean[] = [];
  fileCategories = FileCategories;
  attachFileSubs!: Subscription;
  submitFileSubs!: Subscription;
  errorTableData: ExcelErrors[] = [];

  apiData: ExcelUploadApiResponse[] = [];
  headings: IHeader[] = [];
  updateData: ExcelTableData[] = [];
  newRecords: ExcelUploadApiResponse[] = [];
  nullRecords: ExcelUploadApiResponse[] = [];

  showValue = true;

  errorTableHeaders = ErrorTableHeaders;

  @ViewChild('fileInput') fileInputContent!: ElementRef;

  constructor(
    public fileService: UploadFileService,
    private toast: NotifierService,
    private overlay: OverlayService
  ) {}
  ngOnDestroy(): void {
    this.attachFileSubs?.unsubscribe();
    this.submitFileSubs?.unsubscribe();
  }

  ngOnInit(): void {
    // this.getUpdateData();
  }

  loadFile(event: any) {
    console.log('loadFile Called');
    this.loadedFile = event.target.files[0];
    console.log(this.loadedFile);

    this.validateFile(this.loadedFile as File, this.selectedCategory as string);
    event.target.files = null;
  }

  validateFile(uploadFile: File, uploadCategory: string) {
    this.overlay.setOverlayStatus(true);
    this.errors = [];
    this.errorTableData = [];
    this.updateData = [];
    if (uploadFile) {
      this.attachFileSubs = this.fileService
        .attachFile(uploadFile, uploadCategory)
        .subscribe(
          (res) => {
            console.log(res);
            this.loadUpdateData(res);
            this.validFile = true;
            this.overlay.setOverlayStatus(false);
          },

          (err: HttpErrorResponse) => {
            this.errorTableData = [];
            this.validFile = false;
            if (Array.isArray(err.error)) {
              this.errorTableData = err.error;
              console.log(this.errorTableData);
              this.toast.showError(this.errorTableData[0].code);
            } else {
              this.toast.showError(err.error.message);
            }
            this.overlay.setOverlayStatus(false);
          }
        );
    } else {
      // alert('Please select a file first');
    }
  }

  onSubmit(uploadFile: File | null, uploadCategory: string) {
    if (uploadFile) {
      this.submitFileSubs = this.fileService
        .submitFile(uploadFile, uploadCategory)
        .subscribe(
          (res) => {
            this.updateData = [];
            this.headings = [];
            this.newRecords = [];
            if (res.errorDesc) {
              this.errors.push(res.errorDesc);
              this.validFile = false;
            } else {
              this.validFile = false;
            }
            console.log(this.errors);
            this.toast.showSuccess('File Uploaded');
            // this.loadedFile = null;
            this.resetFileInputField();
          },

          (error) => {
            // this.errors = error.message;
            console.log(this.errors);
            this.errors.push(error.message);
            if (error) {
              this.validFile = false;
            }
          }
        );
    } else {
      this.toast.showWarning('Please select a file first');
    }
  }

  raiseToast() {
    this.toast.showInfo('Please select the category');
  }

  resetFileInputField() {
    console.log(this.fileInputContent.nativeElement.files);

    this.fileInputContent.nativeElement.value = '';
    console.log(this.fileInputContent.nativeElement.files);
    this.selectedCategory = null;
  }

  loadUpdateData(apiData: ExcelUploadApiResponse[]) {
    this.updateData = [];
    this.headings = [];
    this.newRecords = [];
    this.nullRecords = [];
    let filteredData: ExcelUploadApiResponse[] = [];

    filteredData = apiData.filter((record): boolean => {
      return record.status == 'Excel' || record.status == 'DB';
    });

    this.newRecords = apiData.filter((record): boolean => {
      return record.status == 'New';
    });

    this.nullRecords = apiData.filter((record): boolean => {
      return record.status == null;
    });

    console.log(this.newRecords);

    if (filteredData.length == 0) {
      this.validFile = true;
      return;
    }

    console.log(filteredData);
    let mySet = new Set<number>();

    filteredData.forEach((record: ExcelUploadApiResponse) => {
      if (!mySet.has(record.empNumber as number)) {
        mySet.add(record.empNumber as number);
      }
    });

    console.log(mySet);

    mySet.forEach((ele: number) => {
      let key = ele;
      let val = filteredData.filter((record): boolean => {
        return record.empNumber == key;
      });

      let temp = {
        id: key,
        records: {
          excel: val.filter((record): boolean => {
            return record.status == 'Excel';
          })[0],
          db: val.filter((record): boolean => {
            return record.status == 'DB';
          })[0],
        },
      };
      this.updateData.push(temp as ExcelTableData);
    });

    console.log(this.updateData);
    console.log(this.updateData.length);
    // Object.keys(filteredData[0]).forEach((key) => {
    //   let temp = {
    //     value: key,
    //     viewValue: key.split(/(?=[A-Z])/)?.join(' '),
    //   };
    //   console.log(temp);

    //   this.headings.push(temp);
    // });

    if (this.selectedCategory == 'HCR') {
      this.headings = updateHeadersHCR;
    } else if (this.selectedCategory == 'WPS') {
      this.headings = updateHeadersWPS;
    }

    if (this.nullRecords.length == 0) {
      this.validFile = true;
    }
    console.log(this.headings);
  }
}
