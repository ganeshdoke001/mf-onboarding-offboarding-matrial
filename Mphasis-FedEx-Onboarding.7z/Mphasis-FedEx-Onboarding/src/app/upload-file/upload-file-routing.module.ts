import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UploadFileComponent } from './upload-file.component';
import { FileUploadComponent } from './uploadFileComponents/file-upload/file-upload.component';

const routes: Routes = [
  // { path: '', component: UploadFileComponent },
  {
    path: 'upload-file',
    component: FileUploadComponent,
  },
  { path: '', redirectTo: 'upload-file', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UploadFileRoutingModule {}
