import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UploadFileRoutingModule } from './upload-file-routing.module';
import { UploadFileComponent } from './upload-file.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileUploadComponent } from './uploadFileComponents/file-upload/file-upload.component';
import { UploadFileService } from './uploadFileServices/upload-file.service';
import { NotifierService } from '../shared/shared-services/notifier-service/notifier.service';
import { SharedModule } from '../shared/shared.module';
import { TableModule } from 'primeng/table';
@NgModule({
  declarations: [UploadFileComponent, FileUploadComponent],
  imports: [
    CommonModule,
    UploadFileRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    TableModule,
    SharedModule,
  ],
  providers: [UploadFileService, HttpClient, NotifierService],
})
export class UploadFileModule {}
