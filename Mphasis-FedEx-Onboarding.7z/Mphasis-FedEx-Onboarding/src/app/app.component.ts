import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { OverlayService } from './shared/shared-services/overlay-service/overlay.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Mphasis-FedEx-Onboarding';
  showFlag!: boolean;
  overlaySubs!: Subscription;

  constructor(private overlay: OverlayService) {}

  ngOnDestroy(): void {
    this.overlaySubs.unsubscribe();
  }

  ngOnInit(): void {
    this.overlaySubs = this.overlay.overlayStatus$.subscribe((status) => {
      this.showFlag = status;
    });
  }
}
