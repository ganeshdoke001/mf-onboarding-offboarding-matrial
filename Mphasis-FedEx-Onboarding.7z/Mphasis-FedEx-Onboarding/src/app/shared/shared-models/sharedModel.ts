export interface IHeader {
  value: string;
  viewValue: string;
  filter?: boolean;
  id?: number;
  viewTittle?: string;
  backgroundColor?: string;
  width?: string;
  height?: string;
  rowSpan?: number;
}


export interface IResponseModel{
  notification:any
  highestSeverity:string;
  data:any
}
