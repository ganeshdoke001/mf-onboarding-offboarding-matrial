import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-notifier-component',
  templateUrl: './notifier-component.component.html',
  styleUrls: ['./notifier-component.component.scss'],
})
export class NotifierComponentComponent implements OnInit {
  constructor(private toast: ToastrService) {}

  ngOnInit(): void {}
}
