import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class NotifierService {
  constructor(private toast: ToastrService) {}

  showSuccess(message: any, title: any = 'Success') {
    this.toast.success(message, title);
  }

  showError(message: any, title: any = 'Error') {
    this.toast.error(message, title);
  }

  showInfo(message: any, title: any = 'Info') {
    this.toast.info(message, title);
  }

  showWarning(message: any, title: any = 'Warning') {
    this.toast.warning(message, title);
  }
}
