import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class OverlayService {
  private overlayStatus = new Subject<boolean>();

  overlayStatus$ = this.overlayStatus.asObservable();
  constructor() {}

  setOverlayStatus(status: boolean) {
    this.overlayStatus.next(status);
  }
}
