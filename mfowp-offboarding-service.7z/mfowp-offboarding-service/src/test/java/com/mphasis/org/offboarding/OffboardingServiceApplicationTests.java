//package com.mphasis.org.offboarding;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class OffboardingServiceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
