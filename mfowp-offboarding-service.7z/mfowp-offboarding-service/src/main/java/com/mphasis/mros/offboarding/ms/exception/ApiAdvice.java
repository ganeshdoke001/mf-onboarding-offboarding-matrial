package com.mphasis.mros.offboarding.ms.exception;



import java.io.FileNotFoundException;
import java.nio.file.FileAlreadyExistsException;



import javax.servlet.http.HttpServletRequest;



import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice()
public class ApiAdvice extends ResponseEntityExceptionHandler {



   @ExceptionHandler(FileNotFoundException.class)
    public ResponseEntity<Object> handleFileNotFoundException(HttpServletRequest req, FileNotFoundException ex) {
        ErrorResponse response = new ErrorResponse();
        response.setCode("FILE");
        response.setMessage(ExcelConstants.FILE_NOT_FOUND);
        return buildResponseEntity(response, HttpStatus.NOT_FOUND);



   }



   @ExceptionHandler(FileAlreadyExistsException.class)
    public ResponseEntity<Object> handleFileAlreadyExistsException(HttpServletRequest req,
            FileAlreadyExistsException ex) {
        ErrorResponse response = new ErrorResponse();
        response.setCode("FILE");
        response.setMessage(ExcelConstants.FILE_ALREADY_EXISTS);
        return buildResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);



   }



	/*
	 * @ExceptionHandler(FileStorageException.class) public ResponseEntity<Object>
	 * handleFileStorageException(HttpServletRequest req, FileStorageException ex) {
	 * ErrorResponse response = new ErrorResponse(); response.setCode("FILE");
	 * response.setMessage(ExcelConstants.FILE_NOT_STORED); return
	 * buildResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
	 * 
	 * 
	 * 
	 * }
	 */



   @ExceptionHandler(FileNotAvailableException.class)
    public ResponseEntity<Object> handleFileNotAvailableException(HttpServletRequest req, FileNotAvailableException ex) {
        ErrorResponse response = new ErrorResponse();
        response.setCode("FILE");
        response.setMessage(ExcelConstants.FILE_NOT_AVBL);
        return buildResponseEntity(response, HttpStatus.NOT_FOUND);



   }



//	/*
//	 * @ExceptionHandler(InvalidFileException.class) public ResponseEntity<Object>
//	 * handleInvalidFileException(HttpServletRequest req, InvalidFileException ex) {
//	 * ErrorResponse response = new ErrorResponse(); response.setCode("FILE");
//	 * response.setMessage(ExcelConstants.INVALID_FILE); return
//	 * buildResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
//	 * 
//	 * 
//	 * 
//	 * }
//	 */
   
   @ExceptionHandler(EmployeeNotFoundException.class)
   public ResponseEntity<Object> handleEmployeeNotFoundException(HttpServletRequest req, EmployeeNotFoundException ex) {
       ErrorResponse response = new ErrorResponse();
       response.setCode("EMPLOYEE");
       response.setMessage(ExcelConstants.Employee_Not_Found);
       return buildResponseEntity(response, HttpStatus.NOT_FOUND);



  }
   
   @ExceptionHandler(IncorrectDateFormat.class)
   public ResponseEntity<Object> handleIncorrectDateFormat(HttpServletRequest req, IncorrectDateFormat ex) {
       ErrorResponse response = new ErrorResponse();
       response.setCode("DATE");
       response.setMessage(ExcelConstants.INCORRECT_DATE_FORMAT);
       return buildResponseEntity(response, HttpStatus.FORBIDDEN);



  }
   
   @ExceptionHandler(HttpClientErrorException.class)
   public ResponseEntity<Object> handleHttpClientErrorException(HttpServletRequest req, HttpClientErrorException ex) {
       ErrorResponse response = new ErrorResponse();
       response.setCode("SUMMARY API");
       response.setMessage(ex.getMessage());
       return buildResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
  }

   private ResponseEntity<Object> buildResponseEntity(ErrorResponse errorResponse, HttpStatus status) {
        return new ResponseEntity<Object>(errorResponse, status);
    }
}