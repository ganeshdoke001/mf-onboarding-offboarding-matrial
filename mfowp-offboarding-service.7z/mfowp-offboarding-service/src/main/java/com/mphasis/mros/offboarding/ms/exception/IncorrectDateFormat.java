package com.mphasis.mros.offboarding.ms.exception;

public class IncorrectDateFormat  extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public IncorrectDateFormat(String message) {
        super(message);
    }

    public IncorrectDateFormat(String message, String string) {
        super(message);
    }

}
