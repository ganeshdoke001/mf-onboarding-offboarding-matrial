package com.mphasis.mros.offboarding.ms.exception;

public class ExcelConstants {

	public static final String FILE_NOT_FOUND = "File is not available in DB";
	
	public static final String FILE_NOT_AVBL = "Please Upload a Valid Xlsx file";
		 
	public static final String FILE_ALREADY_EXISTS =  "File already exists , please upload another file";

	public static final String INVALID_FILE = " The Uploaded file is not an Excel File, please upload a Excel file only.";

	public static final String FILE_NOT_STORED= "Could not store file, Please try again!";
	
	public static final String FILE_DELETE= "File is deleted with ID";
	
	public static final String FILES_DELETE= "multiple selected files deleted...";

	public static final String INVALID_MSG ="must not be null";
	
	public static final String Wps ="Wps";
	
	public static final String Yes ="yes";
	
	public static final String No ="no";

	public static final String NA ="NA";

	public static final String Deactive ="Deactived";
	
	public static final String Active ="Actived";
	
	public static final String Submitted ="Submitted";
	
	public static final String Not_Submitted ="Not Submitted";
	
	public static final String Primary ="Primary";
	
	public static final String Optional ="Optional";
	
	public static final String Employee_Not_Found ="Employee not available with given employee number.";
	
	public static final String Organization = "Mphasis";
	
	public static final String INCORRECT_DATE_FORMAT = "Date Format Should be(yyyy-MM-dd)";
	
	public static final String No_Data_Found_Date ="No Data found in the given Date";
	
	public static final String No_Data_Found_DM ="No Data found for the given delivery manager Id";

	public static final String Org_FedEx ="FedEx";
	
	public static final String Org_Mphasis ="Mphasis";
	
	public static final String HIGH_SEVERITY_SUCCESS = "Success";
	
	public static final String HIGH_SEVERITY_FAILURE = "Failure";


	
	}

