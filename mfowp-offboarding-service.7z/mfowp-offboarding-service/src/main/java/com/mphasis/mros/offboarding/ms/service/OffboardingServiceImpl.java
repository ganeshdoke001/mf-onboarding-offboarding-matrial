package com.mphasis.mros.offboarding.ms.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedRuntimeException;
import org.springframework.core.NestedRuntimeException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.mongodb.client.result.DeleteResult;
import com.mphasis.mros.offboarding.ms.dto.BaseResponse;
import com.mphasis.mros.offboarding.ms.dto.OffboardingDTO;
import com.mphasis.mros.offboarding.ms.entity.EmployeeEntity;
import com.mphasis.mros.offboarding.ms.entity.Offboarding;
import com.mphasis.mros.offboarding.ms.exception.EmployeeNotFoundException;
import com.mphasis.mros.offboarding.ms.exception.ExcelConstants;
import com.mphasis.mros.offboarding.ms.exception.IncorrectDateFormat;
import com.mphasis.mros.offboarding.ms.helper.ServiceHelper;
import com.mphasis.mros.offboarding.ms.repository.OffboardingRepository;
import com.mphasis.mros.offboarding.ms.vo.EmpTransitionResponseVO;
import com.mphasis.mros.offboarding.ms.vo.NotificationVO;
import com.mphasis.mros.offboarding.ms.vo.OffboardingSummaryVO;

@Service
public class OffboardingServiceImpl implements OffboardingService {

	@Autowired
	OffboardingRepository offboardingRepository;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	BaseResponse response;

	@Override
	public ResponseEntity<?> getDetailsByEmpNumber(int empNumber) {
		System.out.println("empNumber" + empNumber);
		Query queryObj = new Query(Criteria.where("employeeNumber").is(empNumber));
		List<Offboarding> result = mongoTemplate.find(queryObj, Offboarding.class);
		List<Offboarding> accountOffboarding = new ArrayList<Offboarding>();
		OffboardingDTO offboardingDTO = new OffboardingDTO();
		try {
			if (result.size() > 0) {
				offboardingDTO.setEmployeeNumber(empNumber);
				for (Offboarding res : result) {
					if (res.getOrganisation().equalsIgnoreCase(ExcelConstants.Organization)) {
						offboardingDTO.setMphasisOffboarding(res);
					} else {
						accountOffboarding.add(res);
					}
					offboardingDTO.setAccountOffboardings(accountOffboarding);
				}
			}
			System.out.println("offboardingDTO::::" + offboardingDTO);
			return new ResponseEntity<Object>(offboardingDTO, new HttpHeaders(), HttpStatus.OK);
		} catch (Exception e) {
			throw new EmployeeNotFoundException(ExcelConstants.Employee_Not_Found);

		}

	}

	@Override
	public ResponseEntity<?> deleteDetailsByEmpNumber(int empNumber) {
		Query queryObj = new Query(Criteria.where("employeeNumber").is(empNumber));
		DeleteResult result = mongoTemplate.remove(queryObj, Offboarding.class);
		if (result.getDeletedCount() > 0) {
			String resp = "Employee with number" + empNumber + " is deleted";
			return new ResponseEntity<String>(resp, HttpStatus.OK);
		} else {
			throw new EmployeeNotFoundException(ExcelConstants.Employee_Not_Found);
		}
	}

	@Override
	public ResponseEntity<?> offboardingDashboardCount(String startDate, String endDate, String filter)
			throws IncorrectDateFormat {
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			Date startDate1 = null;
			Date endDate1 = null;
			startDate1 = formatter.parse(startDate);
			endDate1 = formatter.parse(endDate);
			System.out.println(filter);
			Query queryObj = new Query();
			if (filter.equalsIgnoreCase("total")) {
				queryObj.addCriteria(new Criteria()
						.orOperator(Criteria.where("organisation").is(ExcelConstants.Org_FedEx),
								Criteria.where("organisation").is(ExcelConstants.Org_Mphasis))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1)));
			} else {
				queryObj.addCriteria(new Criteria()
						.orOperator(Criteria.where("organisation").is(ExcelConstants.Org_FedEx),
								Criteria.where("organisation").is(ExcelConstants.Org_Mphasis))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1),
								Criteria.where("separationReason").is(filter)));
			}
			List<Offboarding> result = mongoTemplate.find(queryObj, Offboarding.class);
			if (result.size() > 0) {
				Map<String, Object> finalMap = new LinkedHashMap<String, Object>();
				finalMap = offboardingFilter(result);

				///////////////////////////////
				List<Map<String, Object>> finalResponse = new ArrayList<>();
				finalResponse.add(finalMap);
				List<Integer> dmIDs = new ArrayList<Integer>();
				for (Offboarding res : result) {
					dmIDs.add(res.getDeliveryManagerId());
				}
				System.out.println(dmIDs);
				Set<Integer> setDmIDs = new LinkedHashSet<>();
				setDmIDs.addAll(dmIDs);
				System.out.println(setDmIDs);
				List<Integer> listDmId = new ArrayList<>(setDmIDs);
				for (int i = 0; i < listDmId.size(); i++) {
					List<Offboarding> empList = null;
					int dmId = listDmId.get(i);
					Map<String, Object> responseObj1 = new HashMap<String, Object>();
					empList = result.stream().filter(a -> (a.getDeliveryManagerId() == (dmId)))
							.collect(Collectors.toList());
					Map<String, Object> finalMap1 = new LinkedHashMap<String, Object>();
					if (empList.size() > 0) {
						finalMap1 = offboardingFilter(empList);
					}

					responseObj1.put("DeliveryManagerId", listDmId.get(i));
					responseObj1.put("Analytics", finalMap1);
					finalResponse.add(responseObj1);

				}
				empTransitionResponseVO.setData(finalResponse);
				empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.HIGH_SEVERITY_SUCCESS,
						ExcelConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.No_Data_Found_Date,
						ExcelConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException | ParseException e) {
			empTransitionResponseVO.setData(responseObj);
			empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.INCORRECT_DATE_FORMAT,
					ExcelConstants.HIGH_SEVERITY_FAILURE, "403", "APP"));
			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.FORBIDDEN);
		}
	}

	@Override
	public ResponseEntity<?> offboardingDashboardDetails(int dmEmpNumber, String startDate, String endDate,
			String filter) {
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			Date startDate1 = null;
			Date endDate1 = null;
			startDate1 = formatter.parse(startDate);
			endDate1 = formatter.parse(endDate);
			System.out.println(filter);
			Query queryObj = new Query();
			if (filter.equalsIgnoreCase("total") && dmEmpNumber > 0) {// single DM total
				queryObj.addCriteria(new Criteria()
						.orOperator(Criteria.where("organisation").is(ExcelConstants.Org_FedEx),
								Criteria.where("organisation").is(ExcelConstants.Org_Mphasis))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1),
								Criteria.where("deliveryManagerId").is(dmEmpNumber)));
			}
			if (!filter.equalsIgnoreCase("total") && dmEmpNumber > 0) {// single DM filter
				queryObj.addCriteria(new Criteria()
						.orOperator(Criteria.where("organisation").is(ExcelConstants.Org_FedEx),
								Criteria.where("organisation").is(ExcelConstants.Org_Mphasis))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1),
								Criteria.where("separationReason").is(filter),
								Criteria.where("deliveryManagerId").is(dmEmpNumber)));
			}
			if (!filter.equalsIgnoreCase("total") && dmEmpNumber == 0) {// admin wise filter
				queryObj.addCriteria(new Criteria()
						.orOperator(Criteria.where("organisation").is(ExcelConstants.Org_FedEx),
								Criteria.where("organisation").is(ExcelConstants.Org_Mphasis))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1),
								Criteria.where("separationReason").is(filter)));
			}
			if (filter.equalsIgnoreCase("total") && dmEmpNumber == 0) {// admin wise total
				queryObj.addCriteria(new Criteria()
						.orOperator(Criteria.where("organisation").is(ExcelConstants.Org_FedEx),
								Criteria.where("organisation").is(ExcelConstants.Org_Mphasis))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1)));
			}

			List<Offboarding> result = mongoTemplate.find(queryObj, Offboarding.class);

			if (result.size() > 0) {
				List<Integer> dmIDs = new ArrayList<Integer>();
				for (Offboarding res : result) {
					dmIDs.add(res.getDeliveryManagerId());
				}
				System.out.println(dmIDs);
				Set<Integer> setDmIDs = new LinkedHashSet<>();
				setDmIDs.addAll(dmIDs);
				System.out.println(setDmIDs);
				List<Integer> listDmId = new ArrayList<>(setDmIDs);

				List<Map<String, Object>> finalResponse = new ArrayList<>();

				if (dmEmpNumber != 0) {
					List<Offboarding> empList = null;
					Map<String, Object> responseObj = new HashMap<String, Object>();
					List<Integer> empIDs = new ArrayList<Integer>();
					if (result != null && !result.isEmpty()) {
						empList = result.stream().filter(a -> (a.getDeliveryManagerId() == (dmEmpNumber)))
								.collect(Collectors.toList());
					}
					for (Offboarding res : empList) {
						empIDs.add(res.getEmployeeNumber());
					}
					System.out.println(empIDs);
					Set<Integer> setEmpIDs = new LinkedHashSet<>();// TODO
					setEmpIDs.addAll(empIDs);
					System.out.println(setEmpIDs);
					List<Integer> listEmpId = new ArrayList<>(setEmpIDs);
					List<Map<String, Object>> empResponse = new ArrayList<>();

					for (int i = 0; i < listEmpId.size(); i++) {
						List<Offboarding> fedExList = null;
						List<Offboarding> mphasisList = null;
						int EmpId = listEmpId.get(i);
						Map<String, Object> responseObj1 = new LinkedHashMap<String, Object>();
						if (empList != null && !empList.isEmpty()) {
							fedExList = empList.stream()
									.filter(a -> (a.getEmployeeNumber() == (EmpId)
											&& a.getOrganisation().equalsIgnoreCase("FedEx")))
									.collect(Collectors.toList());
							mphasisList = empList.stream()
									.filter(a -> (a.getEmployeeNumber() == (EmpId)
											&& a.getOrganisation().equalsIgnoreCase("Mphasis")))
									.collect(Collectors.toList());
							responseObj1.put("employeeNumber", listEmpId.get(i));
							responseObj1.put("fedExData", fedExList);
							responseObj1.put("mphasisData", mphasisList);
							empResponse.add(responseObj1);
						}

					}

					responseObj.put("DeliveryManagerId", dmEmpNumber);
					responseObj.put("DmEmpList", empResponse);
					finalResponse.add(responseObj);
				} else {
					for (int i = 0; i < listDmId.size(); i++) {
						List<Offboarding> empList = null;
						int dmId = listDmId.get(i);
						Map<String, Object> responseObj = new HashMap<String, Object>();
						List<Integer> empIDs = new ArrayList<Integer>();
						if (result != null && !result.isEmpty()) {
							empList = result.stream().filter(a -> (a.getDeliveryManagerId() == (dmId)))
									.collect(Collectors.toList());
							for (Offboarding res : empList) {
								empIDs.add(res.getEmployeeNumber());
							}
							System.out.println(empIDs);
							Set<Integer> setEmpIDs = new LinkedHashSet<>();// TODO
							setEmpIDs.addAll(empIDs);
							System.out.println(setEmpIDs);
							List<Integer> listEmpId = new ArrayList<>(setEmpIDs);
							List<Map<String, Object>> empResponse = new ArrayList<>();

							for (int j = 0; j < listEmpId.size(); j++) {
								List<Offboarding> fedExList = null;
								List<Offboarding> mphasisList = null;
								int EmpId = listEmpId.get(j);
								Map<String, Object> responseObj1 = new LinkedHashMap<String, Object>();
								if (empList != null && !empList.isEmpty()) {
									fedExList = empList.stream()
											.filter(a -> (a.getEmployeeNumber() == (EmpId)
													&& a.getOrganisation().equalsIgnoreCase("FedEx")))
											.collect(Collectors.toList());
									mphasisList = empList.stream()
											.filter(a -> (a.getEmployeeNumber() == (EmpId)
													&& a.getOrganisation().equalsIgnoreCase("Mphasis")))
											.collect(Collectors.toList());
									responseObj1.put("employeeNumber", listEmpId.get(j));
									responseObj1.put("fedExData", fedExList);
									responseObj1.put("mphasisData", mphasisList);
									empResponse.add(responseObj1);
								}

							}
							responseObj.put("DeliveryManagerId", listDmId.get(i));
							responseObj.put("DmEmpList", empResponse);
							finalResponse.add(responseObj);
						}

					}
				}
				empTransitionResponseVO.setData(finalResponse);
				empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.HIGH_SEVERITY_SUCCESS,
						ExcelConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setData(result);
				empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.No_Data_Found_DM,
						ExcelConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException | ParseException e) {
			empTransitionResponseVO.setData(null);
			empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.INCORRECT_DATE_FORMAT,
					ExcelConstants.HIGH_SEVERITY_FAILURE, "403", "APP"));
			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.FORBIDDEN);
		}
	}

	public Map<String, Object> offboardingFilter(List<Offboarding> result) {
		Map<String, Object> StatusCount = ServiceHelper.getStatusCount(result);
		Map<String, Object> FedExLDAPIdCount = ServiceHelper.getFedExLDAPIdCount(result);
		Map<String, Object> FedExEmailIdCount = ServiceHelper.getFedExEmailIdCount(result);
		Map<String, Object> MphasisVPNCount = ServiceHelper.getMphasisVPNCount(result);
		Map<String, Object> FedExMVOIPCount = ServiceHelper.getFedExMVOIPCount(result);
		Map<String, Object> FedExLaptopCount = ServiceHelper.getFedExLaptopCount(result);
		Map<String, Object> AnyCustomersuppliedDeviceCount = ServiceHelper.getAnyCustomersuppliedDeviceCount(result);
		Map<String, Object> AccesstoFedExODCCount = ServiceHelper.getAccesstoFedExODCCount(result);
		Map<String, Object> MphasisEmailIdCount = ServiceHelper.getMphasisEmailIdCount(result);
		Map<String, Object> MphasisUserIdCount = ServiceHelper.getMphasisUserIdCount(result);
		Map<String, Object> MphasisLaptopCount = ServiceHelper.getMphasisLaptopCount(result);
		Map<String, Object> AccesstoMainGateCount = ServiceHelper.getAccesstoMainGateCount(result);
		Map<String, Object> finalMap = new LinkedHashMap<String, Object>();
		finalMap.put("Category", StatusCount);
		finalMap.put("FedExLDAPId", FedExLDAPIdCount);
		finalMap.put("FedExEmailId", FedExEmailIdCount);
		finalMap.put("FedExMVOIP", FedExMVOIPCount);
		finalMap.put("FedExLaptop", FedExLaptopCount);
		finalMap.put("AnyCustomersuppliedDevice", AnyCustomersuppliedDeviceCount);
		finalMap.put("AccesstoFedExODC", AccesstoFedExODCCount);
//			if (!filter.equalsIgnoreCase("Out-Transfer")) {
		finalMap.put("MphasisVPN", MphasisVPNCount);
		finalMap.put("MphasisEmailId", MphasisEmailIdCount);
		finalMap.put("MphasisUserId", MphasisUserIdCount);
		finalMap.put("MphasisLaptop", MphasisLaptopCount);
		finalMap.put("AccesstoMainGate", AccesstoMainGateCount);
//			}
		return finalMap;
	}

	@Override
	public ResponseEntity<?> fetchEmployeeList(String startDate, String endDate, String Status) {
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			Date startDate1 = null;
			Date endDate1 = null;
			startDate1 = formatter.parse(startDate);
			endDate1 = formatter.parse(endDate);
			System.out.println(Status);
			Query queryObj = new Query();
			if (Status.equalsIgnoreCase("Account Offboarding")) {
				new Criteria();
				queryObj.addCriteria(Criteria.where("offboardingStatus").is("Account Offboarding")
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1)));
			}
			if (Status.equalsIgnoreCase("Mphasis Offboarding")) {
				new Criteria();
				queryObj.addCriteria(Criteria.where("offboardingStatus").is("Mphasis Offboarding")
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1)));
			}
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			if (result.size() > 0) {
				responseObj.put("Emplist", result);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.HIGH_SEVERITY_SUCCESS,
						ExcelConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setData(result);
				empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.No_Data_Found_DM,
						ExcelConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}

		} catch (DateTimeParseException | ParseException e) {
			empTransitionResponseVO.setData(null);
			empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.INCORRECT_DATE_FORMAT,
					ExcelConstants.HIGH_SEVERITY_SUCCESS, "403", "APP"));
			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.FORBIDDEN);
		}
	}

	@Override
	public ResponseEntity<?> employeeOffboardingSummary(int dmEmpNumber, String startDate, String endDate,
			String filter, String Status) throws HttpClientErrorException {
		
		Map<String,Object> summaryResponse= new HashMap<>();
		Map<String,Object> summaryResponse1= new HashMap<>();
		Map<String,Object> notification = new HashMap<>();
		OffboardingSummaryVO offboardingSummaryVO = new OffboardingSummaryVO();
		try {
		List<Map<String,Object>> offboardingSummaryVOList = new ArrayList<>();
		 RestTemplate restTemplate= new RestTemplate();
		 NotificationVO notificationVO = new NotificationVO(ExcelConstants.HIGH_SEVERITY_SUCCESS,ExcelConstants.HIGH_SEVERITY_SUCCESS, "200", "APP");
		 notification.put("Notification", notificationVO);
		 offboardingSummaryVOList.add(notification);
		 String uri = "http://localhost:8083/app/employeeList/"+dmEmpNumber+"?startDate="+startDate+"&endDate="+endDate+"&Status="+Status;
		 offboardingSummaryVO = restTemplate.getForObject(uri, OffboardingSummaryVO.class);
		 summaryResponse.put("EmployeeDetails", offboardingSummaryVO);
		 offboardingSummaryVOList.add(summaryResponse);
		 
		String uri1 = "http://localhost:8085/api/v1/offboardings/analytics/dashboard/data/"+dmEmpNumber+"?startDate="+startDate+"&filter="+filter+"&endDate="+endDate;
		 OffboardingSummaryVO offboardingSummaryVO1 = new OffboardingSummaryVO();
		 offboardingSummaryVO1 = restTemplate.getForObject(uri1, OffboardingSummaryVO.class);
		 summaryResponse1.put("OffboardingDetails", offboardingSummaryVO1);
		offboardingSummaryVOList.add(summaryResponse1);
		 return new ResponseEntity<List<Map<String,Object>>>(offboardingSummaryVOList,HttpStatus.OK);
	    
		}
		catch (HttpClientErrorException| ResourceAccessException e) {
	    	 List<Map<String,Object>> offboardingSummaryVOList = new ArrayList<>();
	    	 NotificationVO notificationVO = new NotificationVO( e.getMessage(),"Success", "404", "APP");
			 notification.put("Notification", notificationVO);
			 offboardingSummaryVOList.add(notification);	 
//	throw new HttpClientErrorException(HttpStatus.NOT_FOUND,"Somethig went wrong");
			 return new ResponseEntity<List<Map<String,Object>>>(offboardingSummaryVOList,HttpStatus.NOT_FOUND);
	}
}

}
