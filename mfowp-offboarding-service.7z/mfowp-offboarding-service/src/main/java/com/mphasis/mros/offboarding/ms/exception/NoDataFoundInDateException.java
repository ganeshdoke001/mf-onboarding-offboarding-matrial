package com.mphasis.mros.offboarding.ms.exception;

public class NoDataFoundInDateException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public NoDataFoundInDateException(String message) {
        super(message);
    }

    public NoDataFoundInDateException(String message, Throwable cause) {
        super(message, cause);
    }}
