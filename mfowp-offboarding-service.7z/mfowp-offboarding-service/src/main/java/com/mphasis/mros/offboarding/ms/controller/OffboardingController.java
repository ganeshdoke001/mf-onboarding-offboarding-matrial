package com.mphasis.mros.offboarding.ms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.mros.offboarding.ms.service.OffboardingService;
import com.mphasis.mros.offboarding.ms.vo.OffboardingSummaryVO;

@EnableMongoRepositories(basePackages = {"com.mphasis.mros.offboarding.ms.repository"})
@RestController
@CrossOrigin("*")
@RequestMapping("api/v1/offboardings")
public class OffboardingController {
	
	@Autowired
	OffboardingService offboardingService;
	
	@GetMapping("/getEmployeeDetails/{empNumber}")
	public ResponseEntity<?> getDetailsByEmpNumber(@PathVariable int empNumber) {
		return offboardingService.getDetailsByEmpNumber(empNumber);
		
	}
	
	@DeleteMapping("/deleteEmpDetails/{empNumber}")
	public ResponseEntity<?> deleteDetailsByEmpNumber(@PathVariable int empNumber){
		return offboardingService.deleteDetailsByEmpNumber(empNumber);
		
	}

	@GetMapping("/analytics/dashboard/count")
	public ResponseEntity<?> offboardingDashboardCount(@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate,@RequestParam("filter") String filter) {
		
		return offboardingService.offboardingDashboardCount(startDate, endDate,filter);
	}
	
	@GetMapping("/analytics/dashboard/data/{dmEmpNumber}")
	public ResponseEntity<?> offboardingDashboardDetails(@PathVariable(value = "dmEmpNumber",required = false) int dmEmpNumber,@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate,@RequestParam("filter") String filter) {
//		OffboardingSummaryVO offboardingSummaryVO=new OffboardingSummaryVO();
//		offboardingSummaryVO.add(1.b(offboardingDetails));
		return offboardingService.offboardingDashboardDetails(dmEmpNumber,startDate, endDate,filter);
	}
	
	@GetMapping("/employeeList")
	public ResponseEntity<?> fetchEmployeeList(@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate,@RequestParam("Status") String Status) {
//		OffboardingSummaryVO offboardingSummaryVO=new OffboardingSummaryVO();
//		offboardingSummaryVO.add(1.a(employeeList));
		
		return offboardingService.fetchEmployeeList(startDate, endDate,Status);
	}
}
