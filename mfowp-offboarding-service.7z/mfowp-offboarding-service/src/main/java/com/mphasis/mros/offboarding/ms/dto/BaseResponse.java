package com.mphasis.mros.offboarding.ms.dto;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mphasis.mros.offboarding.ms.entity.Offboarding;

@Component
public class BaseResponse {
	private int deliveryManagerId;
	private Map<String, List<Offboarding>>offBoardgingList;

	
	public int getDeliveryManagerId() {
		return deliveryManagerId;
	}
	public void setDeliveryManagerId(int deliveryManagerId) {
		this.deliveryManagerId = deliveryManagerId;
	}
	public Map<String, List<Offboarding>> getOffBoardgingList() {
		return offBoardgingList;
	}
	public void setOffBoardgingList(Map<String, List<Offboarding>> empDetailsMap) {
		this.offBoardgingList = empDetailsMap;
	}
	public BaseResponse(int deliveryManagerId, Map<String, List<Offboarding>> offBoardgingList) {
		super();
		this.deliveryManagerId = deliveryManagerId;
		this.offBoardgingList = offBoardgingList;
	}
	public BaseResponse() {
		super();
	}
	
	
	

}
