package com.mphasis.mros.offboarding.ms.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "Offboarding")
public class Offboarding {
	
	@Id
	private String offboardingId;
	private int employeeNumber;
	private int deliveryManagerId;
	private int projectManagerId;
	private String organisation;
	private Date releaseDate;
	private String email;
	private String userId;
	private Access access;
	private String vpn;
	private List<Asset> assets;
	private Asset otherAssets;
	private String separationReason;
	private String status;
	public String getOffboardingId() {
		return offboardingId;
	}
	public void setOffboardingId(String offboardingId) {
		this.offboardingId = offboardingId;
	}
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public int getDeliveryManagerId() {
		return deliveryManagerId;
	}
	public void setDeliveryManagerId(int deliveryManagerId) {
		this.deliveryManagerId = deliveryManagerId;
	}
	public int getProjectManagerId() {
		return projectManagerId;
	}
	public void setProjectManagerId(int projectManagerId) {
		this.projectManagerId = projectManagerId;
	}
	public String getOrganisation() {
		return organisation;
	}
	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Access getAccess() {
		return access;
	}
	public void setAccess(Access access) {
		this.access = access;
	}
	public String getVpn() {
		return vpn;
	}
	public void setVpn(String vpn) {
		this.vpn = vpn;
	}
	public List<Asset> getAssets() {
		return assets;
	}
	public void setAssets(List<Asset> assets) {
		this.assets = assets;
	}
	public Asset getOtherAssets() {
		return otherAssets;
	}
	public void setOtherAssets(Asset otherAssets) {
		this.otherAssets = otherAssets;
	}
	public String getSeparationReason() {
		return separationReason;
	}
	public void setSeparationReason(String separationReason) {
		this.separationReason = separationReason;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Offboarding(String offboardingId, int employeeNumber, int deliveryManagerId, int projectManagerId,
			String organisation, Date releaseDate, String email, String userId, Access access, String vpn,
			List<Asset> assets, Asset otherAssets, String separationReason, String status) {
		super();
		this.offboardingId = offboardingId;
		this.employeeNumber = employeeNumber;
		this.deliveryManagerId = deliveryManagerId;
		this.projectManagerId = projectManagerId;
		this.organisation = organisation;
		this.releaseDate = releaseDate;
		this.email = email;
		this.userId = userId;
		this.access = access;
		this.vpn = vpn;
		this.assets = assets;
		this.otherAssets = otherAssets;
		this.separationReason = separationReason;
		this.status = status;
	}
	public Offboarding() {
		super();
	}
	
	
	
	
}
	

