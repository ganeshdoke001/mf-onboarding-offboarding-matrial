package com.mphasis.mros.offboarding.ms.vo;

public class OffboardingSummaryVO {
	
	private Object data;
	
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	
}
