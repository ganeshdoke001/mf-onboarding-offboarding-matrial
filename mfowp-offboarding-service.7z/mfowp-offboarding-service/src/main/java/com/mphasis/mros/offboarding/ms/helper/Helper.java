package com.mphasis.mros.offboarding.ms.helper;

public enum Helper {
a,b
}

class filter{
	Helper variable;
	public filter(Helper variable) {
		this.variable=variable;
	}
	
	public void analyticsFilter() {
		switch(variable) {
		case a:
		break;
		case b:
		break;
		default:
		break;
		}
	}

}