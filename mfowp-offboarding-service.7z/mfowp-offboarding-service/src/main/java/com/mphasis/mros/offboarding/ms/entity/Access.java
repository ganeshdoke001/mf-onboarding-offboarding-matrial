
package com.mphasis.mros.offboarding.ms.entity;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "Access")
public class Access {
	
	@Id
	private String accessID;
	private String accessName;
	private String accessStatus;
	public Access(String accessID, String accessName, String accessStatus) {
		super();
		this.accessID = accessID;
		this.accessName = accessName;
		this.accessStatus = accessStatus;
	}
	public Access() {
		super();
	}
	@Override
	public String toString() {
		return "Access [accessID=" + accessID + ", accessName=" + accessName + ", accessStatus=" + accessStatus + "]";
	}
	public String getAccessID() {
		return accessID;
	}
	public void setAccessID(String accessID) {
		this.accessID = accessID;
	}
	public String getAccessName() {
		return accessName;
	}
	public void setAccessName(String accessName) {
		this.accessName = accessName;
	}
	public String getAccessStatus() {
		return accessStatus;
	}
	public void setAccessStatus(String accessStatus) {
		this.accessStatus = accessStatus;
	}

	

}
