package com.mphasis.mros.offboarding.ms.dto;

import java.util.List;

import com.mphasis.mros.offboarding.ms.entity.Offboarding;

public class EmpDetails {
	private int employeeNumber;
    private List<Offboarding> mphasisData;
    private List<Offboarding>fedExData;
	
    public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public List<Offboarding> getMphasisData() {
		return mphasisData;
	}
	public void setMphasisData(List<Offboarding> mphasisData) {
		this.mphasisData = mphasisData;
	}
	public List<Offboarding> getFedExData() {
		return fedExData;
	}
	public void setFedExData(List<Offboarding> fedExData) {
		this.fedExData = fedExData;
	}
	public EmpDetails(int employeeNumber, List<Offboarding> mphasisData, List<Offboarding> fedExData) {
		super();
		this.employeeNumber = employeeNumber;
		this.mphasisData = mphasisData;
		this.fedExData = fedExData;
	}
	public EmpDetails() {
		super();
	}
	
    
    
    

}
