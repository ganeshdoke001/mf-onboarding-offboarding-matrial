package com.mphasis.mros.offboarding.ms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.mros.offboarding.ms.service.OffboardingService;

@RestController
@CrossOrigin("*")
@RequestMapping("api/v1/offboardings")
public class SummaryApiController {

	@Autowired
	OffboardingService offboardingService;

	@GetMapping("/employeeOffboardingSummary/{dmEmpNumber}")
	public ResponseEntity<?> employeeOffboardingSummary(@PathVariable(value = "dmEmpNumber",required = false) int dmEmpNumber,@RequestParam("startDate") String startDate,
	 @RequestParam("endDate") String endDate,@RequestParam("filter") String filter,@RequestParam("Status") String Status) {
	return offboardingService.employeeOffboardingSummary(dmEmpNumber, startDate, endDate, filter, Status);
	}

}