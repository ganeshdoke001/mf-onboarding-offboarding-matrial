package com.mphasis.mros.offboarding.ms.service;

import java.text.ParseException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

public interface OffboardingService {
	
	public ResponseEntity<?> getDetailsByEmpNumber(int empNumber);
	
	public ResponseEntity<?> deleteDetailsByEmpNumber(int empNumber);

	public ResponseEntity<?> offboardingDashboardCount(String startDate, String endDate,String filter) ;
	
	public ResponseEntity<?> offboardingDashboardDetails(int dmEmpNumber,String startDate, String endDate,String filter);

	public ResponseEntity<?> fetchEmployeeList(String startDate,String endDate,String Status);
	
	public ResponseEntity<?> employeeOffboardingSummary(int dmEmpNumber,String startDate,String endDate,String filter, String Status); 
	
}
