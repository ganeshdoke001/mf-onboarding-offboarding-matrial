package com.mphasis.mros.offboarding.ms.entity;
import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Employee")
public class EmployeeEntity {
	
	@Id
	@NotNull(message = "EMPLOYE NUMBER::Should not be empty")
	private Integer employeeNumber;

	@NotNull
	@NotEmpty(message = "EMPLOYEE NAME::Should not be empty")
	private String employeeName;

	@NotNull
	@Past(message = "DATE OF JOINING::Should not be empty")
	private Date dateOfJoining;

	// offshore ie. chennai
	@NotNull
	@NotEmpty(message = "LOCATION::Should not be empty")
	private String location;

	// position ie OFFSHORE or ONSHORE
	@NotNull
	@NotEmpty(message = "LOCATION2::Should not be empty")
	private String position;

	// excel POS LOC NAME ie Chennai (IN-CHE08)
	@NotNull
	@NotEmpty(message = "POSITION::Should not be empty")
	private String posLocName;
	
	@NotNull(message = "POSONSITEOFFSHORE::Should not be empty")
	private String posOnsiteOffsure;

	@NotNull
	@NotEmpty(message = "GRADEDESC::Should not be empty")
	private String gradeDescription;

//	@NotNull
//	@NotEmpty(message = "ACCOUNT NAME::Should not be empty")
//	private String accountName;

	@NotNull
	@NotEmpty(message = "DM EMPLOYEE NAME::Should not be empty")
	private String deliveryManagerName;

	@NotNull
	@NotEmpty(message = "PM::Should not be empty")
	private String projectManager;

	private String status;
	
	private Date releaseDate;
	
	private String offboardingStatus;

	public EmployeeEntity(@NotNull(message = "EMPLOYE NUMBER::Should not be empty") Integer employeeNumber,
			@NotNull @NotEmpty(message = "EMPLOYEE NAME::Should not be empty") String employeeName,
			@NotNull @Past(message = "DATE OF JOINING::Should not be empty") Date dateOfJoining,
			@NotNull @NotEmpty(message = "LOCATION::Should not be empty") String location,
			@NotNull @NotEmpty(message = "LOCATION2::Should not be empty") String position,
			@NotNull @NotEmpty(message = "POSITION::Should not be empty") String posLocName,
			@NotNull(message = "POSONSITEOFFSHORE::Should not be empty") String posOnsiteOffsure,
			@NotNull @NotEmpty(message = "GRADEDESC::Should not be empty") String gradeDescription,
			@NotNull @NotEmpty(message = "DM EMPLOYEE NAME::Should not be empty") String deliveryManagerName,
			@NotNull @NotEmpty(message = "PM::Should not be empty") String projectManager, String status,
			Date releaseDate, String offboardingStatus) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.dateOfJoining = dateOfJoining;
		this.location = location;
		this.position = position;
		this.posLocName = posLocName;
		this.posOnsiteOffsure = posOnsiteOffsure;
		this.gradeDescription = gradeDescription;
		this.deliveryManagerName = deliveryManagerName;
		this.projectManager = projectManager;
		this.status = status;
		this.releaseDate = releaseDate;
		this.offboardingStatus = offboardingStatus;
	}

	public Integer getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPosLocName() {
		return posLocName;
	}

	public void setPosLocName(String posLocName) {
		this.posLocName = posLocName;
	}

	public String getPosOnsiteOffsure() {
		return posOnsiteOffsure;
	}

	public void setPosOnsiteOffsure(String posOnsiteOffsure) {
		this.posOnsiteOffsure = posOnsiteOffsure;
	}

	public String getGradeDescription() {
		return gradeDescription;
	}

	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}

	public String getDeliveryManagerName() {
		return deliveryManagerName;
	}

	public void setDeliveryManagerName(String deliveryManagerName) {
		this.deliveryManagerName = deliveryManagerName;
	}

	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getOffboardingStatus() {
		return offboardingStatus;
	}

	public void setOffboardingStatus(String offboardingStatus) {
		this.offboardingStatus = offboardingStatus;
	}

	@Override
	public String toString() {
		return "EmployeeEntity [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName
				+ ", dateOfJoining=" + dateOfJoining + ", location=" + location + ", position=" + position
				+ ", posLocName=" + posLocName + ", posOnsiteOffsure=" + posOnsiteOffsure + ", gradeDescription="
				+ gradeDescription + ", deliveryManagerName=" + deliveryManagerName + ", projectManager="
				+ projectManager + ", status=" + status + ", releaseDate=" + releaseDate + ", offboardingStatus="
				+ offboardingStatus + "]";
	}

	public EmployeeEntity() {
		super();
	}

	
}
