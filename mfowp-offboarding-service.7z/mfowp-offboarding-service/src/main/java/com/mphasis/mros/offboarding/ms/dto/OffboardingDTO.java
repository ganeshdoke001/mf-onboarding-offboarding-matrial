package com.mphasis.mros.offboarding.ms.dto;

import java.util.List;

import com.mphasis.mros.offboarding.ms.entity.Offboarding;

public class OffboardingDTO {
	
	int employeeNumber;
	Offboarding mphasisOffboarding;
	List<Offboarding> accountOffboardings;
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public Offboarding getMphasisOffboarding() {
		return mphasisOffboarding;
	}
	public void setMphasisOffboarding(Offboarding res) {
		this.mphasisOffboarding = res;
	}
	public List<Offboarding> getAccountOffboardings() {
		return accountOffboardings;
	}
	public void setAccountOffboardings(List<Offboarding> accountOffboardings) {
		this.accountOffboardings = accountOffboardings;
	}
	@Override
	public String toString() {
		return "OffboardingDTO [employeeNumber=" + employeeNumber + ", mphasisOffboarding=" + mphasisOffboarding
				+ ", accountOffboardings=" + accountOffboardings + "]";
	}
	

}
