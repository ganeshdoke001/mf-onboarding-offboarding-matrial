package com.mphasis.mros.offboarding.ms.dto;

import java.util.List;

public class ResponseDTO {
	
	private int deliveryManagerId;
	private List<EmpDetails> empDetails;
	
	
	
	public int getDeliveryManagerId() {
		return deliveryManagerId;
	}
	public void setDeliveryManagerId(int deliveryManagerId) {
		this.deliveryManagerId = deliveryManagerId;
	}
	public List<EmpDetails> getEmpDetails() {
		return empDetails;
	}
	public void setEmpDetails(List<EmpDetails> empDetails) {
		this.empDetails = empDetails;
	}
	public ResponseDTO(int deliveryManagerId, List<EmpDetails> empDetails) {
		super();
		this.deliveryManagerId = deliveryManagerId;
		this.empDetails = empDetails;
	}
	public ResponseDTO() {
		super();
	}
	
	
	

}
