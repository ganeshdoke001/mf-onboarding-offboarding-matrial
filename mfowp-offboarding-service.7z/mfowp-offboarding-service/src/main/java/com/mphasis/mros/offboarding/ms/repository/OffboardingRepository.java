package com.mphasis.mros.offboarding.ms.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.mros.offboarding.ms.entity.Offboarding;

@Repository
public interface OffboardingRepository extends MongoRepository<Offboarding,Integer>{
	
	

}
