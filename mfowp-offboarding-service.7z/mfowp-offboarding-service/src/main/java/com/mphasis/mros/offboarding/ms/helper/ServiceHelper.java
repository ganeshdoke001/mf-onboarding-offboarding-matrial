package com.mphasis.mros.offboarding.ms.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.mphasis.mros.offboarding.ms.entity.Offboarding;

public class ServiceHelper {

	public static Map<String, Object> getStatusCount(List<Offboarding> result) {
		List<Offboarding> resignedList = null;
		List<Offboarding> outTransferList = null;
		List<Offboarding> terminatedList = null;
		List<Offboarding> abscondedList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {

				resignedList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
								&& a.getSeparationReason().equalsIgnoreCase("Separated_Resigned")))
						.collect(Collectors.toList());
				responseObj.put("resigned", resignedList.size());
				
				outTransferList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
								&& a.getSeparationReason().equalsIgnoreCase("Out-Transfer")))
						.collect(Collectors.toList());
				responseObj.put("out-transfer", outTransferList.size());
				
				terminatedList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
								&& a.getSeparationReason().equalsIgnoreCase("Separated_Terminated")))
						.collect(Collectors.toList());
				responseObj.put("terminated", terminatedList.size());
				
				abscondedList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
								&& a.getSeparationReason().equalsIgnoreCase("Separated_Absconded")))
						.collect(Collectors.toList());
				responseObj.put("absconded", abscondedList.size());
				responseObj.put("Total",
						resignedList.size() + outTransferList.size() + terminatedList.size() + abscondedList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getFedExLDAPIdCount(List<Offboarding> result) {
		List<Offboarding> LDAPYesList = null;
		List<Offboarding> LDAPNoList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				
				LDAPYesList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
						&& a.getUserId().equalsIgnoreCase("Deactivated"))).collect(Collectors.toList());
				responseObj.put("Deactivated", LDAPYesList.size());
				
				LDAPNoList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
						&& a.getUserId().equalsIgnoreCase("Activated"))).collect(Collectors.toList());
				responseObj.put("Activated", LDAPNoList.size());
				
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getFedExEmailIdCount(List<Offboarding> result) {
		List<Offboarding> FedExEmailIdYesList = null;
		List<Offboarding> FedExEmailIdNoList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				FedExEmailIdYesList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
						&& a.getEmail().equalsIgnoreCase("Deactivated"))).collect(Collectors.toList());
				responseObj.put("Deactivated", FedExEmailIdYesList.size());
				FedExEmailIdNoList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
						&& a.getEmail().equalsIgnoreCase("Activated"))).collect(Collectors.toList());
				responseObj.put("Activated", FedExEmailIdNoList.size());
				
			}

		} catch (Exception e) {
		}
		return responseObj;
	}

	public static Map<String, Object> getMphasisVPNCount(List<Offboarding> result) {
		List<Offboarding> MphasisVPNYesList = null;
		List<Offboarding> MphasisVPNNoList = null;
//		List<Offboarding> MphasisVPNNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				MphasisVPNYesList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
						&& a.getVpn().equalsIgnoreCase("Deactivated"))).collect(Collectors.toList());
				responseObj.put("Deactivated", MphasisVPNYesList.size());
				MphasisVPNNoList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
						&& a.getVpn().equalsIgnoreCase("Activated"))).collect(Collectors.toList());
				responseObj.put("Activated", MphasisVPNNoList.size());
//				MphasisVPNNAList = result.stream().filter(
//						a -> (a.getOrganisation().equalsIgnoreCase("Mphasis") && a.getVpn().equalsIgnoreCase("NA")))
//						.collect(Collectors.toList());
//				responseObj.put("NA", MphasisVPNNAList.size());
			}
		} catch (Exception e) {
		}
		return responseObj;
	}

	public static Map<String, Object> getFedExMVOIPCount(List<Offboarding> result) {
		List<Offboarding> FedExMVOIPYesList = null;
		List<Offboarding> FedExMVOIPNoList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();

		try {
			if (result != null && !result.isEmpty()) {
				FedExMVOIPYesList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
						&& a.getVpn().equalsIgnoreCase("Deactivated"))).collect(Collectors.toList());
				responseObj.put("Deactivated", FedExMVOIPYesList.size());
				FedExMVOIPNoList = result.stream().filter(
						a -> (a.getOrganisation().equalsIgnoreCase("FedEx") && a.getVpn().equalsIgnoreCase("Activated")))
						.collect(Collectors.toList());
				responseObj.put("Activated", FedExMVOIPNoList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getFedExLaptopCount(List<Offboarding> result) {
		List<Offboarding> FedExLaptopYesList = null;
		List<Offboarding> FedExLaptopNoList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				FedExLaptopYesList = result.stream()
						.filter(e -> e.getAssets().stream()
								.anyMatch(a -> (a.getAssetName().equalsIgnoreCase("FedEx Laptop")
										&& a.getAssetStatus().equalsIgnoreCase("Submitted"))))
						.collect(Collectors.toList());
				responseObj.put("Deactivated", FedExLaptopYesList.size());
				FedExLaptopNoList = result.stream()
						.filter(e -> e.getAssets().stream()
								.anyMatch(a -> (a.getAssetName().equalsIgnoreCase("FedEx Laptop")
										&& a.getAssetStatus().equalsIgnoreCase("Not Submitted"))))
						.collect(Collectors.toList());
				responseObj.put("Activated", FedExLaptopNoList.size());
			}
		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getAnyCustomersuppliedDeviceCount(List<Offboarding> result) {
		List<Offboarding> AnyCustomersuppliedDeviceYesList = null;
		List<Offboarding> AnyCustomersuppliedDeviceNoList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				AnyCustomersuppliedDeviceYesList = result.stream()
						.filter(e -> e.getAssets().stream()
								.anyMatch(a -> (a.getAssetName().equalsIgnoreCase("CustomerSuppliedDevice")
										&& a.getAssetStatus().equalsIgnoreCase("Submitted"))))
						.collect(Collectors.toList());
				responseObj.put("Deactivated", AnyCustomersuppliedDeviceYesList.size());
				AnyCustomersuppliedDeviceNoList = result.stream()
						.filter(e -> e.getAssets().stream()
								.anyMatch(a -> (a.getAssetName().equalsIgnoreCase("CustomerSuppliedDevice")
										&& a.getAssetStatus().equalsIgnoreCase("Not Submitted"))))
						.collect(Collectors.toList());
				responseObj.put("Activated", AnyCustomersuppliedDeviceNoList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getAccesstoFedExODCCount(List<Offboarding> result) {
		List<Offboarding> AccesstoFedExODCYesList = null;
		List<Offboarding> AccesstoFedExODCNoList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				AccesstoFedExODCYesList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
								&& a.getAccess().getAccessStatus().equalsIgnoreCase("Deactivated")))
						.collect(Collectors.toList());
				responseObj.put("Deactivated", AccesstoFedExODCYesList.size());
				AccesstoFedExODCNoList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
								&& a.getAccess().getAccessStatus().equalsIgnoreCase("Activated")))
						.collect(Collectors.toList());
				responseObj.put("Activated", AccesstoFedExODCNoList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getMphasisEmailIdCount(List<Offboarding> result) {
		List<Offboarding> MphasisEmailIdYesList = null;
		List<Offboarding> MphasisEmailIdNoList = null;
//		List<Offboarding> MphasisEmailIdNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				MphasisEmailIdYesList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
						&& a.getEmail().equalsIgnoreCase("Deactivated"))).collect(Collectors.toList());
				responseObj.put("Deactivated", MphasisEmailIdYesList.size());
				MphasisEmailIdNoList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
						&& a.getEmail().equalsIgnoreCase("Activated"))).collect(Collectors.toList());
				responseObj.put("Activated", MphasisEmailIdNoList.size());
//				MphasisEmailIdNAList = result.stream().filter(
//						a -> (a.getOrganisation().equalsIgnoreCase("Mphasis") && a.getEmail().equalsIgnoreCase("NA")))
//						.collect(Collectors.toList());
//				responseObj.put("NA", MphasisEmailIdNAList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getMphasisUserIdCount(List<Offboarding> result) {
		List<Offboarding> MphasisUserIdYesList = null;
		List<Offboarding> MphasisUserIdNoList = null;
//		List<Offboarding> MphasisUserIdNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				MphasisUserIdYesList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
						&& a.getUserId().equalsIgnoreCase("Deactivated"))).collect(Collectors.toList());
				responseObj.put("Deactivated", MphasisUserIdYesList.size());
				MphasisUserIdNoList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
						&& a.getUserId().equalsIgnoreCase("Activated"))).collect(Collectors.toList());
				responseObj.put("Activated", MphasisUserIdNoList.size());
//				MphasisUserIdNAList = result.stream().filter(
//						a -> (a.getOrganisation().equalsIgnoreCase("Mphasis") && a.getUserId().equalsIgnoreCase("NA")))
//						.collect(Collectors.toList());
//				responseObj.put("NA", MphasisUserIdNAList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getMphasisLaptopCount(List<Offboarding> result) {
		List<Offboarding> MphasisLaptopYesList = null;
		List<Offboarding> MphasisLaptopNoList = null;
//		List<Offboarding> MphasisLaptopNAList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				MphasisLaptopYesList = result.stream()
						.filter(e -> e.getAssets().stream()
								.anyMatch(a -> (a.getAssetName().equalsIgnoreCase("Mphasis Laptop")
										&& a.getAssetStatus().equalsIgnoreCase("Submitted"))))
						.collect(Collectors.toList());
				responseObj.put("Deactivated", MphasisLaptopYesList.size());
				MphasisLaptopNoList = result.stream()
						.filter(e -> e.getAssets().stream()
								.anyMatch(a -> (a.getAssetName().equalsIgnoreCase("Mphasis Laptop")
										&& a.getAssetStatus().equalsIgnoreCase("Not Submitted"))))
						.collect(Collectors.toList());
				responseObj.put("Activated", MphasisLaptopNoList.size());
//				MphasisLaptopNAList = result.stream()
//						.filter(e -> e.getAssets().stream()
//								.anyMatch(a -> (a.getAssetName().equalsIgnoreCase("Mphasis Laptop")
//										&& a.getAssetStatus().equalsIgnoreCase("NA"))))
//						.collect(Collectors.toList());
//				responseObj.put("NA", MphasisLaptopNAList.size());
			}

		} catch (Exception e) {

		}
		return responseObj;
	}

	public static Map<String, Object> getAccesstoMainGateCount(List<Offboarding> result) {
		List<Offboarding> AccesstoMainGateYesList = null;
		List<Offboarding> AccesstoMainGateNoList = null;
//		List<Offboarding> AccesstoMainGateNAList = null;

		Map<String, Object> responseObj = new HashMap<String, Object>();
		try {
			if (result != null && !result.isEmpty()) {
				AccesstoMainGateYesList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
								&& a.getAccess().getAccessStatus().equalsIgnoreCase("Deactivated")))
						.collect(Collectors.toList());
				responseObj.put("Deactivated", AccesstoMainGateYesList.size());
				AccesstoMainGateNoList = result.stream()
						.filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
								&& a.getAccess().getAccessStatus().equalsIgnoreCase("Activated")))
						.collect(Collectors.toList());
				responseObj.put("Activated", AccesstoMainGateNoList.size());
//				AccesstoMainGateNAList = result.stream()
//						.filter(a -> (a.getOrganisation().equalsIgnoreCase("Mphasis")
//								&& a.getAccess().getAccessStatus().equalsIgnoreCase("NA")))
//						.collect(Collectors.toList());
//				responseObj.put("NA", AccesstoMainGateNAList.size());

			}

		} catch (Exception e) {

		}
		return responseObj;
	}
	
//	public static Map<String, Object> getLDAPIdDetails(List<Offboarding> result) {
//		List<Offboarding> LDAPIdDetailsYesList = null;
//		List<Offboarding> LDAPIdDetailsNoList = null;
//
//		Map<String, Object> responseObj = new HashMap<String, Object>();
//		try {
//			if (result != null && !result.isEmpty()) {
//				LDAPIdDetailsYesList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
//						&& a.getUserId().equalsIgnoreCase("Deactivated"))).collect(Collectors.toList());
//				responseObj.put("Deactivated", LDAPIdDetailsYesList);
//				LDAPIdDetailsNoList = result.stream().filter(a -> (a.getOrganisation().equalsIgnoreCase("FedEx")
//						&& a.getUserId().equalsIgnoreCase("Activated"))).collect(Collectors.toList());
//				responseObj.put("Activated", LDAPIdDetailsNoList);
//				
//
//			}
//
//		} catch (Exception e) {
//
//		}
//		return responseObj;
//	}
}
