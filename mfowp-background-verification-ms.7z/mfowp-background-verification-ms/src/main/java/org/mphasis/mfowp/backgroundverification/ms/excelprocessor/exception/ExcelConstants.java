package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception;

public class ExcelConstants {

	public static final String FILE_NOT_FOUND = "File is not available in DB";
	
	public static final String FILE_NOT_AVBL = "Please Upload a Valid Xlsx file";
		 
	public static final String FILE_ALREADY_EXISTS =  "File already exists , please upload another file";

	public static final String INVALID_FILE = " The Uploaded file is not an Excel File, please upload a Excel file only.";

	public static final String FILE_NOT_STORED= "Could not store file, Please try again!";
	
	public static final String FILE_DELETE= "File is deleted with ID";
	
	public static final String FILES_DELETE= "multiple selected files deleted...";
	
	public static final String  HIGH_SEVERITY_SUCCESS = "Success";
	
	public static final String  LOCATION_OFFSHORE = "OFFSHORE";
	
	public static final String  LOCATION_ONSITE = "ONSITE";
	
	public static final String  INCORRECT_DATE_FORMAT = "Enter data In correct format (yyyy-mm-dd)";
	}

