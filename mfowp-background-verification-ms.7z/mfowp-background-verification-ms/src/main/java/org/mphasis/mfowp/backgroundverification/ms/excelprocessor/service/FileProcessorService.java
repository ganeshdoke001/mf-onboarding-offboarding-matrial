package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface FileProcessorService {
	
	public List<?> process( MultipartFile sourceFile) throws IOException;
	
	public ResponseEntity<Object> uploadFile( MultipartFile file)
			throws IOException, FileNotFoundException;
	
}
