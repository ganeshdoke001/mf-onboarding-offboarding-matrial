package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.Api;

import java.io.FileNotFoundException;
import java.nio.file.FileAlreadyExistsException;
import java.text.ParseException;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.ErrorResponse;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.ExcelConstants;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.FileNotAvailableException;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.FileStorageException;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.IncorrectDateFormat;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.InvalidFileException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice()
public class ExcelApiAdvice extends ResponseEntityExceptionHandler {

	@ExceptionHandler(FileNotFoundException.class)
	public ResponseEntity<Object> handleFileNotFoundException(HttpServletRequest req, FileNotFoundException ex) {
		ErrorResponse response = new ErrorResponse();
		response.setCode("FILE");
		response.setMessage(ExcelConstants.FILE_NOT_FOUND);
		return buildResponseEntity(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(FileAlreadyExistsException.class)
	public ResponseEntity<Object> handleFileAlreadyExistsException(HttpServletRequest req,
			FileAlreadyExistsException ex) {
		ErrorResponse response = new ErrorResponse();
		response.setCode("FILE");
		response.setMessage(ExcelConstants.FILE_ALREADY_EXISTS);
		return buildResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(FileStorageException.class)
	public ResponseEntity<Object> handleFileStorageException(HttpServletRequest req, FileStorageException ex) {
		ErrorResponse response = new ErrorResponse();
		response.setCode("FILE");
		response.setMessage(ExcelConstants.FILE_NOT_STORED);
		return buildResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(FileNotAvailableException.class)
	public ResponseEntity<Object> handleFileNotAvailableException(HttpServletRequest req,
			FileNotAvailableException ex) {
		ErrorResponse response = new ErrorResponse();
		response.setCode("FILE");
		response.setMessage(ExcelConstants.FILE_NOT_AVBL);
		return buildResponseEntity(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InvalidFileException.class)
	public ResponseEntity<Object> handleInvalidFileException(HttpServletRequest req, InvalidFileException ex) {
		ErrorResponse response = new ErrorResponse();
		response.setCode("FILE");
		response.setMessage(ExcelConstants.INVALID_FILE);
		return buildResponseEntity(response, HttpStatus.UNPROCESSABLE_ENTITY);
	}
	
	@ExceptionHandler(IncorrectDateFormat.class)
	public ResponseEntity<Object> handleIncorrectDateFormat(HttpServletRequest req, IncorrectDateFormat ex) {
		ErrorResponse response = new ErrorResponse();
		response.setCode("Date");
		response.setMessage(ExcelConstants.INCORRECT_DATE_FORMAT);
		return buildResponseEntity(response, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ParseException.class)
	public ResponseEntity<Object> handleParseException(HttpServletRequest req, ParseException ex) {
		ErrorResponse response = new ErrorResponse();
		response.setCode("Date");
		response.setMessage(ExcelConstants.INCORRECT_DATE_FORMAT);
		return buildResponseEntity(response, HttpStatus.BAD_REQUEST);
	}


//	    @ExceptionHandler(IllegalStateException.class)
//	    public ResponseEntity<Object>handleInvalidFileException(HttpServletRequest req,InvalidFileException ex){
//	        ErrorResponse response = new ErrorResponse();
//	        response .setCode("FILE");
//	        response .setMessage("Invalid file,Unsupported Media Type");
//	        return buildResponseEntity(response,HttpStatus.UNPROCESSABLE_ENTITY);
	//
	// }

	private ResponseEntity<Object> buildResponseEntity(ErrorResponse errorResponse, HttpStatus status) {
		return new ResponseEntity<Object>(errorResponse, status);
	}

}
