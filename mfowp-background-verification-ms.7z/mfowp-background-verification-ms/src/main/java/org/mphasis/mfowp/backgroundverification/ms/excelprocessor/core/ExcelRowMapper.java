package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core;

import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader.ExcelDataProcessorException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface ExcelRowMapper<T> {

	@Nullable
	T mapRow(Row nextExcelRow, int rowNum) throws ExcelDataProcessorException;

}