package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.vo;

public class EmpTransitionResponseVO {
	
	private NotificationVO notification;
	
	private String highestSeverity;
	
	private Object data;

	public NotificationVO getNotification() {
		return notification;
	}

	public void setNotification(NotificationVO notification) {
		this.notification = notification;
	}

	public String getHighestSeverity() {
		return highestSeverity;
	}

	public void setHighestSeverity(String highestSeverity) {
		this.highestSeverity = highestSeverity;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
}
