package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class RootExpceptionClass extends ResponseEntityExceptionHandler {
	
	@ResponseStatus(value= HttpStatus.BAD_REQUEST,reason=ExcelConstants.INCORRECT_DATE_FORMAT)
	@ExceptionHandler(IncorrectDateFormat.class)
	public ResponseEntity<?> handleIncorrectDateFormatException(IncorrectDateFormat incorrectDateFormat){
		Map<String,String> errorMap = new HashMap<String,String>();
		errorMap.put("error Message::", incorrectDateFormat.getMessage());
		return new ResponseEntity<Map<String,String>>(errorMap,HttpStatus.BAD_REQUEST);
	}
	
}
