package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.FileEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface FilePersistanceService {

	public FileEntity persistFile(MultipartFile file);

	public ResponseEntity<Map<String, String>> deleteFileByID(String id);

	public ResponseEntity<String> deleteFiles(List<String> files);

	public ResponseEntity<List<FileEntity>> getAllFiles();

	public ResponseEntity<FileEntity> getFileById(String id) throws FileNotFoundException;

}
