package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception;

public class IncorrectDateFormat extends Exception{
	private String errorMessage;
	private String highSeverity;
	
	public IncorrectDateFormat(String errorMessage, String highSeverity) {
		super();
		this.errorMessage=errorMessage;
		this.highSeverity=highSeverity;
		
	}


}
