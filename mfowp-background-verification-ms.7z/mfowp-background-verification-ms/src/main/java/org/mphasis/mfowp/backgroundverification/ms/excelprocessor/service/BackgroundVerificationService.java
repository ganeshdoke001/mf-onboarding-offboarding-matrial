package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.IncorrectDateFormat;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

public interface BackgroundVerificationService {
	
	
	public BackgroundVerificationEntity saveEmployeeNumber(BackgroundVerificationEntity entity);
	
	public Boolean deleteByEmployeeNumber(String id);

	public BackgroundVerificationEntity updateEmployeeDetails(BackgroundVerificationEntity entity, Integer id);

	Page<BackgroundVerificationEntity> getByFromDateandToDate(Date startDate1, Date endDate1,Pageable paging);

	public Optional<BackgroundVerificationEntity> getByEmployeeNumber(Integer id);

	public List<BackgroundVerificationEntity> getAllBgv();
	
	public ResponseEntity<?> bgvDashboardCount(String location, String endDate) throws IncorrectDateFormat;

	public ResponseEntity<?> backgroundVerificationDashboardDetailsCount(String startDate, String endDate) throws IncorrectDateFormat;


	ResponseEntity<?> backgroundVerificationDashboardDetailsCountByDm(String startDate, String endDate) throws IncorrectDateFormat;
	


}

