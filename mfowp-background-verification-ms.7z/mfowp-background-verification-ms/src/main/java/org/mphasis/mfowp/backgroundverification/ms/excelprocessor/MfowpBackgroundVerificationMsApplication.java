package org.mphasis.mfowp.backgroundverification.ms.excelprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication(scanBasePackages = "org.mphasis.mfowp.backgroundverification.ms")
@EnableMongoRepositories(basePackages = "org.mphasis.mfowp.backgroundverification.ms.repository")
public class MfowpBackgroundVerificationMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MfowpBackgroundVerificationMsApplication.class, args);
	}

}
