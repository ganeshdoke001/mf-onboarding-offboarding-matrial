package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.mapper;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.BackgroundVerification;

public interface BackgroundVerificationMapper {
	BackgroundVerificationEntity BackgroundVerificationtoEmployee(BackgroundVerification backgroundVerification);
	BackgroundVerification EmployeetoBackgroundVerification(BackgroundVerificationEntity backgroundVerificationEntity);


}
