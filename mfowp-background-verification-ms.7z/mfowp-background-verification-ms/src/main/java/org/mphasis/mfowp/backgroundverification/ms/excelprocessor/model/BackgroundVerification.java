package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model;
import java.util.Date;
import javax.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

public class BackgroundVerification {

    
	
	@Positive(message = "EMPLOYEENUMBER::should not be empty")
	@NotNull(message = "EMPLOYEENUMBER::should not be empty")
	private Integer employeeNumber;

	@NotNull
	@NotEmpty(message = "FEDEX ID::should not be empty")
	private String fedEXId;

	@NotNull
	@NotEmpty(message = "EMPLOYEENAME::should not be empty")
	private String employeeName;
	

	@NotNull(message = "DOJ::should not be empty")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date doj;

	
	@NotNull
	@NotEmpty(message = "posLocName::should not be empty")
	private String posLocName;


	@NotNull
	@NotEmpty(message = "LOCATION::should not be empty")
	private String location; 

	@NotNull
	@NotEmpty(message = "DM/CEM::should not be empty")
	private String dm;// campusLaterals

	@NotNull
	@NotEmpty(message = "PM::should not be empty")
	private String pm;// location

	
	@NotNull
	@NotEmpty(message = "BGVSTATUS::Should not be empty")
	private String bgvStatus;
	
	private String redReason;
	
	//@NotNull(message = "Date Of Completion::should not be empty")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateOfCompletion;
	
	
	@Positive(message = "BGV Aging::Should not be empty")
	@NotNull(message = "BGV Aging::Should not be empty")
	private Integer bgvAging;
	
	
	private String status;
	

	public BackgroundVerification() {

	}


	public BackgroundVerification(
			@Positive(message = "EMPLOYEENUMBER::should not be empty") @NotNull(message = "EMPLOYEENUMBER::should not be empty") Integer employeeNumber,
			@NotNull @NotEmpty(message = "FEDEX ID::should not be empty") String fedEXId,
			@NotNull @NotEmpty(message = "EMPLOYEENAME::should not be empty") String employeeName,
			@NotNull(message = "DOJ::should not be empty") Date doj,
			@NotNull @NotEmpty(message = "posLocName::should not be empty") String posLocName,
			@NotNull @NotEmpty(message = "LOCATION::should not be empty") String location,
			@NotNull @NotEmpty(message = "DM/CEM::should not be empty") String dm,
			@NotNull @NotEmpty(message = "PM::should not be empty") String pm,
			@NotNull @NotEmpty(message = "BGVSTATUS::Should not be empty") String bgvStatus, String redReason,
			Date dateOfCompletion,
			@Positive(message = "BGV Aging::Should not be empty") @NotNull(message = "BGV Aging::Should not be empty") Integer bgvAging,
			String status) {
		super();
		this.employeeNumber = employeeNumber;
		this.fedEXId = fedEXId;
		this.employeeName = employeeName;
		this.doj = doj;
		this.posLocName = posLocName;
		this.location = location;
		this.dm = dm;
		this.pm = pm;
		this.bgvStatus = bgvStatus;
		this.redReason = redReason;
		this.dateOfCompletion = dateOfCompletion;
		this.bgvAging = bgvAging;
		this.status = status;
	}


	public Integer getEmployeeNumber() {
		return employeeNumber;
	}


	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}


	public String getFedEXId() {
		return fedEXId;
	}


	public void setFedEXId(String fedEXId) {
		this.fedEXId = fedEXId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public Date getDoj() {
		return doj;
	}


	public void setDoj(Date doj) {
		this.doj = doj;
	}


	public String getPosLocName() {
		return posLocName;
	}


	public void setPosLocName(String posLocName) {
		this.posLocName = posLocName;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getDm() {
		return dm;
	}


	public void setDm(String dm) {
		this.dm = dm;
	}


	public String getPm() {
		return pm;
	}


	public void setPm(String pm) {
		this.pm = pm;
	}


	public String getBgvStatus() {
		return bgvStatus;
	}


	public void setBgvStatus(String bgvStatus) {
		this.bgvStatus = bgvStatus;
	}


	public String getRedReason() {
		return redReason;
	}


	public void setRedReason(String redReason) {
		this.redReason = redReason;
	}


	public Date getDateOfCompletion() {
		return dateOfCompletion;
	}


	public void setDateOfCompletion(Date dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}


	public Integer getBgvAging() {
		return bgvAging;
	}


	public void setBgvAging(Integer bgvAging) {
		this.bgvAging = bgvAging;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public String toString() {
		return "BackgroundVerification [employeeNumber=" + employeeNumber + ", fedEXId=" + fedEXId + ", employeeName="
				+ employeeName + ", doj=" + doj + ", posLocName=" + posLocName + ", location=" + location + ", dm=" + dm
				+ ", pm=" + pm + ", bgvStatus=" + bgvStatus + ", redReason=" + redReason + ", dateOfCompletion="
				+ dateOfCompletion + ", bgvAging=" + bgvAging + ", status=" + status + "]";
	}


	
	
}
