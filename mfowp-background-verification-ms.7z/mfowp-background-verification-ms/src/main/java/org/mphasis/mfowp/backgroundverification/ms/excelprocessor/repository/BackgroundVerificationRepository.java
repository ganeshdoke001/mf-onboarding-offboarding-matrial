package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.repository;

import java.util.Optional;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BackgroundVerificationRepository extends MongoRepository<BackgroundVerificationEntity, String> {

	public BackgroundVerificationEntity findByBackgroundverificationId(String id);

	public Optional<BackgroundVerificationEntity> findByEmployeeNumber(Integer employeeNumber);
//	Page<BackgroundVerificationEntity> getByFromDateAndToDate( LocalDate fromDate, LocalDate toDate, Pageable pageable);


}
