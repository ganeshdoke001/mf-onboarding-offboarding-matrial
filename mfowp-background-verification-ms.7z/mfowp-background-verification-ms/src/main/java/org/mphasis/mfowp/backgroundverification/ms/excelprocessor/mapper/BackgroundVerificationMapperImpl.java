package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.mapper;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.BackgroundVerification;
import org.springframework.stereotype.Service;
@Service
public class BackgroundVerificationMapperImpl implements BackgroundVerificationMapper{
	@Override
	public BackgroundVerificationEntity BackgroundVerificationtoEmployee(BackgroundVerification backgroundVerification) {

		BackgroundVerificationEntity backgroundVerificationEntity = new BackgroundVerificationEntity();
		backgroundVerificationEntity.setEmployeeNumber(backgroundVerification.getEmployeeNumber());
		backgroundVerificationEntity.setFedEXId(backgroundVerification.getFedEXId());
		backgroundVerificationEntity.setEmployeeName(backgroundVerification.getEmployeeName());
		backgroundVerificationEntity.setDoj(backgroundVerification.getDoj());
		backgroundVerificationEntity.setPosLocName(backgroundVerification.getPosLocName());
		backgroundVerificationEntity.setLocation(backgroundVerification.getLocation());
		backgroundVerificationEntity.setDm(backgroundVerification.getDm());
		backgroundVerificationEntity.setPm(backgroundVerification.getPm());
		backgroundVerificationEntity.setBgvStatus(backgroundVerification.getBgvStatus());
		backgroundVerificationEntity.setredReason(backgroundVerification.getRedReason());
		backgroundVerificationEntity.setDateOfCompletion(backgroundVerification.getDateOfCompletion());
		backgroundVerificationEntity.setBgvAging(backgroundVerification.getBgvAging());
		backgroundVerificationEntity.setStatus("New");

		return backgroundVerificationEntity;
	}

	@Override
	public BackgroundVerification EmployeetoBackgroundVerification(BackgroundVerificationEntity backgroundVerificationEntity) {

		BackgroundVerification backgroundVerification = new BackgroundVerification();
		backgroundVerification.setEmployeeNumber(backgroundVerificationEntity.getEmployeeNumber());
		backgroundVerification.setFedEXId(backgroundVerificationEntity.getFedEXId());
		backgroundVerification.setEmployeeName(backgroundVerificationEntity.getEmployeeName());
		backgroundVerification.setDoj(backgroundVerificationEntity.getDoj());
		backgroundVerification.setPosLocName(backgroundVerificationEntity.getPosLocName());
		backgroundVerification.setLocation(backgroundVerificationEntity.getLocation());
		backgroundVerification.setDm(backgroundVerificationEntity.getDm());
		backgroundVerification.setPm(backgroundVerificationEntity.getPm());
		backgroundVerification.setBgvStatus(backgroundVerification.getBgvStatus());
		backgroundVerification.setRedReason(backgroundVerification.getRedReason());
		backgroundVerification.setDateOfCompletion(backgroundVerification.getDateOfCompletion());
		backgroundVerification.setBgvAging(backgroundVerification.getBgvAging());

		return backgroundVerification;
	}
	


}
