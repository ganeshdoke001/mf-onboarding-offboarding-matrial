package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.ExcelConstants;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.IncorrectDateFormat;

public class ServiceHelper {

	public static Map<String, Object> getBgvStatusCount(List<BackgroundVerificationEntity> result, String location,
			String endDate) throws IncorrectDateFormat {

		List<BackgroundVerificationEntity> greenList = null;
		List<BackgroundVerificationEntity> reinitiatedToGreenList = null;
		List<BackgroundVerificationEntity> redDeviation = null;
		List<BackgroundVerificationEntity> wipList = null;
		List<BackgroundVerificationEntity> redList = null;
		List<BackgroundVerificationEntity> bgvIncompleteList = null;
		List<BackgroundVerificationEntity> redReinitiatedList = null;
		List<BackgroundVerificationEntity> bgvWaivedList = null;
		Map<String, Object> responseObj = new HashMap<String, Object>();

		if (result != null && !result.isEmpty()) {
			responseObj.put("location", location);
			greenList = result.stream().filter(a -> (a.getBgvStatus().equalsIgnoreCase("green")))
					.collect(Collectors.toList());
			responseObj.put("green", greenList.size());

			reinitiatedToGreenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("reinitiatedToGreen")))
					.collect(Collectors.toList());
			responseObj.put("reinitiatedToGreen", reinitiatedToGreenList.size());

			redDeviation = result.stream().filter(a -> (a.getBgvStatus().equalsIgnoreCase("redDeviation")))
					.collect(Collectors.toList());
			;
			responseObj.put("redDeviation", redDeviation.size());

			wipList = result.stream().filter(a -> (a.getBgvStatus().equalsIgnoreCase("WIP")))
					.collect(Collectors.toList());
			responseObj.put("WIP", wipList.size());
			String date1 = "2010-01-01";
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

			try {
				Date date = formatter.parse(date1);
				bgvIncompleteList = result.stream()
						.filter(a -> (a.getDoj().before(date) && (a.getBgvStatus().equalsIgnoreCase("WIP")
								|| a.getBgvStatus().equalsIgnoreCase("bgv Waived")
								|| a.getBgvStatus().equalsIgnoreCase("red Deviation"))))
						.collect(Collectors.toList());
				responseObj.put("bgvIncompleteEmployeesDOJBefore2010", bgvIncompleteList.size());

			} catch (DateTimeParseException | ParseException e) {
				throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
			}

			redList = result.stream().filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red")))
					.collect(Collectors.toList());
			responseObj.put("red", redList.size());

			redReinitiatedList = result.stream().filter(a -> (a.getBgvStatus().equalsIgnoreCase("redReinitiated")))
					.collect(Collectors.toList());
			responseObj.put("redReinitiated", redReinitiatedList.size());

			bgvWaivedList = result.stream().filter(a -> (a.getBgvStatus().equalsIgnoreCase("bgvWaived")))
					.collect(Collectors.toList());
			responseObj.put("bgvWaived", bgvWaivedList.size());

			float total = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size() + wipList.size()
					+ redList.size() + redReinitiatedList.size() + bgvWaivedList.size();

			responseObj.put("totalEmployees", total);
			float count = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size();
			float completion = (count / total) * 100;

			responseObj.put("bgvCompliant", completion);
		}

		return responseObj;

	}

	public static List<?> getDashboardDetailsCount(List<BackgroundVerificationEntity> result)
			throws IncorrectDateFormat {

		List<BackgroundVerificationEntity> greenList = null;
		List<BackgroundVerificationEntity> reinitiatedToGreenList = null;
		List<BackgroundVerificationEntity> redDeviation = null;
		List<BackgroundVerificationEntity> wipList = null;
		List<BackgroundVerificationEntity> redList = null;
		List<BackgroundVerificationEntity> bgvIncompleteList = null;
		List<BackgroundVerificationEntity> redReinitiatedList = null;
		List<BackgroundVerificationEntity> bgvWaivedList = null;
		List<Object> response = new ArrayList<>();
		Map<String, Object> responseObj = new HashMap<>();
		Map<String, Object> responseObj1 = new HashMap<>();

		if (result != null && !result.isEmpty()) {

			responseObj.put("location", ExcelConstants.LOCATION_OFFSHORE);

			greenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("green", greenList.size());

			reinitiatedToGreenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Reinitiated to Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("reinitiatedToGreen", reinitiatedToGreenList.size());

			redDeviation = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Deviation")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			;
			responseObj.put("redDeviation", redDeviation.size());

			wipList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("WIP")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("WIP", wipList.size());
			String date1 = "2010-01-01";
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

			try {
				Date date = formatter.parse(date1);
				bgvIncompleteList = result.stream().filter(a -> (a.getDoj().before(date)
						&& (a.getBgvStatus().equalsIgnoreCase("WIP") || a.getBgvStatus().equalsIgnoreCase("BGV Waived")
								|| a.getBgvStatus().equalsIgnoreCase("Red Deviation"))
						&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
						.collect(Collectors.toList());
				responseObj.put("bgvIncompleteEmployeesDOJBefore2010", bgvIncompleteList.size());

			} catch (DateTimeParseException | ParseException e) {
				throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
			}

			redList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("red", redList.size());

			redReinitiatedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Reinitiated")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("redReinitiated", redReinitiatedList.size());

			bgvWaivedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("BGV Waived")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("bgvWaived", bgvWaivedList.size());

			float total = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size() + wipList.size()
					+ redList.size() + redReinitiatedList.size() + bgvWaivedList.size();

			responseObj.put("totalEmployees", total);
			float count = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size();
			float completion = (count / total) * 100;

			responseObj.put("bgvCompliant", completion);

			response.add(responseObj);

		}

		if (result != null && !result.isEmpty()) {

			responseObj1.put("location", ExcelConstants.LOCATION_ONSITE);

			greenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("green", greenList.size());

			reinitiatedToGreenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Reinitiated to Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("reinitiatedToGreen", reinitiatedToGreenList.size());

			redDeviation = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Deviation")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			;
			responseObj1.put("redDeviation", redDeviation.size());

			wipList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("WIP")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("WIP", wipList.size());
			String date1 = "2010-01-01";
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

			try {
				Date date = formatter.parse(date1);
				bgvIncompleteList = result.stream().filter(a -> (a.getDoj().before(date)
						&& (a.getBgvStatus().equalsIgnoreCase("WIP") || a.getBgvStatus().equalsIgnoreCase("BGV Waived")
								|| a.getBgvStatus().equalsIgnoreCase("Red Deviation"))
						&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
						.collect(Collectors.toList());
				responseObj1.put("bgvIncompleteEmployeesDOJBefore2010", bgvIncompleteList.size());

			} catch (DateTimeParseException | ParseException e) {
				throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
			}

			redList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("red", redList.size());

			redReinitiatedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Reinitiated")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("redReinitiated", redReinitiatedList.size());

			bgvWaivedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("BGV Waived")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("bgvWaived", bgvWaivedList.size());

			float total = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size() + wipList.size()
					+ redList.size() + redReinitiatedList.size() + bgvWaivedList.size();

			responseObj1.put("totalEmployees", total);
			float count = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size();
			float completion = (count / total) * 100;

			responseObj1.put("bgvCompliant", completion);

			response.add(responseObj1);

		}

		return response;

	}

	public static List<?> getDashboardDetailsCountByDm(List<BackgroundVerificationEntity> result) throws IncorrectDateFormat{
		List<BackgroundVerificationEntity> greenList = null;
		List<BackgroundVerificationEntity> reinitiatedToGreenList = null;
		List<BackgroundVerificationEntity> redDeviation = null;
		List<BackgroundVerificationEntity> wipList = null;
		List<BackgroundVerificationEntity> redList = null;
//		List<BackgroundVerificationEntity> bgvIncompleteList = null;
		List<BackgroundVerificationEntity> redReinitiatedList = null;
		List<BackgroundVerificationEntity> bgvWaivedList = null;
		List<Object> response = new ArrayList<>();
		Map<String, Object> responseObj = new HashMap<>();
		Map<String, Object> responseObj1 = new HashMap<>();

		if (result != null && !result.isEmpty()) {

			responseObj.put("location", ExcelConstants.LOCATION_OFFSHORE);

			greenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("green", greenList.size());

			reinitiatedToGreenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Reinitiated to Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("reinitiatedToGreen", reinitiatedToGreenList.size());

			redDeviation = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Deviation")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			;
			responseObj.put("redDeviation", redDeviation.size());

			wipList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("WIP")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("WIP", wipList.size());
//			String date1 = "2010-01-01";
//			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
//
//			try {
//				Date date = formatter.parse(date1);
//				bgvIncompleteList = result.stream().filter(a -> (a.getDoj().before(date)
//						&& (a.getBgvStatus().equalsIgnoreCase("WIP") || a.getBgvStatus().equalsIgnoreCase("BGV Waived")
//								|| a.getBgvStatus().equalsIgnoreCase("Red Deviation"))
//						&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
//						.collect(Collectors.toList());
//				responseObj.put("bgvIncompleteEmployeesDOJBefore2010", bgvIncompleteList.size());
//
//			} catch (DateTimeParseException | ParseException e) {
//				throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
//			}

			redList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("red", redList.size());

			redReinitiatedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Reinitiated")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("redReinitiated", redReinitiatedList.size());

			bgvWaivedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("BGV Waived")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_OFFSHORE)))
					.collect(Collectors.toList());
			responseObj.put("bgvWaived", bgvWaivedList.size());

			float total = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size() + wipList.size()
					+ redList.size() + redReinitiatedList.size() + bgvWaivedList.size();

			responseObj.put("totalEmployees", total);
			float count = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size();
			float completion;
			if (total != 0) {
			completion = (count / total) * 100;
			}else {
				completion = 0;
			}

			responseObj.put("bgvCompliant", completion);

			response.add(responseObj);

		}

		if (result != null && !result.isEmpty()) {

			responseObj1.put("location", ExcelConstants.LOCATION_ONSITE);

			greenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("green", greenList.size());

			reinitiatedToGreenList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Reinitiated to Green")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("reinitiatedToGreen", reinitiatedToGreenList.size());

			redDeviation = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Deviation")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			;
			responseObj1.put("redDeviation", redDeviation.size());

			wipList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("WIP")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("WIP", wipList.size());
//			String date1 = "2010-01-01";
//			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
//
//			try {
//				Date date = formatter.parse(date1);
//				bgvIncompleteList = result.stream().filter(a -> (a.getDoj().before(date)
//						&& (a.getBgvStatus().equalsIgnoreCase("WIP") || a.getBgvStatus().equalsIgnoreCase("BGV Waived")
//								|| a.getBgvStatus().equalsIgnoreCase("Red Deviation"))
//						&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
//						.collect(Collectors.toList());
//				responseObj1.put("bgvIncompleteEmployeesDOJBefore2010", bgvIncompleteList.size());
//
//			} catch (DateTimeParseException | ParseException e) {
//				throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
//			}

			redList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("red", redList.size());

			redReinitiatedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("Red Reinitiated")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("redReinitiated", redReinitiatedList.size());

			bgvWaivedList = result.stream()
					.filter(a -> (a.getBgvStatus().equalsIgnoreCase("BGV Waived")
							&& a.getLocation().equalsIgnoreCase(ExcelConstants.LOCATION_ONSITE)))
					.collect(Collectors.toList());
			responseObj1.put("bgvWaived", bgvWaivedList.size());

			float count = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size();
			float total = greenList.size() + reinitiatedToGreenList.size() + redDeviation.size() + wipList.size()
					+ redList.size() + redReinitiatedList.size() + bgvWaivedList.size();

			responseObj1.put("totalEmployees", total);
			float completion;
			if (total != 0) {
			completion = (count / total) * 100;
			}else {
				completion = 0;
			}

			responseObj1.put("bgvCompliant", completion);

			response.add(responseObj1);

		}

		return response;


	}	

}
