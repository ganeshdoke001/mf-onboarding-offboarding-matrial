package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelException;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelReader;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.FileEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.ExcelConstants;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.FileNotAvailableException;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.InvalidFileException;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.BackgroundVerification;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader.BackgroundVerificationExcelReader;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.repository.BackgroundVerificationRepository;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.repository.FileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileValidationServiceImpl<BackgroundverificationRepository> implements FileValidationService {

	@Autowired
	private FileRepository FileRepository;
	ArrayList<BackgroundVerification> backgroundverificationSave = new ArrayList<>();

	@Autowired
	private BackgroundVerificationRepository backgroundverificationRepository;

	private ExcelReader<BackgroundVerification> backgroundverificationReader = new BackgroundVerificationExcelReader<BackgroundVerification>();

	public List<BackgroundVerification> validateExcel(String fileType,MultipartFile sourceFile) throws IOException {

		List<BackgroundVerification> backgroundverifications = null;
		if (fileType.equalsIgnoreCase("Bgv")) {

		backgroundverificationReader.setSourceFile(sourceFile);
		backgroundverifications = backgroundverificationReader.listRecords();

		System.out.println("backgroundverification Record" + backgroundverifications);
		for (int i = 0; i < backgroundverifications.size(); i++) {
			BackgroundVerification backgroundverificationCheck = backgroundverifications.get(i);

			System.out.println("Backgroundverification: " + backgroundverifications.get(i));
			Optional<BackgroundVerificationEntity> backgroundVerificationEntityOptional = backgroundverificationRepository
					.findByEmployeeNumber(backgroundverificationCheck.getEmployeeNumber());

			if (backgroundVerificationEntityOptional.isPresent()) {
				System.out.println("Record already exists");
				BackgroundVerificationEntity backgroundverificationEntity = backgroundVerificationEntityOptional.get();
				BackgroundVerification backgroundverificationNew = new BackgroundVerification();

				backgroundverificationNew.setEmployeeNumber(backgroundverificationEntity.getEmployeeNumber());
				backgroundverificationNew.setFedEXId(backgroundverificationEntity.getFedEXId());
				backgroundverificationNew.setEmployeeName(backgroundverificationEntity.getEmployeeName());
				backgroundverificationNew.setDoj(backgroundverificationEntity.getDoj());
				backgroundverificationNew.setPosLocName(backgroundverificationEntity.getPosLocName());
				backgroundverificationNew.setLocation(backgroundverificationEntity.getLocation());
				backgroundverificationNew.setDm(backgroundverificationEntity.getDm());
				backgroundverificationNew.setPm(backgroundverificationEntity.getPm());
				backgroundverificationNew.setBgvStatus(backgroundverificationEntity.getBgvStatus());
				backgroundverificationNew.setRedReason(backgroundverificationEntity.getredReason());
				backgroundverificationNew.setDateOfCompletion(backgroundverificationEntity.getDateOfCompletion());
				backgroundverificationNew.setBgvAging(backgroundverificationEntity.getBgvAging());
				backgroundverificationNew.setStatus("DB");
				backgroundverificationSave.add(backgroundverificationNew);

				backgroundverificationEntity.setEmployeeNumber(backgroundverificationCheck.getEmployeeNumber());
				backgroundverificationEntity.setFedEXId(backgroundverificationCheck.getFedEXId());
				backgroundverificationEntity.setEmployeeName(backgroundverificationCheck.getEmployeeName());
				backgroundverificationEntity.setDoj(backgroundverificationCheck.getDoj());
				backgroundverificationEntity.setPosLocName(backgroundverificationCheck.getPosLocName());
				backgroundverificationEntity.setLocation(backgroundverificationCheck.getLocation());
				backgroundverificationEntity.setDm(backgroundverificationCheck.getDm());
				backgroundverificationEntity.setPm(backgroundverificationCheck.getPm());
				backgroundverificationEntity.setBgvStatus(backgroundverificationCheck.getBgvStatus());
				backgroundverificationEntity.setredReason(backgroundverificationCheck.getRedReason());
				backgroundverificationNew.setDateOfCompletion(backgroundverificationEntity.getDateOfCompletion());
				backgroundverificationEntity.setBgvAging(backgroundverificationCheck.getBgvAging());
				
				backgroundverificationCheck.setStatus("Excel");
				backgroundverificationEntity.setStatus("Excel");

			} else {
				BackgroundVerificationEntity backgroundverificationEntity = new BackgroundVerificationEntity();
				backgroundverificationEntity.setStatus("New");
				backgroundverificationCheck.setStatus("New");
			}
		}
		}
		if (backgroundverificationSave.size() != 0) {
			backgroundverifications.addAll(backgroundverificationSave);
		}
		backgroundverificationSave.clear();
		return backgroundverifications;
	}

	public String validateFile(MultipartFile file) throws FileNotFoundException, FileAlreadyExistsException {

		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		String extension = "";
		String ErrorMsg = "";
		if (file.isEmpty()) {
			throw new FileNotAvailableException(ExcelConstants.FILE_NOT_AVBL);
		}
		List<FileEntity> fileGot = FileRepository.findByFileName(fileName);
		int fileSize = fileGot.size();
		if (fileSize > 0) {
			throw new FileAlreadyExistsException(ExcelConstants.FILE_ALREADY_EXISTS);
		} else {
			int i = fileName.lastIndexOf('.');
			if (i >= 0) {
				extension = fileName.substring(i + 1);
				if (!extension.equals("xlsx")) {
					throw new InvalidFileException(ExcelConstants.INVALID_FILE);
				}
			}
		}
		return ErrorMsg;

	}

	public ResponseEntity<Object> validate(String fileType,MultipartFile file) throws IOException, FileNotFoundException {
		List<?> data = null;
		validateFile(file);

		try {
			data = validateExcel(fileType,file);

		} catch (ExcelException e) {
			return new ResponseEntity<Object>(e.getErrors(), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return new ResponseEntity<Object>(data, new HttpHeaders(), HttpStatus.OK);

	}

}