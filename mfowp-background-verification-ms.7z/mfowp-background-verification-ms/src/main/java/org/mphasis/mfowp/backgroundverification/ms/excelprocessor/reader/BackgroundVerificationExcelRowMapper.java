package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader;

import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelRowMapper;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.BackgroundVerification;

public class BackgroundVerificationExcelRowMapper implements ExcelRowMapper<BackgroundVerification> {

	@Override
	public BackgroundVerification mapRow(Row nextExcelRow, int rowNum) throws ExcelDataProcessorException {

		BackgroundVerification backgroundverification = new BackgroundVerification();
		Integer valueInt;
		String valueStr;
		Date valueDate;

		Cell cell = nextExcelRow.getCell(0);
		if (cell != null) {
			valueInt = (int) cell.getNumericCellValue();
			backgroundverification.setEmployeeNumber(valueInt);
		}

		cell = nextExcelRow.getCell(1);
		if (cell != null) {
			try {
				valueStr = cell.getStringCellValue();
			backgroundverification.setFedEXId(valueStr);
			}catch(Exception e){
				backgroundverification.setFedEXId("");
			}
		}

		cell = nextExcelRow.getCell(2);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			backgroundverification.setEmployeeName(valueStr);
		}

		cell = nextExcelRow.getCell(3);
		if (cell != null) {
			valueDate = cell.getDateCellValue();
			backgroundverification.setDoj(valueDate);
		}

		cell = nextExcelRow.getCell(4);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			backgroundverification.setPosLocName(valueStr);
		}

		cell = nextExcelRow.getCell(5);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			backgroundverification.setLocation(valueStr);
		}

		cell = nextExcelRow.getCell(6);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			backgroundverification.setDm(valueStr);
		}

		cell = nextExcelRow.getCell(7);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			backgroundverification.setPm(valueStr);
		}

		
		cell = nextExcelRow.getCell(8);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			backgroundverification.setBgvStatus(valueStr);
		}
		
		cell = nextExcelRow.getCell(9);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			backgroundverification.setRedReason(valueStr);
		}
		cell = nextExcelRow.getCell(10);
		if (cell != null) {
			valueDate = cell.getDateCellValue();
			backgroundverification.setDateOfCompletion(valueDate);
		
		}

		cell = nextExcelRow.getCell(11);
		if (cell != null) {
			valueInt = (int) cell.getNumericCellValue();
			backgroundverification.setBgvAging(valueInt);
		}
		return backgroundverification;
	}

}
