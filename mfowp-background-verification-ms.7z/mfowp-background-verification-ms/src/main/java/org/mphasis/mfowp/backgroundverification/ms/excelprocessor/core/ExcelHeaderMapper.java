package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader.ExcelDataProcessorException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface ExcelHeaderMapper<T> {

	@Nullable
	List<T> mapHeader(Row nextExcelHeaderRow, int rowHeaderNum) throws ExcelDataProcessorException;

}