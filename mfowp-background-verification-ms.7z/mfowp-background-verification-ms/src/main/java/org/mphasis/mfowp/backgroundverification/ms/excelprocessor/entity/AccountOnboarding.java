package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity;

public class AccountOnboarding {
	
	private String accountName;
	private String transitionDate;
	private String onBoardingDate;
	private String offBoardingDate;
	private String employeeIdmpId;
	private String empEmailId;
	private String designation;
	
	public AccountOnboarding() {
		
	}
	
	public AccountOnboarding(String transitionDate) {
		super();
		this.transitionDate = transitionDate;
	}
	
	public String getAccountName() {
		return accountName;
	}
	public AccountOnboarding(String accountName, String onBoardingDate, String offBoardingDate, String employeeIdmpId,
			String empEmailId, String designation) {
		super();
		this.accountName = accountName;
		this.onBoardingDate = onBoardingDate;
		this.offBoardingDate = offBoardingDate;
		this.employeeIdmpId = employeeIdmpId;
		this.empEmailId = empEmailId;
		this.designation = designation;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getOnBoardingDate() {
		return onBoardingDate;
	}
	public void setOnBoardingDate(String onBoardingDate) {
		this.onBoardingDate = onBoardingDate;
	}
	public String getOffBoardingDate() {
		return offBoardingDate;
	}
	public void setOffBoardingDate(String offBoardingDate) {
		this.offBoardingDate = offBoardingDate;
	}
	public String getEmployeeIdmpId() {
		return employeeIdmpId;
	}
	public void setEmployeeIdmpId(String employeeIdmpId) {
		this.employeeIdmpId = employeeIdmpId;
	}
	public String getEmpEmailId() {
		return empEmailId;
	}
	public void setEmpEmailId(String empEmailId) {
		this.empEmailId = empEmailId;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getTransitionDate() {
		return transitionDate;
	}

	public void setTransitionDate(String transitionDate) {
		this.transitionDate = transitionDate;
	}
		

}
