package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core;

public class ExcelReaderException extends Exception {

	private static final long serialVersionUID = 2657583064616173546L;

	public ExcelReaderException() {
	}

	public ExcelReaderException(String message) {
		super(message);
	}

}