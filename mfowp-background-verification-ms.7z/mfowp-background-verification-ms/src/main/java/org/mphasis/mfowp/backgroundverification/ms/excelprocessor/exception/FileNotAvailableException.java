package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception;



public class FileNotAvailableException extends RuntimeException {
    
    private static final long serialVersionUID = 1L;



   public FileNotAvailableException(String message) {
        super(message);
    }



   public FileNotAvailableException(String message, Throwable cause) {
        super(message, cause);
    }
}