package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.BackgroundVerification;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.ExcelHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

public class ExcelValidator {

	@Autowired
	private Validator validator;

	public ValidationResult validateExcelFile(MultipartFile excelFile) {

		String contentType = excelFile.getContentType();
		System.out.println("contentType: " + contentType);
		Violation violation = new Violation();
		ValidationResult validationResult = new ValidationResult();
		if (!contentType.equalsIgnoreCase("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
			violation.setCode("Excel File Error");
			violation.setMessage("Invalid file, Unsupported Media Type");
			violation.setTimestamp(new Date());
			validationResult.add(violation);
		}
		return validationResult;
	}

	public ValidationResult validateExcelHeaders(List<ExcelHeader> fileHeader, List<ExcelHeader> excelRuntimeHeader) {
		System.out.println("Headers count: " + fileHeader.size());
		System.out.println("excelRuntimeHeaders count: " + excelRuntimeHeader.size());
		int fileHeaderSize = fileHeader.size();
		fileHeaderSize = (excelRuntimeHeader.size() < fileHeader.size()) ? excelRuntimeHeader.size() : fileHeaderSize;
		// TODO Handle NLP excepted less than header counts tukaram
		ValidationResult validationResult = new ValidationResult();

		for (int headerIndex = 0; headerIndex < fileHeaderSize; headerIndex++) {
			System.out.println("+headerIndexheaderIndex" + headerIndex);
			System.out.println("fileHeader " + (headerIndex + 1) + " : " + fileHeader.get(headerIndex));
			System.out.println("headers    " + (headerIndex + 1) + " : " + excelRuntimeHeader.get(headerIndex));
			if (!fileHeader.get(headerIndex).getHeaderName()
					.equals(excelRuntimeHeader.get(headerIndex).getHeaderName())) {
				System.out.println("Not EQ");
				Violation violation = new Violation();
				violation.setCode("Excel Header Error");
				violation.setColumn(fileHeader.get(headerIndex).getHeaderName());
				violation.setMessage(fileHeader.get(headerIndex).getHeaderName() + " : "
						+ " excel mandatory column/ header is missing");
				violation.setTimestamp(new Date());
				validationResult.add(violation);
			}
		}

		return validationResult;
	}

	public ValidationResult validateExcelData(List<ExcelHeader> fileHeader, List<?> BackgroundVerifications) {
		ValidationResult validationResult = new ValidationResult();
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		BackgroundVerification backgroundVerification = new BackgroundVerification();
		System.out.println("BackgroundVerification count: " + BackgroundVerifications.size());

		for (int recordNumber = 0; recordNumber < BackgroundVerifications.size(); recordNumber++) {
			backgroundVerification = (BackgroundVerification) BackgroundVerifications.get(recordNumber);
			Set<ConstraintViolation<BackgroundVerification>> violations = validator
					.validate(backgroundVerification);
//			System.out.println("Violations " + violations);
			for (ConstraintViolation<BackgroundVerification> violation : violations) {
				String message = violation.getMessage();
//				/System.out.println("Message : " + message);
				violation.getInvalidValue();
				String[] violationMessages = message.split("::");
				Violation violation2 = new Violation();
				violation2.setCode("Excel Data Error");
				violation2.setRow(Integer.toString(recordNumber + 2));
				violation2.setColumn(violationMessages[0]);
				violation2.setMessage(message);
				violation2.setTimestamp(new Date());
				validationResult.add(violation2);
			}
		}

		return validationResult;
	}

}
