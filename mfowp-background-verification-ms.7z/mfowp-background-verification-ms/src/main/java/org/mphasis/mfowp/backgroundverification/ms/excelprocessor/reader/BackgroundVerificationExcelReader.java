package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader;

import java.io.IOException;
import java.util.List;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelHeaderMapper;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelReader;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelTemplate;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.ExcelFileInfo;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.ExcelHeader;
import org.springframework.web.multipart.MultipartFile;

public class BackgroundVerificationExcelReader<Backgroundverification> implements ExcelReader<Backgroundverification> {

	private static ExcelFileInfo fileInfo;
	private ExcelTemplate excelTemplate;

	static {

		fileInfo = new ExcelFileInfo("backgroundverification");
		fileInfo.addHeader(new ExcelHeader(1, "A", "EMPLOYEE NUMBER", "Integer"));
		fileInfo.addHeader(new ExcelHeader(2, "B", "FEDEX ID", "String"));
		fileInfo.addHeader(new ExcelHeader(3, "C", "EMPLOYEE NAME", "String"));
		fileInfo.addHeader(new ExcelHeader(4, "D", "DOJ", "Date"));
		fileInfo.addHeader(new ExcelHeader(5, "E", "POS LOC NAME", "String"));
		fileInfo.addHeader(new ExcelHeader(6, "F", "LOCATION", "String"));
		fileInfo.addHeader(new ExcelHeader(7, "G", "DM/CEM", "String"));
		fileInfo.addHeader(new ExcelHeader(8, "H", "PM", "String"));
		fileInfo.addHeader(new ExcelHeader(9, "I", "BGV Status", "String"));
		fileInfo.addHeader(new ExcelHeader(10, "J", "Red Reason", "String"));
		fileInfo.addHeader(new ExcelHeader(11, "K", "Date Of Completion", "Date"));
		fileInfo.addHeader(new ExcelHeader(12, "L", "BGV Aging", "Integer"));

	}

	public BackgroundVerificationExcelReader() {

	}

	@Override
	public void setSourceFile(MultipartFile sourceFile) throws IOException {
		ExcelHeaderMapper<ExcelHeader> excelHeaderMapper = new BackgroundVerificationExcelHeaderMapper();
		excelTemplate = new ExcelTemplate(excelHeaderMapper, sourceFile, fileInfo);
	}

	@Override
	public List<Backgroundverification> listRecords() {
		@SuppressWarnings("unchecked")
		List<Backgroundverification> backgroundverification = (List<Backgroundverification>) excelTemplate
				.lookup(new BackgroundVerificationExcelRowMapper());
		return backgroundverification;
	}

	@Override
	public Backgroundverification get(Integer rowNumber) {
		@SuppressWarnings("unchecked")
		Backgroundverification backgroundverification = (Backgroundverification) excelTemplate.lookup(rowNumber,
				new BackgroundVerificationExcelRowMapper());
		return backgroundverification;

	}

}