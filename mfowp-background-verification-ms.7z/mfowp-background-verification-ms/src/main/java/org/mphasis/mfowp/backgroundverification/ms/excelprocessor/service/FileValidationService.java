package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface FileValidationService {

	public List<?> validateExcel(String fileType,MultipartFile sourceFile) throws IOException;//to be comfirmed by tukaram

	public ResponseEntity<Object> validate(String fileType,MultipartFile file)
			throws IOException, FileNotFoundException;

	public String validateFile(MultipartFile file) throws FileNotFoundException, FileAlreadyExistsException;
	

}