package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.Api;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.IncorrectDateFormat;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service.BackgroundVerificationServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/background-verification")
public class BackgroundVerifictionApi {
	
	@Autowired
	BackgroundVerificationServiceImpl backgroundVerificationService;

	
	@PostMapping
	public ResponseEntity<BackgroundVerificationEntity> addbackgroundverification(
			@RequestBody BackgroundVerificationEntity entity) {
		BackgroundVerificationEntity backgroundverificationEntity = backgroundVerificationService
				.saveEmployeeNumber(entity);

		return new ResponseEntity<BackgroundVerificationEntity>(backgroundverificationEntity,
			HttpStatus.valueOf(200));

	}
	@GetMapping("/{employeeNumber}")
	public ResponseEntity<?> getbackgroundVerificationDataById(@PathVariable Integer employeeNumber) {
		Optional<BackgroundVerificationEntity> backgroundverificationEntity = backgroundVerificationService.getByEmployeeNumber(employeeNumber);
		if(backgroundverificationEntity.isPresent()) {
		return new ResponseEntity<>(backgroundverificationEntity,
				HttpStatus.valueOf(200));
		}else {
			return new ResponseEntity<>("Record Not found with Employee Number: "+employeeNumber ,
					HttpStatus.valueOf(404));
		}

	}
	@GetMapping("/getAll")
	public ResponseEntity<List<BackgroundVerificationEntity>> getAllbgv(){
		List<BackgroundVerificationEntity> bgvEntity=backgroundVerificationService.getAllBgv();
		return new ResponseEntity<List<BackgroundVerificationEntity>>(bgvEntity,HttpStatus.OK);
	}
	

	@GetMapping("/analytics/dashboard/count/dm")
	public ResponseEntity<?> dashboardDetailsCountByDm(@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate) throws IncorrectDateFormat {
		return backgroundVerificationService.backgroundVerificationDashboardDetailsCountByDm(startDate,endDate);
	}	
	
	
	@GetMapping("/analytics/dashboard/count")
	public ResponseEntity<?> bgvDashboardCount(@RequestParam("location") String location,
			@RequestParam("endDate") String endDate) throws IncorrectDateFormat {
		return backgroundVerificationService.bgvDashboardCount(location, endDate);
	}	
	
	@GetMapping("/analytics/dashboard")
	public ResponseEntity<?> dashboardDetailsCount(@RequestParam String startDate,@RequestParam String endDate) throws IncorrectDateFormat {
		return backgroundVerificationService.backgroundVerificationDashboardDetailsCount(startDate,endDate);
	}	
	
	@PutMapping("/reason/{employeeNumber}")
	public ResponseEntity<BackgroundVerificationEntity> updatebackgroundVerificationData(@PathVariable Integer employeeNumber,
			@RequestBody BackgroundVerificationEntity entity) {

		BackgroundVerificationEntity backgroundverificationEntity = backgroundVerificationService
				.updateEmployeeDetails(entity, employeeNumber);
		return new ResponseEntity<BackgroundVerificationEntity>(backgroundverificationEntity, HttpStatus.valueOf(200));

	}

	@DeleteMapping("/{backgroundverificationId}")
	public ResponseEntity<Boolean> deletebackgroundVerificationData(@PathVariable String backgroundverificationId)  {
		Boolean backgroundverification = backgroundVerificationService.deleteByEmployeeNumber(backgroundverificationId);
		return new ResponseEntity<>(backgroundverification, HttpStatus.valueOf(200));
	}

	@GetMapping("/paging")
	public Page<BackgroundVerificationEntity> findAll(@RequestParam String startDate,@RequestParam String endDate,@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "3") int size) throws ParseException {
		Pageable paging = PageRequest.of(page, size);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		Date startDate1 = null;
		Date endDate1 = null;
		startDate1 = formatter.parse(startDate);
		endDate1 = formatter.parse(endDate);
	return backgroundVerificationService.getByFromDateandToDate(startDate1,endDate1 ,paging);

	}

	
}

