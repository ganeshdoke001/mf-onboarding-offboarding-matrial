package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelException;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelReader;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.mapper.BackgroundVerificationMapperImpl;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.BackgroundVerification;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader.BackgroundVerificationExcelReader;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.repository.BackgroundVerificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileProcessorServiceImpl implements FileProcessorService {

	private ExcelReader<BackgroundVerification> backgroundVerificationReader = new BackgroundVerificationExcelReader<BackgroundVerification>();

	@Autowired
	private FilePersistanceService filePersistanceService;

	@Autowired
	private BackgroundVerificationRepository backgroundVerificationRepository;

	@Autowired
	private BackgroundVerificationMapperImpl backgroundVerificationMapperImpl;

	@Autowired
	private FileValidationService fileValidationService;

	public List<BackgroundVerification> process( MultipartFile sourceFile) throws IOException {

		fileValidationService.validateFile(sourceFile);

		List<BackgroundVerification> backgroundVerifications = null;
		
		//if (fileType.equalsIgnoreCase("backgroundVerification")) {
			backgroundVerificationReader.setSourceFile(sourceFile);
			if(backgroundVerificationReader != null) {
				
				backgroundVerifications = backgroundVerificationReader.listRecords();
			}
	
		filePersistanceService.persistFile( sourceFile);

		for (int i = 0; i < backgroundVerifications.size(); i++) 
		{
			BackgroundVerification backgroundVerificationCheck = backgroundVerifications.get(i);
			BackgroundVerificationEntity backgroundVerificationEntity = new BackgroundVerificationEntity();
			Optional<BackgroundVerificationEntity>backgroundVerificationEntityOptional = backgroundVerificationRepository.findByEmployeeNumber(backgroundVerificationCheck.getEmployeeNumber());
			if (backgroundVerificationEntityOptional.isPresent()) {
				backgroundVerificationEntity = backgroundVerificationEntityOptional.get();
				backgroundVerificationEntity = backgroundVerificationMapperImpl.BackgroundVerificationtoEmployee(backgroundVerificationCheck);
				backgroundVerificationEntity.setBackgroundverificationId(
				backgroundVerificationEntityOptional.get().getBackgroundverificationId());
				backgroundVerificationCheck.setStatus("update");
				backgroundVerificationEntity.setStatus("update");

				backgroundVerificationRepository.save(backgroundVerificationEntity);
				

				
			} else {
				backgroundVerificationCheck.setStatus("New");
				backgroundVerificationRepository.save(
						backgroundVerificationMapperImpl.BackgroundVerificationtoEmployee(backgroundVerificationCheck));

			}
		}
		
		return backgroundVerifications;

	}

	@Override
	public ResponseEntity<Object> uploadFile( MultipartFile file)
			throws IOException, FileNotFoundException {
		List<?> data = null;

		try {
			data = process( file);
		} catch (ExcelException e) {
			e.getErrors();
			return new ResponseEntity<Object>(e.getErrors(), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return new ResponseEntity<Object>(data, new HttpHeaders(), HttpStatus.OK);
		

	}

}
