package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.BackgroundVerificationEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.ExcelConstants;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.IncorrectDateFormat;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.helper.ServiceHelper;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.repository.BackgroundVerificationRepository;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.vo.EmpTransitionResponseVO;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.vo.NotificationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class BackgroundVerificationServiceImpl implements BackgroundVerificationService {

	@Autowired
	private BackgroundVerificationRepository backgroundverificationRepo;

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public BackgroundVerificationEntity saveEmployeeNumber(BackgroundVerificationEntity entity) {
		BackgroundVerificationEntity saveEntity = backgroundverificationRepo.save(entity);
		return saveEntity;

	}

	@Override
	public BackgroundVerificationEntity updateEmployeeDetails(BackgroundVerificationEntity entity, Integer id) {

		Optional<BackgroundVerificationEntity> backgroundverification = getByEmployeeNumber(id);
		if (backgroundverification.isPresent()) {
			entity.setBackgroundverificationId(backgroundverification.get().getBackgroundverificationId());
			entity.setEmployeeNumber(backgroundverification.get().getEmployeeNumber());
			entity.setFedEXId(backgroundverification.get().getFedEXId());
			entity.setEmployeeName(backgroundverification.get().getEmployeeName());
			entity.setDoj(backgroundverification.get().getDoj());
			entity.setPosLocName(backgroundverification.get().getPosLocName());
			entity.setLocation(backgroundverification.get().getLocation());
			entity.setDm(backgroundverification.get().getDm());
			entity.setPm(backgroundverification.get().getPm());
			entity.setBgvStatus(backgroundverification.get().getBgvStatus());
			entity.setBgvAging(backgroundverification.get().getBgvAging());
			entity.setStatus("update");
			if (!backgroundverification.get().getBgvStatus().equalsIgnoreCase("Red")) {
				entity.setredReason(null);

			}

		}
		BackgroundVerificationEntity saveEntity = backgroundverificationRepo.save(entity);
		return saveEntity;
	}

	@Override
	public Optional<BackgroundVerificationEntity> getByEmployeeNumber(Integer id) {
		Optional<BackgroundVerificationEntity> backgroundverification = backgroundverificationRepo
				.findByEmployeeNumber(id);
		return backgroundverification;

	}

	@Override
	public Boolean deleteByEmployeeNumber(String id) {
		BackgroundVerificationEntity backgroundverification = backgroundverificationRepo
				.findByBackgroundverificationId(id);
		if (backgroundverification != null) {
			backgroundverificationRepo.deleteById(id);
			return true;
		} else
			return false;

	}

	public Page<BackgroundVerificationEntity> getByFromDateandToDate(Date startDate1, Date endDate1, Pageable paging) {
		var query = new Query().with(paging);
		query.addCriteria(new Criteria().andOperator(Criteria.where("startDate").gte(startDate1).lte(endDate1)));
		return PageableExecutionUtils.getPage(mongoTemplate.find(query, BackgroundVerificationEntity.class), paging,
				() -> mongoTemplate.count(query.skip(0).limit(0), BackgroundVerificationEntity.class));
	}

	@Override
	public List<BackgroundVerificationEntity> getAllBgv() {
		List<BackgroundVerificationEntity> bgvEntity = backgroundverificationRepo.findAll();

		return bgvEntity;
	}

	@Override
	public ResponseEntity<?> bgvDashboardCount(String location, String endDate) throws IncorrectDateFormat {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		Date endDate1 = null;
		try {
			endDate1 = formatter.parse(endDate);
		} catch (DateTimeParseException | ParseException e) {
			throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		Query queryObj = new Query(
				Criteria.where("location").is(location).andOperator(Criteria.where("doj").lte(endDate1)));
		List<BackgroundVerificationEntity> result = mongoTemplate.find(queryObj, BackgroundVerificationEntity.class);
		Map<String, Object> responseObj = new HashMap<String, Object>();

		Map<String, Object> bgvStatusObj = ServiceHelper.getBgvStatusCount(result, location, endDate);

		if (result.size() > 0) {
			empTransitionResponseVO.setHighestSeverity(ExcelConstants.HIGH_SEVERITY_SUCCESS);
			empTransitionResponseVO.setData(bgvStatusObj);
			empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.HIGH_SEVERITY_SUCCESS,
					ExcelConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
		} else {
			empTransitionResponseVO.setHighestSeverity(ExcelConstants.HIGH_SEVERITY_SUCCESS);
			empTransitionResponseVO.setData(responseObj);
			empTransitionResponseVO
					.setNotification(new NotificationVO("NO DATA", ExcelConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public ResponseEntity<?> backgroundVerificationDashboardDetailsCount(String startDate, String endDate)
			throws IncorrectDateFormat {

		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();

			List<BackgroundVerificationEntity> result = backgroundverificationRepo.findAll();
			List<?> bgvStatusObj = ServiceHelper.getDashboardDetailsCount(result);

			if (result.size() > 0) {
				empTransitionResponseVO.setHighestSeverity(ExcelConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(bgvStatusObj);
				empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.HIGH_SEVERITY_SUCCESS,
						ExcelConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(ExcelConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", ExcelConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (DateTimeParseException e) {
			throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}

	}

	@Override
	public ResponseEntity<?> backgroundVerificationDashboardDetailsCountByDm(String startDate, String endDate)
			throws IncorrectDateFormat {
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();

		Map<String, Object> responseObj = new HashMap<String, Object>();
		// try {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		Date startDate1 = null;
		Date endDate1 = null;
		try {
			startDate1 = formatter.parse(startDate);
			endDate1 = formatter.parse(endDate);
		} catch (DateTimeParseException | ParseException e) {
			throw new IncorrectDateFormat(ExcelConstants.INCORRECT_DATE_FORMAT, "FAILURE");
		}
		Query queryObj = new Query();
		queryObj.addCriteria(Criteria.where("dateOfCompletion").gte(startDate1).lte(endDate1));
		List<BackgroundVerificationEntity> result = mongoTemplate.find(queryObj, BackgroundVerificationEntity.class);
		if (result.size() > 0) {
			List<String> dms = new ArrayList<String>();
			for (BackgroundVerificationEntity res : result) {
				dms.add(res.getDm());
			}
			System.out.println(dms);
			Set<String> setDms = new LinkedHashSet<>();
			setDms.addAll(dms);
			System.out.println(setDms);
			List<String> listDm = new ArrayList<>(setDms);
			List<Map<String, Object>> finalResponse = new ArrayList<>();
			for (int i = 0; i < listDm.size(); i++) {
				List<BackgroundVerificationEntity> dmNameList = null;
				String dmName = listDm.get(i);
				dmNameList = result.stream().filter(a -> (a.getDm().equalsIgnoreCase(dmName)))
						.collect(Collectors.toList());
				System.out.println("Dm Name: "+ dmName);
				System.out.println("count: "+dmNameList.size());
				List<?> bgvStatusObj = ServiceHelper.getDashboardDetailsCountByDm(dmNameList);
				Map<String, Object> response = new HashMap<>();
				response.put("dm", dmName);
				response.put("DmData", bgvStatusObj);
				finalResponse.add(response);
			}
			empTransitionResponseVO.setHighestSeverity(ExcelConstants.HIGH_SEVERITY_SUCCESS);
			empTransitionResponseVO.setData(finalResponse);
			empTransitionResponseVO.setNotification(new NotificationVO(ExcelConstants.HIGH_SEVERITY_SUCCESS,
					ExcelConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);

		} else {
			empTransitionResponseVO.setHighestSeverity(ExcelConstants.HIGH_SEVERITY_SUCCESS);
			empTransitionResponseVO.setData(responseObj);
			empTransitionResponseVO
					.setNotification(new NotificationVO("NO DATA", ExcelConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);

		}
	}

}