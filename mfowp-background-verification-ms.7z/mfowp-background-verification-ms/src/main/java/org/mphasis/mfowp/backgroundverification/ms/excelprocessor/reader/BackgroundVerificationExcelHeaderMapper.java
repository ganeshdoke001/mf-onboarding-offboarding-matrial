package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.core.ExcelHeaderMapper;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.model.ExcelHeader;

public class BackgroundVerificationExcelHeaderMapper implements ExcelHeaderMapper<ExcelHeader> {

	@Override
	public List<ExcelHeader> mapHeader(Row nextExcelHeaderRow, int rowHeaderNum) throws ExcelDataProcessorException {

		List<ExcelHeader> excelHeaders = new ArrayList<ExcelHeader>();

		ExcelHeader excelHeader;
		String valueStr;

		Cell cell = nextExcelHeaderRow.getCell(0);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("A");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}

		cell = nextExcelHeaderRow.getCell(1);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("B");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}

		cell = nextExcelHeaderRow.getCell(2);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("C");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(3);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("D");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(4);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("E");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(5);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("F");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(6);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("G");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(7);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("H");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(8);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("I");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		
		cell = nextExcelHeaderRow.getCell(9);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("J");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		
		cell = nextExcelHeaderRow.getCell(10);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("K");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		
		cell = nextExcelHeaderRow.getCell(11);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("L");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		
		return excelHeaders;
	}
}
