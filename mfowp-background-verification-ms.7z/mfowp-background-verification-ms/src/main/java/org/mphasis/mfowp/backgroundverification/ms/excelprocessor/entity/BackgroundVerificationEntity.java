package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document(collection = "Backgroundverification")
public class BackgroundVerificationEntity {
	
	@Id
	private String backgroundverificationId;

	private Integer employeeNumber;
	
	private String fedEXId;
	
	private String employeeName;

	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date doj;
	
	private String posLocName  ;

	private String location;

	private String dm;

	private String pm;
	
	private String bgvStatus;
	
	private String 	redReason;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date dateOfCompletion;
	
	
	private Integer bgvAging;
	
	private String status;

	public BackgroundVerificationEntity() {
		
	}

	public BackgroundVerificationEntity(String backgroundverificationId, Integer employeeNumber, String fedEXId,
			String employeeName, Date doj, String posLocName, String location, String dm, String pm, String bgvStatus,String redReason,
			Date dateOfCompletion,  Integer bgvAging, String status) {
		super();
		this.backgroundverificationId = backgroundverificationId;
		this.employeeNumber = employeeNumber;
		this.fedEXId = fedEXId;
		this.employeeName = employeeName;
		this.doj = doj;
		this.posLocName = posLocName;
		this.location = location;
		this.dm = dm;
		this.pm = pm;
		this.bgvStatus = bgvStatus;
		this.redReason = redReason;
		this.dateOfCompletion = dateOfCompletion;
		this.bgvAging = bgvAging;
		this.status = status;
	}

	public String getBackgroundverificationId() {
		return backgroundverificationId;
	}

	public void setBackgroundverificationId(String backgroundverificationId) {
		this.backgroundverificationId = backgroundverificationId;
	}

	public Integer getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getFedEXId() {
		return fedEXId;
	}

	public void setFedEXId(String fedEXId) {
		this.fedEXId = fedEXId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getPosLocName() {
		return posLocName;
	}

	public void setPosLocName(String posLocName) {
		this.posLocName = posLocName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDm() {
		return dm;
	}

	public void setDm(String dm) {
		this.dm = dm;
	}

	public String getPm() {
		return pm;
	}

	public void setPm(String pm) {
		this.pm = pm;
	}

	public String getBgvStatus() {
		return bgvStatus;
	}

	public void setBgvStatus(String bgvStatus) {
		this.bgvStatus = bgvStatus;
	}
	
	public String getredReason() {
		return redReason;
	}

	public void setredReason(String redReason) {
		this.redReason = redReason;
	}

	public Date getDateOfCompletion() {
		return dateOfCompletion;
	}

	public void setDateOfCompletion(Date dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}

	

	public Integer getBgvAging() {
		return bgvAging;
	}

	public void setBgvAging(Integer bgvAging) {
		this.bgvAging = bgvAging;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "BackgroundVerificationEntity [backgroundverificationId=" + backgroundverificationId
				+ ", employeeNumber=" + employeeNumber + ", fedEXId=" + fedEXId + ", employeeName=" + employeeName
				+ ", doj=" + doj + ", posLocName=" + posLocName + ", location=" + location + ", dm=" + dm + ", pm=" + pm
				+ ", bgvStatus=" + bgvStatus + ", dateOfCompletion=" + dateOfCompletion + ", redReason=" + redReason
				+ ", bgvAging=" + bgvAging + ", status=" + status + "]";
	}

	
	
	}