package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.entity.FileEntity;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.ExcelConstants;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.exception.FileStorageException;
import org.mphasis.mfowp.backgroundverification.ms.excelprocessor.repository.FileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FilePersistanceServiceImpl implements FilePersistanceService {

	@Autowired
	private FileRepository fileRepository;

	@Override
	public FileEntity persistFile( MultipartFile file) {
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		try {
			FileEntity fileEntity = new FileEntity(fileName,  file.getBytes(), "You", getDate(),
					"uploaded", true,file.getContentType());
			fileRepository.save(fileEntity);
			return fileEntity;
		} catch (IOException ex) {
			throw new FileStorageException(ExcelConstants.FILE_NOT_STORED);
		}
	}

	@Override
	public ResponseEntity<Map<String, String>> deleteFileByID(String id) {
		Map<String, String> map = new HashMap<>();
		if (fileRepository.existsById(id)) {
			fileRepository.deleteById(id);
			map.put(ExcelConstants.FILE_DELETE, id);
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		} else {
			map.put(ExcelConstants.FILE_NOT_AVBL, id);
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.FORBIDDEN);
		}
	}

	@Override
	public ResponseEntity<String> deleteFiles(List<String> files) {
		for (int i = 0; i <= files.size() - 1; i++) {
			fileRepository.deleteById(files.get(i));
		}
		return new ResponseEntity<String>(ExcelConstants.FILES_DELETE, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<FileEntity>> getAllFiles() {
		return new ResponseEntity<List<FileEntity>>(fileRepository.findAll(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<FileEntity> getFileById(String id) throws FileNotFoundException {
		FileEntity file = fileRepository.findById(id)
				.orElseThrow(() -> new FileNotFoundException(ExcelConstants.FILE_NOT_FOUND));
		return ResponseEntity.ok(file);
	}

	public String getDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);

	}

}
