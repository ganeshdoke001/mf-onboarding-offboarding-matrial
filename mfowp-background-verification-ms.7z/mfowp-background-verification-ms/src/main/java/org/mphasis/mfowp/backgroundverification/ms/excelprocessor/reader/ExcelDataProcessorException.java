package org.mphasis.mfowp.backgroundverification.ms.excelprocessor.reader;

public class ExcelDataProcessorException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public ExcelDataProcessorException(){
		
	}
}
