package org.mphasis.mfowp.backgroundverification.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfowpBackgroundVerificationMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
