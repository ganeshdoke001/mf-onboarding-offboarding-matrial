package org.mphasis.mfowp.excelprocessor.ms.excel.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class Wps {

	@NotNull(message = "EMPLOYE NUMBER::should not be empty")
	private Integer empNumber;

	@NotNull
	@NotEmpty(message = "FedEx LDAP ID Deactivated::should not be empty")
	private String fedExLDAPIdDeactivated;

	@NotNull
	@NotEmpty(message = "FedEx Email ID (OSV) Deactivated::should not be empty")
	private String fedExEmailIdDeactivated;

	@NotNull
	@NotEmpty(message = "Mphasis VPN Deactivated::should not be empty")
	private String mphasisVPNDeactivated;

	@NotNull(message = "FedEx MVOIP Deactivated ::should not be empty")
	private String fedExMVOIPDeactivated ;

	@NotNull
	@NotEmpty(message = "FedEx Laptop Handed Over::should not be empty")
	private String fedExLaptopHandedOver;

	@NotNull
	@NotEmpty(message = "Any customer supplied  Devices  Handed Over::should not be empty")
	private String anyCustomerSuppliedDevicesHandedOver;

	@NotNull
	@NotEmpty(message = "Access to  FedEx ODC Deactivated::should not be empty")
	private String accessToFedExODCDeactivated;

	@NotNull
	@NotEmpty(message = "Mphasis Email Id Deactivated::should not be empty")
	private String mphasisEmailIdDeactivated;
	
	@NotNull
	@NotEmpty(message = "User Id Deactivated::should not be empty")
	private String userIdDeactivated;
	
	@NotNull
	@NotEmpty(message = "Mphasis Laptop Handed Over::should not be empty")
	private String mphasisLaptopHandedOver;
	
	@NotNull
	@NotEmpty(message = "Access to Main Gate Deactivated::should not be empty")
	private String AccesstoMainGateDeactivated;
	
	private String others;
	
	private String status;

	public Integer getEmpNumber() {
		return empNumber;
	}

	public void setEmpNumber(Integer empNumber) {
		this.empNumber = empNumber;
	}

	public String getFedExLDAPIdDeactivated() {
		return fedExLDAPIdDeactivated;
	}

	public void setFedExLDAPIdDeactivated(String fedExLDAPIdDeactivated) {
		this.fedExLDAPIdDeactivated = fedExLDAPIdDeactivated;
	}

	public String getFedExEmailIdDeactivated() {
		return fedExEmailIdDeactivated;
	}

	public void setFedExEmailIdDeactivated(String fedExEmailIdDeactivated) {
		this.fedExEmailIdDeactivated = fedExEmailIdDeactivated;
	}

	public String getMphasisVPNDeactivated() {
		return mphasisVPNDeactivated;
	}

	public void setMphasisVPNDeactivated(String mphasisVPNDeactivated) {
		this.mphasisVPNDeactivated = mphasisVPNDeactivated;
	}

	public String getFedExMVOIPDeactivated() {
		return fedExMVOIPDeactivated;
	}

	public void setFedExMVOIPDeactivated(String fedExMVOIPDeactivated) {
		this.fedExMVOIPDeactivated = fedExMVOIPDeactivated;
	}

	public String getFedExLaptopHandedOver() {
		return fedExLaptopHandedOver;
	}

	public void setFedExLaptopHandedOver(String fedExLaptopHandedOver) {
		this.fedExLaptopHandedOver = fedExLaptopHandedOver;
	}

	public String getAnyCustomerSuppliedDevicesHandedOver() {
		return anyCustomerSuppliedDevicesHandedOver;
	}

	public void setAnyCustomerSuppliedDevicesHandedOver(String anyCustomerSuppliedDevicesHandedOver) {
		this.anyCustomerSuppliedDevicesHandedOver = anyCustomerSuppliedDevicesHandedOver;
	}

	public String getAccessToFedExODCDeactivated() {
		return accessToFedExODCDeactivated;
	}

	public void setAccessToFedExODCDeactivated(String accessToFedExODCDeactivated) {
		this.accessToFedExODCDeactivated = accessToFedExODCDeactivated;
	}

	public String getMphasisEmailIdDeactivated() {
		return mphasisEmailIdDeactivated;
	}

	public void setMphasisEmailIdDeactivated(String mphasisEmailIdDeactivated) {
		this.mphasisEmailIdDeactivated = mphasisEmailIdDeactivated;
	}

	public String getUserIdDeactivated() {
		return userIdDeactivated;
	}

	public void setUserIdDeactivated(String userIdDeactivated) {
		this.userIdDeactivated = userIdDeactivated;
	}

	public String getMphasisLaptopHandedOver() {
		return mphasisLaptopHandedOver;
	}

	public void setMphasisLaptopHandedOver(String mphasisLaptopHandedOver) {
		this.mphasisLaptopHandedOver = mphasisLaptopHandedOver;
	}

	public String getAccesstoMainGateDeactivated() {
		return AccesstoMainGateDeactivated;
	}

	public void setAccesstoMainGateDeactivated(String accesstoMainGateDeactivated) {
		AccesstoMainGateDeactivated = accesstoMainGateDeactivated;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Wps(@NotNull(message = "EMPLOYE NUMBER::should not be empty") Integer empNumber,
			@NotNull @NotEmpty(message = "FedEx LDAP ID Deactivated::should not be empty") String fedExLDAPIdDeactivated,
			@NotNull @NotEmpty(message = "FedEx Email ID (OSV) Deactivated::should not be empty") String fedExEmailIdDeactivated,
			@NotNull @NotEmpty(message = "Mphasis VPN Deactivated::should not be empty") String mphasisVPNDeactivated,
			@NotNull(message = "FedEx MVOIP Deactivated ::should not be empty") String fedExMVOIPDeactivated,
			@NotNull @NotEmpty(message = "FedEx Laptop Handed Over::should not be empty") String fedExLaptopHandedOver,
			@NotNull @NotEmpty(message = "Any customer supplied  Devices  Handed Over::should not be empty") String anyCustomerSuppliedDevicesHandedOver,
			@NotNull @NotEmpty(message = "Access to  FedEx ODC Deactivated::should not be empty") String accessToFedExODCDeactivated,
			@NotNull @NotEmpty(message = "Mphasis Email Id Deactivated::should not be empty") String mphasisEmailIdDeactivated,
			@NotNull @NotEmpty(message = "User Id Deactivated::should not be empty") String userIdDeactivated,
			@NotNull @NotEmpty(message = "Mphasis Laptop Handed Over::should not be empty") String mphasisLaptopHandedOver,
			@NotNull @NotEmpty(message = "Access to Main Gate Deactivated::should not be empty") String accesstoMainGateDeactivated,
			String others, String status) {
		super();
		this.empNumber = empNumber;
		this.fedExLDAPIdDeactivated = fedExLDAPIdDeactivated;
		this.fedExEmailIdDeactivated = fedExEmailIdDeactivated;
		this.mphasisVPNDeactivated = mphasisVPNDeactivated;
		this.fedExMVOIPDeactivated = fedExMVOIPDeactivated;
		this.fedExLaptopHandedOver = fedExLaptopHandedOver;
		this.anyCustomerSuppliedDevicesHandedOver = anyCustomerSuppliedDevicesHandedOver;
		this.accessToFedExODCDeactivated = accessToFedExODCDeactivated;
		this.mphasisEmailIdDeactivated = mphasisEmailIdDeactivated;
		this.userIdDeactivated = userIdDeactivated;
		this.mphasisLaptopHandedOver = mphasisLaptopHandedOver;
		AccesstoMainGateDeactivated = accesstoMainGateDeactivated;
		this.others = others;
		this.status = status;
	}

	public Wps() {
		super();
	}
	
	

	
	
}