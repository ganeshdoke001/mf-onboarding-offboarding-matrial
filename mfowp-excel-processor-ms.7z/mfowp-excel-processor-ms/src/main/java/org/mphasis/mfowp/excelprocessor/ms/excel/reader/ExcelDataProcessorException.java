package org.mphasis.mfowp.excelprocessor.ms.excel.reader;

public class ExcelDataProcessorException extends RuntimeException {
	public ExcelDataProcessorException(){
		
	}
}
