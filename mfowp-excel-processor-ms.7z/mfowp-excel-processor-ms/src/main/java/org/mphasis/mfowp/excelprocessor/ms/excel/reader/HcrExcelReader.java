package org.mphasis.mfowp.excelprocessor.ms.excel.reader;

import java.io.IOException;
import java.util.List;

import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelHeaderMapper;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelTemplate;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelFileInfo;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelHeader;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;
import org.springframework.web.multipart.MultipartFile;

public class HcrExcelReader<Hcr> implements ExcelReader<Hcr> {
	private static ExcelFileInfo fileInfo;
	private ExcelTemplate excelTemplate;

	static {
		fileInfo = new ExcelFileInfo("hcr");
		fileInfo.addHeader(new ExcelHeader(1, "B", "EMPLOYEE NUMBER", "Long"));
		fileInfo.addHeader(new ExcelHeader(2, "C", "EMPLOYEE NAME", "String"));
		fileInfo.addHeader(new ExcelHeader(3, "D", "DATE OF JOINING", "Date"));
		fileInfo.addHeader(new ExcelHeader(4, "E", "LOCATION", "String"));
		fileInfo.addHeader(new ExcelHeader(5, "F", "LOCATION", "String"));
		fileInfo.addHeader(new ExcelHeader(6, "G", "POS ONSITE OFFSHORE", "String"));
		fileInfo.addHeader(new ExcelHeader(7, "H", "POS LOC NAME", "String"));
		fileInfo.addHeader(new ExcelHeader(13, "N", "GRADE DESC", "String"));
		fileInfo.addHeader(new ExcelHeader(33, "AH", "DM EMP NO", "Long"));
		fileInfo.addHeader(new ExcelHeader(34, "AI", "DM EMP NAME", "String"));
		fileInfo.addHeader(new ExcelHeader(76, "BY", "PM", "String"));
		// offboarding changes start by MJ
		fileInfo.addHeader(new ExcelHeader(79, "CB", "Release date in Prism", "Date"));
		fileInfo.addHeader(new ExcelHeader(83, "CF", "SEPARATION DATE", "Date"));
		fileInfo.addHeader(new ExcelHeader(90, "CM", "Employee Separated/Out-Transfer", "String"));
		fileInfo.addHeader(new ExcelHeader(91, "CN", "PM EMP NO", "Long"));
        //offboarding changes end by MJ

//		fileInfo.addHeader(new ExcelHeader("I", 8,"EMPLOYEE TYPE", "String"));
//		fileInfo.addHeader(new ExcelHeader("J", 9,"ROLE DESC", "String"));
//		fileInfo.addHeader(new ExcelHeader("K", 10,"WORK ALLOCATION", "Integer"));
//		fileInfo.addHeader(new ExcelHeader("L", 11,"BILL ALLOCATION", "Integer"));
//		fileInfo.addHeader(new ExcelHeader("M", 12,"BILLING TYPE ROLE", "String"));
//		fileInfo.addHeader(new ExcelHeader("0", 14,"PROJ ROLE", "String"));
//		fileInfo.addHeader(new ExcelHeader("P", 15,"END CLIENT ID", "Long"));
//		fileInfo.addHeader(new ExcelHeader("Q", 16,"END CLIENT NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader("R", 17,"END CLIENT GROUP ID", "Long"));
//		fileInfo.addHeader(new ExcelHeader("S", 18,"END CLIENT GROUP NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader("T", 19,"MARKETING UNIT", "String"));
//		fileInfo.addHeader(new ExcelHeader("U", 20,"SUB MARKETING UNIT", "String"));
//		fileInfo.addHeader(new ExcelHeader("V", 21,"CHANNEL", "String"));
//		fileInfo.addHeader(new ExcelHeader("W", 22,"BUSINESS ORGANIZATION", "String"));
//		fileInfo.addHeader(new ExcelHeader("X", 23,"SERVICE TYPE", "String"));
//		fileInfo.addHeader(new ExcelHeader("Y", 24,"DELIVERY UNIT", "String"));
//		fileInfo.addHeader(new ExcelHeader("Z", 25,"PROJECT NUM", "Long"));
//		fileInfo.addHeader(new ExcelHeader("AA", 26,"PROJECT NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader("AB", 27,"ASSIGNMENT START DATE", "Date"));
//		fileInfo.addHeader(new ExcelHeader("AC", 28,"ASSIGNMENT RELEASE DATE", "Date"));
//		fileInfo.addHeader(new ExcelHeader("AD", 29,"RESOURSE ALLOCATION STATUS", "String"));
//		fileInfo.addHeader(new ExcelHeader("AE", 30,"PROJECT TYPE", "String"));
//		fileInfo.addHeader(new ExcelHeader("AF", 31,"PROJECT BILL FLAG", "String"));
//		fileInfo.addHeader(new ExcelHeader("AG", 32,"PROJECT BILLING CATEGORY", "String"));
//		fileInfo.addHeader(new ExcelHeader("AH", 33,"DM EMP NO", "Long"));
//		fileInfo.addHeader(new ExcelHeader("AJ", 35,"VL EMP NO", "Long"));
//		fileInfo.addHeader(new ExcelHeader("AK", 36,"VL EMP NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader("AL", 37,"DH EMP NO", "Long"));
//		fileInfo.addHeader(new ExcelHeader("AM", 38,"DH EMP NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader("AN", 39,"PARCTICE", "String"));
//		fileInfo.addHeader(new ExcelHeader("AO", 40,"SUB_PARCTICE", "String"));
//		fileInfo.addHeader(new ExcelHeader("AP", 41,"DOH_Level", "String"));
//		fileInfo.addHeader(new ExcelHeader("AQ", 42,"ASSIGNMENT_ID", "Long"));
//		fileInfo.addHeader(new ExcelHeader("AR", 43,"EMPLOYEE_CATEGORY", "String"));
//		fileInfo.addHeader(new ExcelHeader("AS", 44,"OP_COMM_MODEL", "String"));
//		fileInfo.addHeader(new ExcelHeader("AT", 45,"OP_SERV_TYPE", "String"));
//		fileInfo.addHeader(new ExcelHeader("AU", 46,"FTE", "String"));
//		fileInfo.addHeader(new ExcelHeader("AV", 47,"TOWER", "String"));
//		fileInfo.addHeader(new ExcelHeader("AW", 48,"FRESHERS", "String"));
//		fileInfo.addHeader(new ExcelHeader("AX", 49,"TIMES", "Integer"));
//		fileInfo.addHeader(new ExcelHeader("AY", 50,"HEAD COUNT", "Integer"));
//		fileInfo.addHeader(new ExcelHeader("AZ", 51,"Freshers HC", "Integer"));
//		fileInfo.addHeader(new ExcelHeader("BA", 52,"Sum of BILL ALLOCATION", "Integer"));
//		fileInfo.addHeader(new ExcelHeader("BB", 53,"PROJECT BILL FLAG", "String"));
//		fileInfo.addHeader(new ExcelHeader("BC", 54,"CATEGORY", "String"));
//		fileInfo.addHeader(new ExcelHeader("BD", 55,"Channel", "String"));
//		fileInfo.addHeader(new ExcelHeader("BE", 56,"SMU", "String"));
//		fileInfo.addHeader(new ExcelHeader("BF", 57,"DU Leader1", "String"));
//		fileInfo.addHeader(new ExcelHeader("BG", 58,"DU Leader2", "String"));
//		fileInfo.addHeader(new ExcelHeader("BH", 59,"CATEGORY2", "String"));
//		fileInfo.addHeader(new ExcelHeader("BI", 60,"Section", "String"));
//		fileInfo.addHeader(new ExcelHeader("BJ", 61,"Section C&D", "String"));
//		fileInfo.addHeader(new ExcelHeader("BK", 62,"SMU 2", "String"));
//		fileInfo.addHeader(new ExcelHeader("BL", 63,"OPERATIONAL CLIENT GROUP", "String"));
//		fileInfo.addHeader(new ExcelHeader("BM", 64,"EXPENSE_TYPE", "String"));
//		fileInfo.addHeader(new ExcelHeader("BN", 65,"RES PRACTICE", "String"));
//		fileInfo.addHeader(new ExcelHeader("BO", 66,"CREATION DATE", "DATE"));
//		fileInfo.addHeader(new ExcelHeader("BP", 67,"SUPERVISOR NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader("BQ", 68,"RESOURCE COUNTRY", "String"));
//		fileInfo.addHeader(new ExcelHeader("BR", 69,"EMAIL ADDRESS", "String"));
//		fileInfo.addHeader(new ExcelHeader("BS", 70,"Bussiness Unit", "String"));
//		fileInfo.addHeader(new ExcelHeader("BT", 71,"MU Name", "String"));
//		fileInfo.addHeader(new ExcelHeader("BU", 72,"Market Unit Leader", "String"));
//		fileInfo.addHeader(new ExcelHeader("BV", 73,"AGING", "INTEGER"));
//		fileInfo.addHeader(new ExcelHeader("BW", 74,"AGING BUCKET", "INTEGER"));
//		fileInfo.addHeader(new ExcelHeader("BY", 76,"Critical employee flag", "String"));
//        fileInfo.addHeader(new ExcelHeader("BZ", 77,"Billing start date in Prism", "Date"));
//        fileInfo.addHeader(new ExcelHeader("CA", 78,"Release date in Prism", "Date"));
//        fileInfo.addHeader(new ExcelHeader("CB", 79,"Billing month", "Date"));
//        fileInfo.addHeader(new ExcelHeader("CC", 80,"Release month", "Date"));
//        fileInfo.addHeader(new ExcelHeader("CD", 81,"private Date billingMonth", "String"));
	}

	public HcrExcelReader() {

	}

	@Override
	public void setSourceFile(MultipartFile sourceFile) throws IOException {
		ExcelHeaderMapper<ExcelHeader> excelHeaderMapper = new HcrExcelHeaderMapper();
		excelTemplate = new ExcelTemplate(excelHeaderMapper, sourceFile, fileInfo);
	}

	@Override
	public Hcr get(Integer rowNumber) {
		Hcr hcr = (Hcr) excelTemplate.lookup(rowNumber, new HcrExcelRowMapper());
		return hcr;
	}

	@Override
	public List<Hcr> listRecords() {
		List<Hcr> hcrs = (List<Hcr>) excelTemplate.lookup(new HcrExcelRowMapper(), "hcr");
		return hcrs;
	}

}
