package org.mphasis.mfowp.excelprocessor.ms.excel.reader;

import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelRowMapper;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;

public class HcrExcelRowMapper implements ExcelRowMapper<Hcr> {

	@Override
	public Hcr mapRow(Row nextRow, int rowNum) throws ExcelDataProcessorException {
//		422 (Unprocessable Entity)
		Hcr hcr = new Hcr();
		Integer valueInt;
		String valueStr;
		Date valueDate;

		Cell cell = nextRow.getCell(1);
		if(cell != null) {
		valueInt = (int) cell.getNumericCellValue();
		hcr.setEmpNumber(valueInt);
		}
		cell = nextRow.getCell(2);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setEmpName(valueStr);
		}
		cell = nextRow.getCell(3);
		if(cell != null) {
		valueDate = cell.getDateCellValue();
		hcr.setDateOfJoining(valueDate);
		}
		cell = nextRow.getCell(4);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setLocation1(valueStr);
		}
		cell = nextRow.getCell(5);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setLocation2(valueStr);
		}
		cell = nextRow.getCell(6);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setPosOnsiteOffsure(valueStr);
		}
		cell = nextRow.getCell(7);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setPosLocName(valueStr);
		}
		cell = nextRow.getCell(13);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setGradeDesc(valueStr);
		}
		//MJ
		cell = nextRow.getCell(33);
		if(cell != null) {
		valueInt = (int) cell.getNumericCellValue();
		hcr.setDMEmpNumber(valueInt);
		}//MJ
		cell = nextRow.getCell(34);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setDMEmpName(valueStr);
		}
		cell = nextRow.getCell(76);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setPM(valueStr);
		}
		//MJ
		cell = nextRow.getCell(79);
		if(cell != null) {
		valueDate = cell.getDateCellValue();
		hcr.setReleaseDateInPRISM(valueDate);
		}
		cell = nextRow.getCell(83);
		if(cell != null) {
		valueDate = cell.getDateCellValue();
		hcr.setSeperationDate(valueDate);
		}
		//MJ
		cell = nextRow.getCell(90);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setSeparationReason(valueStr);
		}
		cell = nextRow.getCell(91);
		if(cell != null) {
		valueInt = (int) cell.getNumericCellValue();
		hcr.setPMEmpNumber(valueInt);
		}
		return hcr;
		
	}

}
