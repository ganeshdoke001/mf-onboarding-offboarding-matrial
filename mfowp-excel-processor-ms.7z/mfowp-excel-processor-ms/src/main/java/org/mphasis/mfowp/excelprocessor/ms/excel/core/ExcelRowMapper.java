package org.mphasis.mfowp.excelprocessor.ms.excel.core;

import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.excelprocessor.ms.excel.reader.ExcelDataProcessorException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface ExcelRowMapper<T> {

	@Nullable
	T mapRow(Row nextExcelRow, int rowNum) throws ExcelDataProcessorException;

}