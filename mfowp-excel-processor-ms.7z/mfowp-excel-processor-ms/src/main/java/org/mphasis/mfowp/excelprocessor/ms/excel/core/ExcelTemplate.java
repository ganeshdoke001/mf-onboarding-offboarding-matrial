package org.mphasis.mfowp.excelprocessor.ms.excel.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelFileInfo;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelHeader;
import org.mphasis.mfowp.excelprocessor.ms.excel.reader.ExcelDataProcessorException;
import org.springframework.lang.Nullable;
import org.springframework.web.multipart.MultipartFile;

public class ExcelTemplate {

	@Nullable
	private static MultipartFile sourceFile;
	private XSSFWorkbook workbook;
	private ExcelFileInfo fileInfo;
	private ExcelHeaderMapper<ExcelHeader> excelHeaderMapper;
	ExcelValidator excelValidator;

	public ExcelTemplate(ExcelHeaderMapper<ExcelHeader> excelHeaderMapper, MultipartFile sourceFile) throws IOException {
		setExcelHeaderMapper(excelHeaderMapper);
		setSourceFile(sourceFile);
		excelValidator = new ExcelValidator(); 
		ValidationResult validationResult= excelValidator.validateExcelFile(sourceFile); 
		if(!validationResult.isSuccess()) {
			throw new ExcelException("Invalid File", validationResult.getViolations());
		}
		setWorkbook(new XSSFWorkbook(sourceFile.getInputStream()));
	}

	public ExcelTemplate(ExcelHeaderMapper<ExcelHeader> excelHeaderMapper,MultipartFile sourceFile, ExcelFileInfo fileInfo) throws IOException {
		this(excelHeaderMapper,sourceFile);
		this.fileInfo = fileInfo;
		XSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = sheet.iterator();
		if(iterator.hasNext()) {
			Row nextRow = iterator.next();
			List<ExcelHeader> excelHeader = getExcelHeaderMapper().mapHeader(nextRow, 0);
			ValidationResult validationResult= excelValidator.validateExcelHeaders(fileInfo.getHeaders() ,excelHeader); 
			if(!validationResult.isSuccess()) {
				throw new ExcelException("Invalid excel file, manatory comlumns/ headers are missing",validationResult.getViolations());
			}
		}
	}

	public MultipartFile getSourceFile() {
		return sourceFile;
	}

	public void setSourceFile(MultipartFile sourceFile) {
		this.sourceFile = sourceFile;
	}

	public XSSFWorkbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(XSSFWorkbook workbook) {
		this.workbook = workbook;
	}
	

	public ExcelHeaderMapper<ExcelHeader> getExcelHeaderMapper() {
		return excelHeaderMapper;
	}

	public void setExcelHeaderMapper(ExcelHeaderMapper<ExcelHeader> excelHeaderMapper) {
		this.excelHeaderMapper = excelHeaderMapper;
	}

	public <T> List<T> lookup(ExcelRowMapper<T> rowMapper, String fileType) throws ExcelDataProcessorException {
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        List<T> excelRecors = new ArrayList<T>();
        T t;
        int counter = 0;
        iterator.next();
        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            counter = counter + 1;
            t = rowMapper.mapRow(nextRow, counter);
            excelRecors.add(t);
        }
        System.out.println("fileInfo.getHeaders()"+fileInfo.getHeaders());
        ValidationResult validationResult = excelValidator.validateExcelData(fileInfo.getHeaders(), excelRecors, fileType);
        if (!validationResult.isSuccess()) {
                throw new ExcelException("Invalid excel data, data elements must be valid", validationResult.getViolations());
        }
        return excelRecors;
        }
        
   public <T> T lookup(Integer index, ExcelRowMapper<T> rowMapper) throws ExcelDataProcessorException {

       XSSFSheet sheet = workbook.getSheetAt(0);
//        TODO read and return index
        Iterator<Row> iterator = sheet.iterator();
        T t = null;
        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            t = rowMapper.mapRow(nextRow, 0);
        }
        return t;
    }

}