package org.mphasis.mfowp.excelprocessor.ms.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "AssetManagement")
public class AssetEntity {
	
	@Id
	private int assetId;
	private String assetName;
	private String assetStatus;
	
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetStatus() {
		return assetStatus;
	}
	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}
	public AssetEntity(int assetId, String assetName, String assetStatus) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetStatus = assetStatus;
	}
	public AssetEntity() {
		super();
	}

	
}
