package org.mphasis.mfowp.excelprocessor.ms;

import org.mphasis.mfowp.excelprocessor.ms.mapper.HcrEmployeeMapperImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MfowpExcelProcessorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MfowpExcelProcessorServiceApplication.class, args);
	}
	
	@Bean
	public HcrEmployeeMapperImpl hcrEmployeeMapperImpl() {
		return new HcrEmployeeMapperImpl();
	}

}
