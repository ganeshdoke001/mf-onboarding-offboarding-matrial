package org.mphasis.mfowp.excelprocessor.ms.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface FileProcessorService {
	
	public List<?> process(String fileType, MultipartFile sourceFile) throws IOException;
	
//	public ResponseEntity<Object> uploadFile(String fileType, MultipartFile file)
//			throws IOException, FileNotFoundException;//by  manoj
	
	public ResponseEntity<Object> uploadFile(String fileType, MultipartFile file)
			throws IOException, FileNotFoundException;//by  manoj
	
}
