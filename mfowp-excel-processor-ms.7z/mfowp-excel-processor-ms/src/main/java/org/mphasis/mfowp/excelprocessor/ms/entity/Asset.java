package org.mphasis.mfowp.excelprocessor.ms.entity;

public class Asset {
	
	private String assetId;
	private String assetName;
	private String assetStatus;
	private String assetCategory;
	public Asset(String assetId, String assetName, String assetStatus, String assetCategory) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetStatus = assetStatus;
		this.assetCategory = assetCategory;
	}
	public Asset() {
		super();
	}
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetStatus() {
		return assetStatus;
	}
	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}
	public String getAssetCategory() {
		return assetCategory;
	}
	public void setAssetCategory(String assetCategory) {
		this.assetCategory = assetCategory;
	}
	@Override
	public String toString() {
		return "Asset [assetId=" + assetId + ", assetName=" + assetName + ", assetStatus=" + assetStatus
				+ ", assetCategory=" + assetCategory + "]";
	}
	
	
	
}
