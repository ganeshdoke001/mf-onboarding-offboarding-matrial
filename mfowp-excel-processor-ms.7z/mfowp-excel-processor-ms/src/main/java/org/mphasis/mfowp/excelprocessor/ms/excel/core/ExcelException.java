package org.mphasis.mfowp.excelprocessor.ms.excel.core;

import java.util.ArrayList;
import java.util.List;

public class ExcelException extends RuntimeException {

	private static final long serialVersionUID = 91433452701327749L;
	List<Violation> errors = new ArrayList<Violation>();

	public ExcelException(String message) {
		super(message);
	}
	public ExcelException(Violation error) {
		super(error.getMessage());
		errors.add(error);
	}
	public ExcelException(String message, List<Violation> errors) {
		super(message);
		this.errors = errors;
	}
	public List<Violation> getErrors() {
		return errors;
	}
	public void setErrors(List<Violation> errors) {
		this.errors = errors;
	}
	
}
