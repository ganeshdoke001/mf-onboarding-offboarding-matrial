package org.mphasis.mfowp.excelprocessor.ms.excel.reader;

import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelRowMapper;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Wps;


public class WpsExcelRowMapper implements ExcelRowMapper<Wps> {

	@Override
	public Wps mapRow(Row nextRow, int rowNum) throws ExcelDataProcessorException {
//		422 (Unprocessable Entity)
		Wps hcr = new Wps();
		Integer valueInt;
		String valueStr;
		Date valueDate;

		
		Cell cell = nextRow.getCell(0);
		if(cell != null) {
		valueInt = (int) cell.getNumericCellValue();
		hcr.setEmpNumber(valueInt);
		}
		
		cell = nextRow.getCell(1);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setFedExLDAPIdDeactivated(valueStr);
		}

		cell = nextRow.getCell(2);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setFedExEmailIdDeactivated(valueStr);
		}

		cell = nextRow.getCell(3);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setMphasisVPNDeactivated(valueStr);
		}

		cell = nextRow.getCell(4);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setFedExMVOIPDeactivated(valueStr);
		}
		
		cell = nextRow.getCell(5);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setFedExLaptopHandedOver(valueStr);
		}

		cell = nextRow.getCell(6);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setAnyCustomerSuppliedDevicesHandedOver(valueStr);
		}

		cell = nextRow.getCell(7);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setAccessToFedExODCDeactivated(valueStr);
		}

		cell = nextRow.getCell(8);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setMphasisEmailIdDeactivated(valueStr);
		}

		cell = nextRow.getCell(9);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setUserIdDeactivated(valueStr);
		}

		cell = nextRow.getCell(10);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setMphasisLaptopHandedOver(valueStr);
		}
		
		cell = nextRow.getCell(11);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setAccesstoMainGateDeactivated(valueStr);
		}
		
		cell = nextRow.getCell(12);
		if(cell != null) {
		valueStr = cell.getStringCellValue();
		hcr.setOthers(valueStr);
		}
		
		return hcr;
		
	}

}
