package org.mphasis.mfowp.excelprocessor.ms.api;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.mphasis.mfowp.excelprocessor.ms.entity.FileEntity;
import org.mphasis.mfowp.excelprocessor.ms.service.FilePersistanceService;
import org.mphasis.mfowp.excelprocessor.ms.service.FileProcessorService;
import org.mphasis.mfowp.excelprocessor.ms.service.FileValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@EnableMongoRepositories(basePackages = { "org.mphasis.mfowp.excelprocessor.ms.repository" })
@CrossOrigin(origins = "http://localhost:4200") // usage
@RestController
@RequestMapping("/excel")
public class ExcelApi {

   
	
	@Autowired
	FileValidationService fileValidationService;

	@Autowired
	FilePersistanceService filePersistanceService;
	
	@Autowired
	FileProcessorService  fileProcessorService;

// fileType will be either hcr or bbgv

	@PostMapping("/validate")
	public ResponseEntity<Object> validate(@RequestHeader("File-Type") String fileType,
			@RequestParam("file") MultipartFile file) throws IOException, FileNotFoundException {
		return fileValidationService.validate(fileType, file);

	}

	@PostMapping("/upload")
	public ResponseEntity<Object> uploadFile(@RequestHeader("File-Type") String fileType,
			@RequestParam("file") MultipartFile file) throws IOException, FileNotFoundException {
		return  fileProcessorService.uploadFile(fileType, file);

	}

	@DeleteMapping("/deleteFile/{id}")
	public ResponseEntity<Map<String, String>> deleteFile(@PathVariable String id) throws FileNotFoundException {
		return filePersistanceService.deleteFileByID(id);
	}

	@DeleteMapping("/deleteFiles")
	public ResponseEntity<String> deleteFiles(@RequestBody List<String> files) {
		return filePersistanceService.deleteFiles(files);
	}

	@GetMapping("/getAllFiles")
	public ResponseEntity<List<FileEntity>> getAllFiles() {
		return filePersistanceService.getAllFiles();
	}

	@GetMapping("/getFile/{id}")
	public ResponseEntity<FileEntity> getFileById(@PathVariable String id) throws FileNotFoundException {
		return filePersistanceService.getFileById(id);
	}

}