package org.mphasis.mfowp.excelprocessor.ms.repository;

import java.util.Optional;

import org.mphasis.mfowp.excelprocessor.ms.entity.Offboarding;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface OffboardingRepository extends MongoRepository<Offboarding, String>  {

	Optional<Offboarding> findById(String string);
	Optional<Offboarding> findByEmployeeNumber(Integer empNumber);

}
