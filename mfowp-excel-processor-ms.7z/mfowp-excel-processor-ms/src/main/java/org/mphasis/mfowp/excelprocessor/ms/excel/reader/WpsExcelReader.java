package org.mphasis.mfowp.excelprocessor.ms.excel.reader;

import java.io.IOException;
import java.util.List;

import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelHeaderMapper;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelTemplate;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelFileInfo;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelHeader;
import org.mphasis.mfowp.excelprocessor.ms.exception.ExcelConstants;
import org.springframework.web.multipart.MultipartFile;

public class WpsExcelReader<Wps> implements ExcelReader<Wps> {
	private static ExcelFileInfo fileInfo;
	private ExcelTemplate excelTemplate;

	static {
		fileInfo = new ExcelFileInfo(ExcelConstants.Wps);
		fileInfo.addHeader(new ExcelHeader(0, "A", "EMPLOYEE NUMBER", "Integer"));
		fileInfo.addHeader(new ExcelHeader(1, "B", "FedEx  LDAP ID Deactivated (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(2, "C", "FedEx Email ID (OSV) Deactivated (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(3, "D", "Mphasis VPN Deactivated (Y/N)", "String"));
		fileInfo.addHeader(new ExcelHeader(4, "E", "FedEx MVOIP Deactivated (Y/N)", "String"));
		fileInfo.addHeader(new ExcelHeader(5, "F", "FedEx Laptop Handed Over (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(6,"G","Any customer supplied  Devices  Handed Over(Y/ N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(7,"H","Access to  FedEx ODC Deactivated (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(8,"I","Mphasis Email Id Deactivated (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(9,"J","User Id Deactivated (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(10,"K","Mphasis Laptop Handed Over (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(11,"L","Access to Main Gate Deactivated  (Y/N)?", "String"));
		fileInfo.addHeader(new ExcelHeader(12,"M","Others", "String"));


	}

	public WpsExcelReader() {

	}

	@Override
	public void setSourceFile(MultipartFile sourceFile) throws IOException {
		ExcelHeaderMapper<ExcelHeader> excelHeaderMapper = new WpsExcelHeaderMapper();
		excelTemplate = new ExcelTemplate(excelHeaderMapper, sourceFile, fileInfo);
	}

	@Override
	public List<Wps> listRecords() {
		List<Wps> wps = (List<Wps>) excelTemplate.lookup(new WpsExcelRowMapper(), "wps");
		return wps;
	}

	@Override
	public Wps get(Integer rowNumber) {
		Wps wps =(Wps) excelTemplate.lookup(rowNumber,new WpsExcelRowMapper());
		return wps;
	}

}
