package org.mphasis.mfowp.excelprocessor.ms.mapper;

import org.mphasis.mfowp.excelprocessor.ms.entity.EmployeeEntity;
import org.mphasis.mfowp.excelprocessor.ms.entity.Offboarding;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;

public class HcrEmployeeMapperImpl implements HcrEmployeeMapper{

	@Override
	public EmployeeEntity HcrtoEmployee(Hcr hcr) {

		EmployeeEntity employeeEntity = new EmployeeEntity();
		employeeEntity.setEmployeeNumber(hcr.getEmpNumber());
		employeeEntity.setEmployeeName(hcr.getEmpName());
		employeeEntity.setDateOfJoining(hcr.getDateOfJoining());
		employeeEntity.setLocation(hcr.getLocation1());
		employeeEntity.setPosition(hcr.getLocation2());
		employeeEntity.setPosLocName(hcr.getPosLocName());
		employeeEntity.setPosOnsiteOffsure(hcr.getPosOnsiteOffsure());
		employeeEntity.setGradeDescription(hcr.getGradeDesc());
		employeeEntity.setDeliveryManagerName(hcr.getDMEmpName());
		employeeEntity.setProjectManager(hcr.getPM());
		if(hcr.getReleaseDateInPRISM()!=null) {
		employeeEntity.setReleaseDate(hcr.getReleaseDateInPRISM());
		employeeEntity.setOffboardingStatus("Account Offboarding");}
		if(hcr.getSeperationDate()!=null) {
		employeeEntity.setReleaseDate(hcr.getSeperationDate());
		employeeEntity.setOffboardingStatus("Mphasis Offboarding");}
		return employeeEntity;
	}

	@Override
	public Hcr EmployeetoHcr(EmployeeEntity employeeEntity) {

		Hcr hcr = new Hcr();
		hcr.setEmpNumber(employeeEntity.getEmployeeNumber());
		hcr.setEmpName(employeeEntity.getEmployeeName());
		hcr.setDateOfJoining(employeeEntity.getDateOfJoining());
		hcr.setLocation1(employeeEntity.getLocation());
		hcr.setLocation2(employeeEntity.getPosition());
		hcr.setPosLocName(employeeEntity.getPosLocName());
		hcr.setPosOnsiteOffsure(hcr.getPosOnsiteOffsure());
		hcr.setGradeDesc(employeeEntity.getGradeDescription());
		hcr.setDMEmpName(employeeEntity.getDeliveryManagerName());
		hcr.setPM(employeeEntity.getProjectManager());
		return hcr;
	}

	@Override
	public Offboarding HcrtoOffboardingFedEx(Hcr hcr) {
		Offboarding offboardingEntity = new Offboarding();
		offboardingEntity.setOffboardingId(hcr.getEmpNumber() + "FedEx");
		offboardingEntity.setEmployeeNumber(hcr.getEmpNumber());
		offboardingEntity.setDeliveryManagerId(hcr.getDMEmpNumber());
		if(hcr.getPMEmpNumber()!=null) {
		offboardingEntity.setProjectManagerId(hcr.getPMEmpNumber());}
		offboardingEntity.setSeparationReason(hcr.getSeparationReason());
		offboardingEntity.setReleaseDate(hcr.getReleaseDateInPRISM());
		offboardingEntity.setStatus("New");
		return offboardingEntity;
	}

	@Override
	public Offboarding HcrtoOffboardingMphasis(Hcr hcr) {
		Offboarding offboardingEntity = new Offboarding();
		offboardingEntity.setOffboardingId(hcr.getEmpNumber() + "Mphasis");
		offboardingEntity.setEmployeeNumber(hcr.getEmpNumber());
		offboardingEntity.setDeliveryManagerId(hcr.getDMEmpNumber());
		if(hcr.getPMEmpNumber()!=null) {
		offboardingEntity.setProjectManagerId(hcr.getPMEmpNumber());}
		offboardingEntity.setSeparationReason(hcr.getSeparationReason());
		offboardingEntity.setReleaseDate(hcr.getSeperationDate());
		offboardingEntity.setStatus("New");
		return offboardingEntity;
	}

}
