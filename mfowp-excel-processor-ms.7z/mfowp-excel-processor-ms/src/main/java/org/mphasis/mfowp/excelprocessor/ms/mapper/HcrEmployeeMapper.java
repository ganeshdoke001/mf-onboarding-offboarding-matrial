package org.mphasis.mfowp.excelprocessor.ms.mapper;

import org.mphasis.mfowp.excelprocessor.ms.entity.EmployeeEntity;
import org.mphasis.mfowp.excelprocessor.ms.entity.Offboarding;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;

public interface HcrEmployeeMapper {
		
		EmployeeEntity HcrtoEmployee(Hcr hcr);
		Hcr EmployeetoHcr(EmployeeEntity employeeEntity);
		Offboarding HcrtoOffboardingFedEx(Hcr hcr);
		Offboarding HcrtoOffboardingMphasis(Hcr hcr);

}
