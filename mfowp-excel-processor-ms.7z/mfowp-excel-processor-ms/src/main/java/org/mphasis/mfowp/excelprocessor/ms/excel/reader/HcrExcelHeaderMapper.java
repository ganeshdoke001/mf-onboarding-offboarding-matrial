package org.mphasis.mfowp.excelprocessor.ms.excel.reader;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelHeaderMapper;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelFileInfo;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelHeader;

public class HcrExcelHeaderMapper implements ExcelHeaderMapper<ExcelHeader> {

	@Override
	public List<ExcelHeader> mapHeader(Row nextExcelHeaderRow, int rowHeaderNum) throws ExcelDataProcessorException {

		List<ExcelHeader> excelHeaders = new ArrayList<ExcelHeader>();

		ExcelHeader excelHeader;
		String valueStr;

		// Only 8 HeaderRows Implemented for demo //
//		fileInfo = new ExcelFileInfo("hcr");
//		fileInfo.addHeader(new ExcelHeader(1, "B", "EMPLOYEE NUMBER", "Long"));
//		fileInfo.addHeader(new ExcelHeader(2, "C", "EMPLOYEE NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader(3, "D", "DATE OF JOINING", "Date"));
//		fileInfo.addHeader(new ExcelHeader(4, "E", "LOCATION", "String"));
//		fileInfo.addHeader(new ExcelHeader(5, "F", "LOCATION", "String"));
//		fileInfo.addHeader(new ExcelHeader(6, "G", "POS ONSITE OFFSHORE", "String"));
//		fileInfo.addHeader(new ExcelHeader(7, "H", "POS LOC NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader(13, "N", "GRADE DESC", "String"));
//		fileInfo.addHeader(new ExcelHeader(33, "AH", "DM EMP NO", "Long"));//MJ
//		fileInfo.addHeader(new ExcelHeader(34, "AI", "DM EMP NAME", "String"));
//		fileInfo.addHeader(new ExcelHeader(78, "BY", "PM", "String"));
//		fileInfo.addHeader(new ExcelHeader(81, "CB", "Release date in Prism", "Date"));//MJ
//		fileInfo.addHeader(new ExcelHeader(85, "CF", "SEPARATION DATE", "Date"));//MJ
//		fileInfo.addHeader(new ExcelHeader(92, "CM", "Employee Separated/Out-Transfer", "String"));//MJ
//		fileInfo.addHeader(new ExcelHeader(93, "CN", "PM EMP NO", "Long"));//MJ



		Cell cell = nextExcelHeaderRow.getCell(1);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("B");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}

		cell = nextExcelHeaderRow.getCell(2);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("C");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(3);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("D");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(4);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("E");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}

		cell = nextExcelHeaderRow.getCell(5);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("F");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}

		cell = nextExcelHeaderRow.getCell(6);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("G");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(7);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("H");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(13);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("N");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		cell = nextExcelHeaderRow.getCell(33);//MJ
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("AH");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);//MJ
		}

		cell = nextExcelHeaderRow.getCell(34);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("AI");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}

		cell = nextExcelHeaderRow.getCell(76);
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("BY");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);
		}
		
		cell = nextExcelHeaderRow.getCell(79);//MJ
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("CB");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);//MJ
		}
		cell = nextExcelHeaderRow.getCell(83);//MJ
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("CF");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);//MJ
		}
		cell = nextExcelHeaderRow.getCell(90);//MJ
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("CM");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);//MJ
		}
		cell = nextExcelHeaderRow.getCell(91);//MJ
		if (cell != null) {
			valueStr = cell.getStringCellValue();
			excelHeader = new ExcelHeader();
			excelHeader.setColumnName("CN");
			excelHeader.setHeaderName(valueStr);
			excelHeaders.add(excelHeader);//MJ
		}
		return excelHeaders;
	}

}