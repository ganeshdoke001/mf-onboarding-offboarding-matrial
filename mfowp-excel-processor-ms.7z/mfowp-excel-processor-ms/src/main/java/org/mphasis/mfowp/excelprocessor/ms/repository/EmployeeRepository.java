package org.mphasis.mfowp.excelprocessor.ms.repository;

import java.util.List;

import org.mphasis.mfowp.excelprocessor.ms.entity.EmployeeEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

public interface EmployeeRepository extends MongoRepository<EmployeeEntity, Integer> {
	
//    List<EmployeeEntity> findByAccountName(String accountName);
//	
//	List<EmployeeEntity> findByLocation(String location);

}
