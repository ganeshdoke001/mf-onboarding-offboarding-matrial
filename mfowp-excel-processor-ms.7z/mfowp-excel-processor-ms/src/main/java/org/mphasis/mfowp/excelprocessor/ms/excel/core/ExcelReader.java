package org.mphasis.mfowp.excelprocessor.ms.excel.core;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public interface ExcelReader<T> {
	public void setSourceFile(MultipartFile dataFile)throws IOException;
	public List<T> listRecords();
	public T get(Integer rowNumber);
}
