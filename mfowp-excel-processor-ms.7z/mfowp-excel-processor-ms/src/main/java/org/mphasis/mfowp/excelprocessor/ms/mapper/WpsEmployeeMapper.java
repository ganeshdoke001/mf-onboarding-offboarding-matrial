package org.mphasis.mfowp.excelprocessor.ms.mapper;

import java.util.Optional;

import org.mphasis.mfowp.excelprocessor.ms.entity.Offboarding;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Wps;

public interface WpsEmployeeMapper {
		
		Wps EmployeetoWps(Offboarding offboarding);
		Offboarding WpstoEmployeeFedEx(Wps wps,Optional<Offboarding> accountEmployee);
		Offboarding WpstoEmployeeMphasis(Wps wps, Optional<Offboarding> mphasisEmployee);
}

