package org.mphasis.mfowp.excelprocessor.ms.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.excelprocessor.ms.entity.EmployeeEntity;
import org.mphasis.mfowp.excelprocessor.ms.entity.Offboarding;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelException;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Wps;
import org.mphasis.mfowp.excelprocessor.ms.excel.reader.HcrExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.excel.reader.WpsExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.exception.ExcelConstants;
import org.mphasis.mfowp.excelprocessor.ms.mapper.HcrEmployeeMapperImpl;
import org.mphasis.mfowp.excelprocessor.ms.mapper.WpsEmployeeMapperImpl;
import org.mphasis.mfowp.excelprocessor.ms.repository.EmployeeRepository;
import org.mphasis.mfowp.excelprocessor.ms.repository.OffboardingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class FileProcessorServiceImpl implements FileProcessorService {

	private ExcelReader<Hcr> hcrReader = new HcrExcelReader<Hcr>();
	private ExcelReader<Wps> wpsReader = new WpsExcelReader<Wps>();

	
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	private FilePersistanceService filePersistanceService;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private OffboardingRepository offboardingRepository;

	@Autowired
	private HcrEmployeeMapperImpl hcrEmployeeMapperImpl;

	@Autowired
	private WpsEmployeeMapperImpl wpsEmployeeMapperImpl;

	@Autowired
	private FileValidationService fileValidationService;

	public List<?> process(String fileType, MultipartFile sourceFile) throws IOException {

		fileValidationService.validateFile(sourceFile);

		List<Hcr> hcrs = null;
//		 List<Bvg> bvgs = null;
		List<Wps> wpss = null;
//		try {
		if (fileType.equalsIgnoreCase(ExcelConstants.Hcr)) {
			hcrReader.setSourceFile(sourceFile);
			hcrs = hcrReader.listRecords();

//		Save your file
			filePersistanceService.persistFile(fileType, sourceFile);

//		persist the records
//		by Ashish start
			for (int i = 0; i < hcrs.size(); i++) {

				Hcr hcrCheck = (Hcr) hcrs.get(i);
				EmployeeEntity employeeEntity = new EmployeeEntity();
				Optional<EmployeeEntity> employeeEntityOptional = employeeRepository.findById(hcrCheck.getEmpNumber());
				if (employeeEntityOptional.isPresent()) {
					employeeEntity = employeeEntityOptional.get();
			    	employeeEntity.setStatus("Update");
					hcrCheck.setStatus("Update");
					employeeRepository.save(hcrEmployeeMapperImpl.HcrtoEmployee(hcrCheck));
					if (hcrCheck.getReleaseDateInPRISM() != null) {// MJ
						Offboarding offboarding = new Offboarding();
						Optional<Offboarding>offboardingOptional=offboardingRepository.findById(hcrCheck.getEmpNumber()+ "FedEx");
						if(offboardingOptional.isPresent()) {
						offboarding = offboardingOptional.get();
						offboarding.setOffboardingId(hcrCheck.getEmpNumber() + "FedEx");
						offboarding.setEmployeeNumber(hcrCheck.getEmpNumber());
						offboarding.setDeliveryManagerId(hcrCheck.getDMEmpNumber());
						offboarding.setProjectManagerId(hcrCheck.getPMEmpNumber());
						offboarding.setSeparationReason(hcrCheck.getSeparationReason());
						offboarding.setReleaseDate(hcrCheck.getReleaseDateInPRISM());
						offboarding.setStatus("Update");
						offboardingRepository.save(offboarding);}
					}
					if (hcrCheck.getSeperationDate() != null) {// MJ
						Offboarding offboarding = new Offboarding();
						Optional<Offboarding>offboardingOptional=offboardingRepository.findById(hcrCheck.getEmpNumber()+ "Mphasis");
						if(offboardingOptional.isPresent()) {
						offboarding = offboardingOptional.get();
						offboarding.setOffboardingId(hcrCheck.getEmpNumber() + "Mphasis");
						offboarding.setEmployeeNumber(hcrCheck.getEmpNumber());
						offboarding.setDeliveryManagerId(hcrCheck.getDMEmpNumber());
						offboarding.setProjectManagerId(hcrCheck.getPMEmpNumber());
						offboarding.setSeparationReason(hcrCheck.getSeparationReason());
						offboarding.setReleaseDate(hcrCheck.getSeperationDate());
						offboarding.setStatus("Update");
						offboardingRepository.save(offboarding);}
					}
				} else {
					employeeEntity.setStatus("New");
					hcrCheck.setStatus("New");
					employeeRepository.save(hcrEmployeeMapperImpl.HcrtoEmployee(hcrCheck));
					if (hcrCheck.getReleaseDateInPRISM() != null) {// MJ
						offboardingRepository.save(hcrEmployeeMapperImpl.HcrtoOffboardingFedEx(hcrCheck));
					}
					if (hcrCheck.getSeperationDate() != null) {// MJ
						offboardingRepository.save(hcrEmployeeMapperImpl.HcrtoOffboardingMphasis(hcrCheck));
					}
				}
			}
			// by Ashish end
			return hcrs;
		} else if (fileType.equalsIgnoreCase("wps")) {

			wpsReader.setSourceFile(sourceFile);
			wpss = wpsReader.listRecords();
			
			filePersistanceService.persistFile(fileType, sourceFile);

			for (int i = 0; i < wpss.size(); i++) {
				System.out.println("wpss.size()" + wpss.size());
				Wps wpsCheck = (Wps) wpss.get(i);
				Offboarding offboardingEntity = new Offboarding();
				Optional<Offboarding> mphasisEmployee = offboardingRepository
						.findById(wpsCheck.getEmpNumber() + "Mphasis");
				Optional<Offboarding> accountEmployee = offboardingRepository
						.findById(wpsCheck.getEmpNumber() + "FedEx");

				System.out.println("mphasisEmployee::" + mphasisEmployee);
				System.out.println("accountEmployee::" + accountEmployee);
				
				if (mphasisEmployee.isPresent() || accountEmployee.isPresent()) {
					if ((!accountEmployee.isEmpty())&&(accountEmployee!=null)) {
						
						offboardingEntity.setStatus("Update");
						wpsCheck.setStatus("Update");
						offboardingRepository.save(wpsEmployeeMapperImpl.WpstoEmployeeFedEx(wpsCheck,accountEmployee));// TODO verify the logic for setting DmId from DK
					}
					if ((!mphasisEmployee.isEmpty())&&(mphasisEmployee!=null)) {
						offboardingEntity.setStatus("Update");
						wpsCheck.setStatus("Update");
						offboardingRepository.save(wpsEmployeeMapperImpl.WpstoEmployeeMphasis(wpsCheck,mphasisEmployee ));
					}
				}
			}
			return wpss;
		}
		return wpss;
	}

	// by manoj start
	@Override
	public ResponseEntity<Object> uploadFile(String fileType, MultipartFile file)
			throws IOException, FileNotFoundException {
		List<?> data = null;
		System.out.println("fileType" + fileType);

		try {
			data = process(fileType, file);
		} catch (ExcelException e) {
			e.getErrors();
			return new ResponseEntity<Object>(e.getErrors(), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return new ResponseEntity<Object>(data, new HttpHeaders(), HttpStatus.OK);
	}
	// by manoj end

}
