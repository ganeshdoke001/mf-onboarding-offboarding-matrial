package org.mphasis.mfowp.excelprocessor.ms.excel.model;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Hcr {

	@NotNull(message = "EMPLOYE NUMBER::should not be empty")
	private Integer empNumber;

	@NotNull
	@NotEmpty(message = "EMPLOYEE NAME::should not be empty")
	private String empName;

	@NotNull(message = "DATE OF JOINING::should not be empty")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateOfJoining;

	// offshore ie. chennai
	@NotNull
	@NotEmpty(message = "LOCATION1::should not be empty")
	private String location1;

	// position ie OFFSHORE or ONSHORE
	@NotNull
	@NotEmpty(message = "LOCATION2::should not be empty")
	private String location2;

	// excel POS LOC NAME ie Chennai (IN-CHE08)
	@NotNull
	@NotEmpty(message = "POSITION::should not be empty")
	private String posLocName;

	@NotNull(message = "POSONSITEOFFSHORE::should not be empty")
	private String posOnsiteOffsure;

	@NotNull
	@NotEmpty(message = "GRADEDESC::should not be empty")
	private String gradeDesc;

	@NotNull(message = "DM EMPLOYEE NUMBER::should not be empty")
	private Integer DMEmpNumber;// MJ

	@NotNull
	@NotEmpty(message = "DM EMPLOYEE NAME::should not be empty")
	private String DMEmpName;

	@NotNull
	@NotEmpty(message = "PM::should not be empty")
	private String PM;

	private Integer PMEmpNumber;

	private String separationReason;

	private Date releaseDateInPRISM;// MJ

	private Date seperationDate;// MJ

	private String status;

	public Integer getEmpNumber() {
		return empNumber;
	}

	public void setEmpNumber(Integer empNumber) {
		this.empNumber = empNumber;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getLocation1() {
		return location1;
	}

	public void setLocation1(String location1) {
		this.location1 = location1;
	}

	public String getLocation2() {
		return location2;
	}

	public void setLocation2(String location2) {
		this.location2 = location2;
	}

	public String getPosLocName() {
		return posLocName;
	}

	public void setPosLocName(String posLocName) {
		this.posLocName = posLocName;
	}

	public String getPosOnsiteOffsure() {
		return posOnsiteOffsure;
	}

	public void setPosOnsiteOffsure(String posOnsiteOffsure) {
		this.posOnsiteOffsure = posOnsiteOffsure;
	}

	public String getGradeDesc() {
		return gradeDesc;
	}

	public void setGradeDesc(String gradeDesc) {
		this.gradeDesc = gradeDesc;
	}

	public Integer getDMEmpNumber() {
		return DMEmpNumber;
	}

	public void setDMEmpNumber(Integer dMEmpNumber) {
		DMEmpNumber = dMEmpNumber;
	}

	public String getDMEmpName() {
		return DMEmpName;
	}

	public void setDMEmpName(String dMEmpName) {
		DMEmpName = dMEmpName;
	}

	public String getPM() {
		return PM;
	}

	public void setPM(String pM) {
		PM = pM;
	}

	public Integer getPMEmpNumber() {
		return PMEmpNumber;
	}

	public void setPMEmpNumber(Integer pMEmpNumber) {
		PMEmpNumber = pMEmpNumber;
	}

	public String getSeparationReason() {
		return separationReason;
	}

	public void setSeparationReason(String separationReason) {
		this.separationReason = separationReason;
	}

	public Date getReleaseDateInPRISM() {
		return releaseDateInPRISM;
	}

	public void setReleaseDateInPRISM(Date releaseDateInPRISM) {
		this.releaseDateInPRISM = releaseDateInPRISM;
	}

	public Date getSeperationDate() {
		return seperationDate;
	}

	public void setSeperationDate(Date seperationDate) {
		this.seperationDate = seperationDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Hcr(@NotNull(message = "EMPLOYE NUMBER::should not be empty") Integer empNumber,
			@NotNull @NotEmpty(message = "EMPLOYEE NAME::should not be empty") String empName,
			@NotNull(message = "DATE OF JOINING::should not be empty") Date dateOfJoining,
			@NotNull @NotEmpty(message = "LOCATION1::should not be empty") String location1,
			@NotNull @NotEmpty(message = "LOCATION2::should not be empty") String location2,
			@NotNull @NotEmpty(message = "POSITION::should not be empty") String posLocName,
			@NotNull(message = "POSONSITEOFFSHORE::should not be empty") String posOnsiteOffsure,
			@NotNull @NotEmpty(message = "GRADEDESC::should not be empty") String gradeDesc,
			@NotNull(message = "DM EMPLOYEE NUMBER::should not be empty") Integer dMEmpNumber,
			@NotNull @NotEmpty(message = "DM EMPLOYEE NAME::should not be empty") String dMEmpName,
			@NotNull @NotEmpty(message = "PM::should not be empty") String pM, Integer pMEmpNumber,
			String separationReason, Date releaseDateInPRISM, Date seperationDate, String status) {
		super();
		this.empNumber = empNumber;
		this.empName = empName;
		this.dateOfJoining = dateOfJoining;
		this.location1 = location1;
		this.location2 = location2;
		this.posLocName = posLocName;
		this.posOnsiteOffsure = posOnsiteOffsure;
		this.gradeDesc = gradeDesc;
		DMEmpNumber = dMEmpNumber;
		DMEmpName = dMEmpName;
		PM = pM;
		PMEmpNumber = pMEmpNumber;
		this.separationReason = separationReason;
		this.releaseDateInPRISM = releaseDateInPRISM;
		this.seperationDate = seperationDate;
		this.status = status;
	}

	public Hcr() {
		super();
	}

	

}