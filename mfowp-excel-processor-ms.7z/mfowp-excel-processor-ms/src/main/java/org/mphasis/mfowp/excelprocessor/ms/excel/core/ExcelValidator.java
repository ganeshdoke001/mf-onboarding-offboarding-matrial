package org.mphasis.mfowp.excelprocessor.ms.excel.core;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.mphasis.mfowp.excelprocessor.ms.excel.model.ExcelHeader;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Wps;
import org.mphasis.mfowp.excelprocessor.ms.exception.ExcelConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;


public class ExcelValidator {

	@Autowired
	private Validator validator;

	public ValidationResult validateExcelFile(MultipartFile excelFile) {

		String contentType = excelFile.getContentType();
		System.out.println("contentType: " + contentType);
		Violation violation = new Violation();
		ValidationResult validationResult = new ValidationResult();
		if (!contentType.equalsIgnoreCase("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
			violation.setCode("Excel File Error");
			violation.setMessage("Invalid file, Unsupported Media Type");
			violation.setTimestamp(new Date());
			validationResult.add(violation);
		}
		return validationResult;
	}

	public ValidationResult validateExcelHeaders(List<ExcelHeader> fileHeader, List<ExcelHeader> excelRuntimeHeader) {
		System.out.println("Headers count: " + fileHeader.size());
		System.out.println("excelRuntimeHeaders count: " + excelRuntimeHeader.size());
		int fileHeaderSize = fileHeader.size();
		fileHeaderSize = (excelRuntimeHeader.size() < fileHeader.size()) ? excelRuntimeHeader.size() : fileHeaderSize;
		// TODO Handle NLP excepted less than header counts tukaram
		ValidationResult validationResult = new ValidationResult();

		for (int headerIndex = 0; headerIndex < fileHeaderSize; headerIndex++) {
			System.out.println("+headerIndexheaderIndex" + headerIndex);
			System.out.println("fileHeader " + (headerIndex + 1) + " : " + fileHeader.get(headerIndex));
			System.out.println("headers    " + (headerIndex + 1) + " : " + excelRuntimeHeader.get(headerIndex));
			if (!fileHeader.get(headerIndex).getHeaderName()
					.equals(excelRuntimeHeader.get(headerIndex).getHeaderName())) {
				System.out.println("Not EQ");
				Violation violation = new Violation();
				violation.setCode("Excel Header Error");
				violation.setColumn(fileHeader.get(headerIndex).getHeaderName());
				violation.setMessage(fileHeader.get(headerIndex).getHeaderName() + " : "
						+ " excel mandatory column/ header is missing");
				violation.setTimestamp(new Date());
				validationResult.add(violation);
			}
		}

		return validationResult;
	}

	public ValidationResult validateExcelData(List<ExcelHeader> fileHeader, List<?> hcrs, String fileType) {
		ValidationResult validationResult = new ValidationResult();
		System.out.println("Hcr count: " + hcrs.size());
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		int fileHeaderSize = fileHeader.size();
		Hcr hcr = new Hcr();
		Wps wps = new Wps();
		if (fileType.equalsIgnoreCase(ExcelConstants.Hcr)) {
//			for (int headerIndex = 0; headerIndex < fileHeaderSize; headerIndex++) {
				for (int recordNumber = 0; recordNumber < hcrs.size(); recordNumber++) {
					hcr = (Hcr) hcrs.get(recordNumber);
					Set<ConstraintViolation<Hcr>> violations = validator.validate(hcr);
					System.out.println("Violations " + violations);
					for (ConstraintViolation<Hcr> violation : violations) {
						String message = violation.getMessage();
						System.out.println("Message : " + message);
						violation.getInvalidValue();
						if (!(message.equalsIgnoreCase(ExcelConstants.INVALID_MSG))) { // dkodagi to be verified
							String[] messages = message.split(" :: ");
							Violation violation2 = new Violation();
							violation2.setCode("Excel Data Error");
							violation2.setRow(Integer.toString(recordNumber + 2));
							violation2.setColumn(messages[0]);
							violation2.setMessage(message);
							violation2.setTimestamp(new Date());
							validationResult.add(violation2);
						}
					}
				}
			}
//		}
		// wps
		else if (fileType.equalsIgnoreCase(ExcelConstants.Wps)) {
//			for (int headerIndex = 0; headerIndex < fileHeaderSize; headerIndex++) {
				for (int recordNumber = 0; recordNumber < hcrs.size(); recordNumber++) {
					wps = (Wps) hcrs.get(recordNumber);
					Set<ConstraintViolation<Wps>> violations = validator.validate(wps);
					System.out.println("Violations " + violations);
					for (ConstraintViolation<Wps> violation : violations) {
						String message = violation.getMessage();
						System.out.println("Message : " + message);
						String[] messages = message.split(" :: ");
						violation.getInvalidValue();
						if (!(message.equalsIgnoreCase(ExcelConstants.INVALID_MSG))) {
							violation.getInvalidValue();
							Violation violation2 = new Violation();
							violation2.setCode("Excel Data Error");
							violation2.setRow(Integer.toString(recordNumber + 2));
							violation2.setColumn(messages[0]);
							violation2.setMessage(message);
							violation2.setTimestamp(new Date());
							validationResult.add(violation2);
						}
					}
				}
			}
//		}

//		System.out.println("Bgv count: " + hcrs.size());
//		validator = Validation.buildDefaultValidatorFactory().getValidator();
//		Bgv bgv = new Bgv();
//		for (int recordNumber = 0; recordNumber < hcrs.size(); recordNumber++) {
//			bgv = (Bgv) hcrs.get(recordNumber);
//			Set<ConstraintViolation<Bgv>> violations = validator.validate(bgv);
//			System.out.println("Violations " + violations);
//			for (ConstraintViolation<Bgv> violation : violations) {
//				String message = violation.getMessage();
//				System.out.println("Message : " + message);
//				violation.getInvalidValue();
//				String[] messages = message.split(" :: ");
//				Violation violation2 = new Violation();
//				violation2.setCode("Excel Data Error");
//				violation2.setRow(Integer.toString(recordNumber));
//				violation2.setColumn(fileHeader.get(recordNumber+2).getHeaderName());
//				violation2.setMessage(message);
//				violation2.setTimestamp(new Date());
//				validationResult.add(violation2);
//			}
//		}

		return validationResult;
	}

}
