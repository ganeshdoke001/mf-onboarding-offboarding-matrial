package org.mphasis.mfowp.excelprocessor.ms.mapper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.excelprocessor.ms.entity.Access;
import org.mphasis.mfowp.excelprocessor.ms.entity.Asset;
import org.mphasis.mfowp.excelprocessor.ms.entity.Offboarding;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Wps;
import org.mphasis.mfowp.excelprocessor.ms.exception.ExcelConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author ${Ashish Kumar}
 *
 * 
 */
@Service
public class WpsEmployeeMapperImpl implements WpsEmployeeMapper {

	
	@Override
	public Offboarding WpstoEmployeeFedEx(Wps wps,Optional<Offboarding> accountEmployee) {

		Offboarding offboarding = new Offboarding();
		offboarding = accountEmployee.get();
		offboarding.setOffboardingId(wps.getEmpNumber() + "FedEx");
		offboarding.setEmployeeNumber(wps.getEmpNumber());
		offboarding.setOrganisation("FedEx");
		if (wps.getFedExEmailIdDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			offboarding.setEmail(ExcelConstants.Deactive);
		} else {
			offboarding.setEmail(ExcelConstants.Active);
		}
		if (wps.getFedExLDAPIdDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			offboarding.setUserId(ExcelConstants.Deactive);
		} else {
			offboarding.setUserId(ExcelConstants.Active);
		}
		Access access = new Access();
		access.setAccessName("FedEx_ODC");
		if (wps.getAccessToFedExODCDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			access.setAccessStatus(ExcelConstants.Deactive);
		} else {
			access.setAccessStatus(ExcelConstants.Active);
		}
		offboarding.setAccess(access);
		if (wps.getFedExMVOIPDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			offboarding.setVpn(ExcelConstants.Deactive);
		} else {
			offboarding.setVpn(ExcelConstants.Active);
		}
		List<Asset> assetList = new ArrayList<>();
		Asset assetLaptop = new Asset();
		assetLaptop.setAssetName("FedEx Laptop");
		if (wps.getFedExLaptopHandedOver().equalsIgnoreCase(ExcelConstants.Yes)) {
			assetLaptop.setAssetStatus(ExcelConstants.Submitted);
		} else {
			assetLaptop.setAssetStatus(ExcelConstants.Not_Submitted);
		}
		assetLaptop.setAssetCategory(ExcelConstants.Primary);
		assetList.add(assetLaptop);
		Asset assetCustomerDevices = new Asset();
		assetCustomerDevices.setAssetName("CustomerSuppliedDevice");
		if (wps.getAnyCustomerSuppliedDevicesHandedOver().equalsIgnoreCase(ExcelConstants.Yes)) {
			assetCustomerDevices.setAssetStatus(ExcelConstants.Submitted);
		} else {
			assetCustomerDevices.setAssetStatus(ExcelConstants.Not_Submitted);
		}
		assetCustomerDevices.setAssetCategory(ExcelConstants.Primary);
		assetList.add(assetCustomerDevices);
		offboarding.setAssets(assetList);
		offboarding.setStatus(wps.getStatus());
//		}
		return offboarding;
	}

	@Override
	public Wps EmployeetoWps(Offboarding offboarding) {

		Wps wps = new Wps();
		wps.setEmpNumber(offboarding.getEmployeeNumber());
//		wps.setEmpName(offboarding.getEmpName());
//		wps.setReleaseDateInPRISM(offboarding.getReleaseDateInPRISM());
//		wps.setSeperationDate(offboarding.getSeperationDate());
//		wps.setFedExLDAPIdDeactivated(offboarding.getFedExLDAPIdDeactivated());
//		wps.setFedExEmailIdDeactivated(offboarding.getFedExEmailIdDeactivated());
//		wps.setMphasisVPNDeactivated(offboarding.getMphasisVPNDeactivated());
//		wps.setFedExMVOIPDeactivated(offboarding.getFedExMVOIPDeactivated());
//		wps.setFedExLaptopHandedOver(offboarding.getFedExLaptopHandedOver());
//		wps.setAnyCustomerSuppliedDevicesHandedOver(offboarding.getAnyCustomerSuppliedDevicesHandedOver());
//		wps.setAccessToFedExODCDeactivated(offboarding.getAccessToFedExODCDeactivated());
//		wps.setMphasisEmailIdDeactivated(offboarding.getMphasisEmailIdDeactivated());
//		wps.setUserIdDeactivated(offboarding.getUserIdDeactivated());
//		wps.setMphasisLaptopHandedOver(offboarding.getMphasisLaptopHandedOver());
//		wps.setAccesstoMainGateDeactivated(offboarding.getAccesstoMainGateDeactivated());
//		wps.setEmployeeSeparatedOutTransfer(offboarding.getEmployeeSeparatedOutTransfer());
		return wps;
	}

	public Offboarding WpstoEmployeeMphasis(Wps wps,Optional<Offboarding> mphasisEmployee) {
		Offboarding offboarding = new Offboarding();
		offboarding = mphasisEmployee.get();
		offboarding.setOffboardingId(wps.getEmpNumber() + "Mphasis");
		offboarding.setEmployeeNumber(wps.getEmpNumber());
		offboarding.setOrganisation("Mphasis");
		if (wps.getMphasisEmailIdDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			offboarding.setEmail(ExcelConstants.Deactive);
		} else {
			offboarding.setEmail(ExcelConstants.Active);
		}
		if (wps.getUserIdDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			offboarding.setUserId(ExcelConstants.Deactive);
		} else {
			offboarding.setUserId(ExcelConstants.Active);
		}
		Access access = new Access();
		access.setAccessName("MainGate");
		if (wps.getAccesstoMainGateDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			access.setAccessStatus(ExcelConstants.Deactive);
		} else {
			access.setAccessStatus(ExcelConstants.Active);
		}
		offboarding.setAccess(access);
		if (wps.getMphasisVPNDeactivated().equalsIgnoreCase(ExcelConstants.Yes)) {
			offboarding.setVpn(ExcelConstants.Deactive);
		} else {
			offboarding.setVpn(ExcelConstants.Active);
		}
		List<Asset> assetList = new ArrayList<>();
		Asset assetLaptop = new Asset();
		assetLaptop.setAssetName("Mphasis Laptop");
		if (wps.getMphasisLaptopHandedOver().equalsIgnoreCase(ExcelConstants.Yes)) {
			assetLaptop.setAssetStatus(ExcelConstants.Submitted);
		} else {
			assetLaptop.setAssetStatus(ExcelConstants.Not_Submitted);
		}
		assetLaptop.setAssetCategory(ExcelConstants.Primary);
		assetList.add(assetLaptop);
		Asset otherAsset = new Asset();
		otherAsset.setAssetName("OtherAssets");
		if (wps.getOthers().equalsIgnoreCase(ExcelConstants.Yes)) {
			otherAsset.setAssetStatus(ExcelConstants.Submitted);
		} else {
			otherAsset.setAssetStatus(ExcelConstants.Not_Submitted);
		}
		otherAsset.setAssetCategory(ExcelConstants.Optional);
		assetList.add(otherAsset);
		offboarding.setAssets(assetList);
		offboarding.setStatus(wps.getStatus());
		return offboarding;
	}


}
