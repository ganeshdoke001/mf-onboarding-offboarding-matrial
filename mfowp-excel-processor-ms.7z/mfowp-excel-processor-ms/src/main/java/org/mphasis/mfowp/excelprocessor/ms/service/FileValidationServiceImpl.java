package org.mphasis.mfowp.excelprocessor.ms.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.excelprocessor.ms.entity.EmployeeEntity;
import org.mphasis.mfowp.excelprocessor.ms.entity.FileEntity;
import org.mphasis.mfowp.excelprocessor.ms.entity.Offboarding;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelException;
import org.mphasis.mfowp.excelprocessor.ms.excel.core.ExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Hcr;
import org.mphasis.mfowp.excelprocessor.ms.excel.model.Wps;
import org.mphasis.mfowp.excelprocessor.ms.excel.reader.HcrExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.excel.reader.WpsExcelReader;
import org.mphasis.mfowp.excelprocessor.ms.exception.ExcelConstants;
import org.mphasis.mfowp.excelprocessor.ms.exception.FileNotAvailableException;
import org.mphasis.mfowp.excelprocessor.ms.exception.InvalidFileException;
import org.mphasis.mfowp.excelprocessor.ms.mapper.HcrEmployeeMapperImpl;
import org.mphasis.mfowp.excelprocessor.ms.mapper.WpsEmployeeMapperImpl;
import org.mphasis.mfowp.excelprocessor.ms.repository.EmployeeRepository;
import org.mphasis.mfowp.excelprocessor.ms.repository.FileRepository;
import org.mphasis.mfowp.excelprocessor.ms.repository.OffboardingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileValidationServiceImpl implements FileValidationService {

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	private FileRepository FileRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private OffboardingRepository offboardingRepository;

	@Autowired
	private HcrEmployeeMapperImpl hcrEmployeeMapperImpl;

	@Autowired
	private WpsEmployeeMapperImpl wpsEmployeeMapperImpl;

	private ExcelReader<Hcr> hcrReader = new HcrExcelReader<Hcr>();
	private ExcelReader<Wps> wpsReader = new WpsExcelReader<Wps>();

	ArrayList<Wps> wpsSave = new ArrayList<>();
	ArrayList<Hcr> hcrSave = new ArrayList<>();

	// by manoj changed to ValidateExcel
	/**
	 *
	 */
	public List<?> validateExcel(String fileType, MultipartFile sourceFile) throws IOException {
		List<Hcr> hcrs = null;
		List<Wps> wpss = null;

		if (fileType.equalsIgnoreCase("hcr")) {
			hcrReader.setSourceFile(sourceFile);
			hcrs = hcrReader.listRecords();

			System.out.println("Hcr Record" + hcrs);
			for (int i = 0; i < hcrs.size(); i++) {
				Hcr hcrCheck = (Hcr) hcrs.get(i);
				System.out.println("Hcr: " + hcrs.get(i));
				Optional<EmployeeEntity> employeeEntityOptional = employeeRepository.findById(hcrCheck.getEmpNumber());
				employeeRepository.equals(hcrEmployeeMapperImpl.HcrtoEmployee(hcrCheck));
				if (employeeEntityOptional.isPresent()) {
					System.out.println("Record already exists");
					EmployeeEntity employeeEntity = employeeEntityOptional.get();
					Hcr hcrNew = new Hcr();

					hcrNew.setEmpNumber(employeeEntity.getEmployeeNumber());
					hcrNew.setEmpName(employeeEntity.getEmployeeName());
					hcrNew.setLocation1(employeeEntity.getLocation());
					hcrNew.setLocation2(employeeEntity.getPosition());
					hcrNew.setDateOfJoining(employeeEntity.getDateOfJoining());
					hcrNew.setPosLocName(employeeEntity.getPosLocName());
					hcrNew.setGradeDesc(employeeEntity.getGradeDescription());
					hcrNew.setDMEmpName(employeeEntity.getDeliveryManagerName());
					hcrNew.setPM(employeeEntity.getProjectManager());
					hcrNew.setPosOnsiteOffsure(employeeEntity.getPosOnsiteOffsure());
					hcrNew.setStatus("DB");
					hcrSave.add(hcrNew);

					employeeEntity.setEmployeeName(hcrCheck.getEmpName());
					employeeEntity.setLocation(hcrCheck.getLocation1());
					employeeEntity.setPosition(hcrCheck.getLocation2());
					employeeEntity.setDateOfJoining(hcrCheck.getDateOfJoining());
					employeeEntity.setPosLocName(hcrCheck.getPosLocName());
					employeeEntity.setGradeDescription(hcrCheck.getGradeDesc());
					employeeEntity.setDeliveryManagerName(hcrCheck.getDMEmpName());
					employeeEntity.setProjectManager(hcrCheck.getPM());
					employeeEntity.setPosOnsiteOffsure(hcrCheck.getPosOnsiteOffsure());
					hcrCheck.setStatus("Excel");
					employeeEntity.setStatus("Excel");

				} else {
					EmployeeEntity employeeEntity = new EmployeeEntity();
					employeeEntity.setStatus("New");
					hcrCheck.setStatus("New");
				}
			}
			if (hcrSave.size() != 0) {
				hcrs.addAll(hcrSave);
			}
			hcrSave.clear();
			// by Ashish end
			return hcrs;

		} else if (fileType.equalsIgnoreCase("wps")) {
			wpsReader.setSourceFile(sourceFile);
			wpss = wpsReader.listRecords();
			
			for (int i = 0; i < wpss.size(); i++) {
				System.out.println("wpss.size()" + wpss.size());
				Wps wpsCheck = (Wps) wpss.get(i);
				Offboarding offboardingEntity = new Offboarding();
				Optional<Offboarding> mphasisEmployee = offboardingRepository
						.findById(wpsCheck.getEmpNumber() + "Mphasis");
				Optional<Offboarding> accountEmployee = offboardingRepository
						.findById(wpsCheck.getEmpNumber() + "FedEx");
				Query queryObj = new Query(Criteria.where("employeeNumber").is(wpsCheck.getEmpNumber()));
				List<Offboarding> Employee = mongoTemplate.find(queryObj, Offboarding.class);
				System.out.println("mphasisEmployee::" + mphasisEmployee);
				System.out.println("accountEmployee::" + accountEmployee);
                if(Employee.isEmpty()) {
                	wpsCheck.setStatus("No offboarding data");
                }
				if(!Employee.isEmpty()) {
					if (Employee.get(0).getStatus().equalsIgnoreCase("New")
//							||(Employee.get(0).getStatus().equalsIgnoreCase("Update")&&(Employee.get(0).getEmail()==null))){
						||(Employee.get(0).getStatus().equalsIgnoreCase("Update")&&(wpsFieldsIsPresent(Employee)==false))){

						offboardingEntity.setStatus("New");
						wpsCheck.setStatus("New");
					}
					else {
						offboardingEntity.setStatus("DB");
						wpsCheck.setStatus("Excel");
						
						Offboarding offboarding = Employee.get(0);
						Wps wpsNew = new Wps();
                        if(accountEmployee.isPresent()) {
						wpsNew.setEmpNumber(offboarding.getEmployeeNumber());
						wpsNew.setFedExLDAPIdDeactivated(offboarding.getUserId());
						wpsNew.setFedExEmailIdDeactivated(offboarding.getEmail());
						wpsNew.setFedExMVOIPDeactivated(offboarding.getVpn());
						if(offboarding.getAssets()!=null) {
						wpsNew.setFedExLaptopHandedOver(offboarding.getAssets().get(0).getAssetStatus());}
						if(offboarding.getAssets()!=null) {
						wpsNew.setAnyCustomerSuppliedDevicesHandedOver(offboarding.getAssets().get(1).getAssetStatus());}
						if(offboarding.getAccess()!=null) {
						wpsNew.setAccessToFedExODCDeactivated(offboarding.getAccess().getAccessStatus());}
						wpsNew.setStatus("DB");
                        }
                        if(mphasisEmployee.isPresent()) {
                        	wpsNew.setEmpNumber(offboarding.getEmployeeNumber());
    						wpsNew.setMphasisVPNDeactivated(offboarding.getVpn());
    						wpsNew.setMphasisEmailIdDeactivated(offboarding.getEmail());
    						wpsNew.setUserIdDeactivated(offboarding.getUserId());
    						if(offboarding.getAssets()!=null) {
    						wpsNew.setMphasisLaptopHandedOver(offboarding.getAssets().get(0).getAssetStatus());}
    						if(offboarding.getAssets()!=null) {
    						wpsNew.setOthers(offboarding.getAssets().get(1).getAssetStatus());}
    						if(offboarding.getAccess()!=null) {
    						wpsNew.setAccesstoMainGateDeactivated(offboarding.getAccess().getAccessStatus());}
    						wpsNew.setStatus("DB");
                        	
                        }
						wpsSave.add(wpsNew);
					}
				}
				
			}if (wpsSave.size() != 0) {
				wpss.addAll(wpsSave);
			}
			wpsSave.clear();

			return wpss;

		}
		return wpss;
	}

	public String validateFile(MultipartFile file) throws FileNotFoundException, FileAlreadyExistsException {

		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		String extension = "";
		String ErrorMsg = "";
		if (file.isEmpty()) {
			throw new FileNotAvailableException(ExcelConstants.FILE_NOT_AVBL);
		}
		List<FileEntity> fileGot = FileRepository.findByFileName(fileName);
		int fileSize = fileGot.size();
		if (fileSize > 0) {
			throw new FileAlreadyExistsException(ExcelConstants.FILE_ALREADY_EXISTS);
		} else {
			int i = fileName.lastIndexOf('.');
			if (i >= 0) {
				extension = fileName.substring(i + 1);
				if (!extension.equals("xlsx")) {
					throw new InvalidFileException(ExcelConstants.INVALID_FILE);
				}
			}
		}
		return ErrorMsg;

	}

	public ResponseEntity<Object> validate(String fileType, MultipartFile file)
			throws IOException, FileNotFoundException {
		List<?> data = null;
		validateFile(file);

		try {
			data = validateExcel(fileType, file);// To be verified by tukaram;

		} catch (ExcelException e) {
			return new ResponseEntity<Object>(e.getErrors(), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return new ResponseEntity<Object>(data, new HttpHeaders(), HttpStatus.OK);

	}
	
	public boolean wpsFieldsIsPresent(List<Offboarding> Employee ) {
		if(Employee.get(0).getEmail()!= null
				||Employee.get(0).getUserId()!= null
				||Employee.get(0).getOrganisation()!= null
				||Employee.get(0).getVpn()!= null
				||Employee.get(0).getAccess()!= null
				||Employee.get(0).getAssets()!= null
				||Employee.get(0).getOtherAssets()!= null
				) {
			return true;
		}else {
			return false;
		}
		
		
	}
	

}