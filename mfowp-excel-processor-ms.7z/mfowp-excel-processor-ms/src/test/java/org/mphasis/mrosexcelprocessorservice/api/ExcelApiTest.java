//package org.mphasis.mrosexcelprocessorservice.api;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//
//import java.io.FileNotFoundException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HexFormat;
//import java.util.List;
//import java.util.Map;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//import org.mphasis.mfowp.excelprocessor.ms.api.ExcelApi;
//import org.mphasis.mfowp.excelprocessor.ms.entity.FileEntity;
//import org.mphasis.mfowp.excelprocessor.ms.service.FilePersistanceService;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.mock.web.MockHttpServletResponse;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.MockMvcBuilder;
//import org.springframework.test.web.servlet.MvcResult;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
//import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
//
//public class ExcelApiTest {
//	
//	private MockMvc mvc;
//
//	ExcelApi excelApi;
//
//	FilePersistanceService filePersistanceService;
//
//	byte[] data = HexFormat.of().parseHex("e04fd020ea3a6910a2d808002b30309d");
//
//	@BeforeEach
//	public void setUp() {
//		excelApi = new ExcelApi();
//		filePersistanceService = Mockito.mock(FilePersistanceService.class);
//		excelApi.setFilePersistanceService(filePersistanceService);
//
//	}
//
////	@Test
////	public void testGetFileById_Exception()  {
////		assertThrows(FileNotFoundException.class, () ->{
////			ResponseEntity<FileEntity> fileEntity = null; excelApi.getFileById("6392f3bc8422cb5efd623e0");
////			
////		});
////	}
////	
////	@Test
////	public void testGetAllFiles_Exception() {
////		assertThrows(FileNotFoundException.class, () ->{
////			ResponseEntity<List<FileEntity>> fileEntity = null; excelApi.getAllFiles();
////			
////		});
////		
////	}
//	
////	@Test
////	public void testGetAllFiles_Negative() {
////		ResponseEntity<List<Product>> result = null;
////		List<Product> products = new ArrayList<>();
////		Mockito.when(productRepository.findAll()).thenReturn(products);
////		result = productController.getAllProducts();
////		assertEquals(HttpStatus.NO_CONTENT, result.getStatusCode());
////	}
//	
//	@Test
//	public void testGetFileById() throws FileNotFoundException {
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		ResponseEntity<FileEntity> result = new ResponseEntity<FileEntity>(HttpStatus.OK);
//		Mockito.when(filePersistanceService.getFileById("6392f3bc8422cb5efd623e0a")).thenReturn(result);
//		result = excelApi.getFileById("6392f3bc8422cb5efd623e0a");
//		assertEquals(HttpStatus.OK, result.getStatusCode());
//	}
//
//	@Test
//	public void testGetAllFiles() throws FileNotFoundException {
//		List<FileEntity> fileEntityObj = new ArrayList<>();
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		fileEntityObj.add(fileEntity);
//		ResponseEntity<List<FileEntity>> result = new ResponseEntity<List<FileEntity>>(fileEntityObj, HttpStatus.OK);
//		Mockito.when(filePersistanceService.getAllFiles()).thenReturn(result);
//		result = excelApi.getAllFiles();
//		assertEquals(HttpStatus.OK, result.getStatusCode());
//	}
//	
//	@Test
//	public void testGetFileById_Exception() throws FileNotFoundException {
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("");
//		Mockito.when(filePersistanceService.getFileById(fileEntity.getId())).thenThrow(FileNotFoundException.class);
//		assertThrows(FileNotFoundException.class, () -> excelApi.getFileById(""));
//	}
//	
//	
//	@Test
//	public void testdeleteFileById() throws FileNotFoundException {
//		FileEntity fileEntity = new FileEntity();
//		Map<String, String> map = new HashMap<>();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		ResponseEntity<Map<String, String>>  deleteFile = new ResponseEntity<Map<String, String>>(HttpStatus.OK);
//		Mockito.when(filePersistanceService.deleteFileByID(fileEntity.getId())).thenReturn(deleteFile);
//	}
//	
//	@Test
//	public void testdeleteFiles() {
//		List<String> fileIds = new ArrayList<>();
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		fileIds.add(fileEntity.getId());
//		 ResponseEntity<String> deleteFiles = new  ResponseEntity<String>(HttpStatus.OK);
//		 Mockito.when(filePersistanceService.deleteFiles(fileIds)).thenReturn(deleteFiles);
//	}
//
////	@Test
////	public void testdeleteFileById() throws FileNotFoundException {
////		FileEntity fileEntity = new FileEntity();
////		Map<String, String> map = new HashMap<>();
////		fileEntity.setId("6392f3bc8422cb5efd623e0a");
////		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
////		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
////		fileEntity.setData(data);
////		fileEntity.setUpdatedBy("You");
////		fileEntity.setCreatedDate("");
////		fileEntity.setStatus("Uploaded");
////		fileEntity.setActive(true);
////		fileEntity.setFileCategory("Hcr");
////		ResponseEntity<Map<String, String>>  deleteFile = new ResponseEntity<Map<String, String>>(HttpStatus.OK);
////		Mockito.when(filePersistanceService.deleteFileByID(fileEntity.getId())).thenReturn(deleteFile);
////		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete("/excel/deleteFile/{id}")).param("",fileEntity)
////				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).andExcept(MockMvcResultMatchers.status().isOk())
////				.andDo(MockMvcResultHandlers.print()).andReturn();
////		MockHttpServletResponse apiResp = mvcResult.getResponse();
////		assertNotNull(apiResp);
////	}
//		
//
//}
