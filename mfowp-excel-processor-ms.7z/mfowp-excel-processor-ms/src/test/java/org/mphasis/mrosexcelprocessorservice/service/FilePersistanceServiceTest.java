//package org.mphasis.mrosexcelprocessorservice.service;
//
//import static org.assertj.core.api.Assertions.contentOf;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.HexFormat;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//import org.mphasis.mfowp.excelprocessor.ms.entity.FileEntity;
//import org.mphasis.mfowp.excelprocessor.ms.exception.ExcelConstants;
//import org.mphasis.mfowp.excelprocessor.ms.exception.FileStorageException;
//import org.mphasis.mfowp.excelprocessor.ms.repository.FileRepository;
//import org.mphasis.mfowp.excelprocessor.ms.service.FilePersistanceServiceImpl;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.mock.web.MockMultipartFile;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//import org.springframework.web.context.WebApplicationContext;
//import org.springframework.web.multipart.MultipartFile;
//
//public class FilePersistanceServiceTest {
//
//	FileRepository fileRepository;
//
//	FilePersistanceServiceImpl filePersistanceService;
//
//	@Autowired
//	private WebApplicationContext webApplicationContext;
//
//	byte[] data = HexFormat.of().parseHex("e04fd020ea3a6910a2d808002b30309d");
//
//	@BeforeEach
//	public void setUp() {
//		filePersistanceService = new FilePersistanceServiceImpl();
//		fileRepository = Mockito.mock(FileRepository.class);
//		filePersistanceService.setFileRepository(fileRepository);
//	}
//
//	@Test
//	public void testGetFileById() throws FileNotFoundException {
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		Mockito.when(fileRepository.findById(fileEntity.getId())).thenReturn(Optional.of(fileEntity));
//		ResponseEntity<FileEntity> fileEntityObj = filePersistanceService.getFileById("6392f3bc8422cb5efd623e0a");
//		assertNotNull(fileEntityObj);
//	}
//
//	@Test
//	public void testGetAllFiles() throws FileNotFoundException {
//		List<FileEntity> fileEntityObj = new ArrayList<>();
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		fileEntityObj.add(fileEntity);
//		Mockito.when(fileRepository.findAll()).thenReturn(fileEntityObj);
//		ResponseEntity<List<FileEntity>> objFileEntity = filePersistanceService.getAllFiles();
//		assertNotNull(objFileEntity);
//		assertNotNull(filePersistanceService.getFileRepository());
//	}
//
//	@Test
//	public void testPersistFile() throws IOException {
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		MockMultipartFile file = new MockMultipartFile(fileEntity.getFileName(), fileEntity.getData());
//		Mockito.when(fileRepository.save(Mockito.any())).thenReturn(fileEntity);
//		FileEntity fileEntitytObj = filePersistanceService.persistFile(fileEntity.getFileCategory(), file);
//		assertNotNull(fileEntitytObj);
//	}
//
////	@Test
////	public void testPersistFile_Negative() throws FileStorageException {
////		FileEntity fileEntity = new FileEntity();
////		//fileEntity.setId("");
////		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
////		fileEntity.setData(data);
////		fileEntity.setFileCategory("hcr");
////		MockMultipartFile file = new MockMultipartFile(fileEntity.getFileName(),fileEntity.getData());
////		Mockito.when(filePersistanceService.persistFile(fileEntity.getFileCategory(),file)).thenThrow(FileStorageException.class);
////		assertThrows(FileStorageException.class, () -> filePersistanceService.persistFile(fileEntity.getFileCategory(),file));
////	}
//
//	@Test
//	public void testDeleteFileByID() {
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
////		if (fileRepository.existsById("6392f3bc8422cb5efd623e0a")) {
////			Mockito.doNothing().when(fileRepository).deleteById(fileEntity.getId());
//		filePersistanceService.deleteFileByID(fileEntity.getId());
//	}
////	}
//
//	@Test
//	public void testDeleteFiles() {
//		List<String> fileIds = new ArrayList<>();
//		FileEntity fileEntity = new FileEntity();
//		fileEntity.setId("6392f3bc8422cb5efd623e0a");
//		fileEntity.setFileName("Data-HDR5-success (2).xlsx");
//		fileEntity.setFileType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//		fileEntity.setData(data);
//		fileEntity.setUpdatedBy("You");
//		fileEntity.setCreatedDate("");
//		fileEntity.setStatus("Uploaded");
//		fileEntity.setActive(true);
//		fileEntity.setFileCategory("Hcr");
//		fileIds.add(fileEntity.getId());
//		if (fileIds.size() > 0) {
//			Mockito.doNothing().when(fileRepository).deleteById(fileEntity.getId());
//			filePersistanceService.deleteFiles(fileIds);
//		}
//	}
//
//	@Test
//	public void testDeleteFileByID_Negative() {
//		FileEntity fileEntity = new FileEntity();
//		filePersistanceService.deleteFileByID(fileEntity.getId());
//	}
//
//	@Test
//	public void testDeleteFiles_Negative() {
//		List<String> fileIds = new ArrayList<>();
//		filePersistanceService.deleteFiles(fileIds);
//	}
//
//}
