//package org.mphasis.mfowpemployeemanagementservices;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class MfowpEmployeeManagementServicesApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
