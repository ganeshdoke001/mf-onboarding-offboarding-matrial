package org.mphasis.mros.transition.ms.exceptionClasses;

public class EmployeeNotFound extends Exception{
	private String errorMessage;
	public EmployeeNotFound(String errorMessage) {
		this.errorMessage=errorMessage;
	}

}
