package org.mphasis.mros.transition.ms.exceptionClasses;

public class IncorrectDateFormat extends Exception{
	private String errorMessage;
	private String highSeverity;
	
	public IncorrectDateFormat(String errorMessage, String highSeverity) {
		super();
		this.errorMessage=errorMessage;
		this.highSeverity=highSeverity;
		
	}


}
