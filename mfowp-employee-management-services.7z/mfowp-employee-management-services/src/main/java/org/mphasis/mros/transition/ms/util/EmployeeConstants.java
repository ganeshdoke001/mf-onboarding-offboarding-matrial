package org.mphasis.mros.transition.ms.util;

public class EmployeeConstants {

	public static final String EMP_NOT_FOUND = "Employee details Not found in database";

	public static final String NO_DATA_AVAILABLE = "No data present inside database";

	public static final String INCORRECT_DATE_FORMAT = "Enter Date In Correct Format(yyyy-mm-dd)";

	public static final String VALID_EMP_ID = "This Employee ID is Not found in database";

	public static final String EMP_ALREADY_EXISTS = "Employee already exists in data base";

	public static final String HIGH_SEVERITY_SUCCESS = "Success";

	public static final String No_Data_Found_Date = "No Data found in the given Date";

	public static final String No_Data_Found_DM = "No Data found for the given delivery manager Id";

	public static final String HIGH_SEVERITY_FAILURE = "Failure";
	
	public static final String Org_FedEx = "FedEx";

	public static final String Org_Mphasis = "Mphasis";

}
