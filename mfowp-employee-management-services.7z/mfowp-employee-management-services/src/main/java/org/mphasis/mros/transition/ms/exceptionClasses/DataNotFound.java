package org.mphasis.mros.transition.ms.exceptionClasses;

public class DataNotFound extends Exception{
	private String errorMessage;
	public DataNotFound(String errorMessage) {
		this.errorMessage=errorMessage;
	}


}
