package org.mphasis.mros.transition.ms.exceptionClasses;

public class EmpAlreadyExists extends Exception{
	private String errorMessage;
	public EmpAlreadyExists(String errorMessage) {
		this.errorMessage=errorMessage;
	}


}
