package org.mphasis.mros.transition.ms.util;

public class MonthNames {
    public static String dates(String month) {
        String d=null;
        switch(month) {
        case "Jan":
            d="2022-01-01:2022-01-31";
            break;
        case "Feb":
            d="2022-02-01:2022-02-31";
            break;
        case "Mar":
            d="2022-03-01:2022-03-31";
            break;
        case "Apr":
            d="2022-04-01:2022-04-31";
            break;
        case "May":
            d="2022-05-01:2022-05-31";
            break;
        case "Jun":
            d="2022-06-01:2022-06-31";
            break;
        case "Jul":
            d="2022-07-01:2022-07-31";
            break;
        case "Aug":
            d="2022-08-01:2022-08-31";
            break;
        case "Sep":
            d="2022-09-01:2022-09-31";
            break;
        case "Oct":
            d="2022-10-01:2022-10-31";
            break;
        case "Nov":
            d="2022-11-01:2022-11-31";
            break;
        case "Dec":
            d="2022-12-01:2022-12-31";
            break;
        }
        return d;
    }
    
}
