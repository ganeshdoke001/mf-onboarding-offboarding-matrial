package org.mphasis.mros.transition.ms.util;

public class DateUtil {
	
	
	public static String getStartDate(String month,String format) {
		return month+format+"01";
	}
	
	public static String getEndDate(String month,String format) {
		return month+format+"31";
	}

}
