package org.mphasis.employeemanagement.ms.repository;

import java.util.List;

import org.mphasis.employeemanagement.ms.entity.EmployeeEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends MongoRepository<EmployeeEntity, Integer>{

}
