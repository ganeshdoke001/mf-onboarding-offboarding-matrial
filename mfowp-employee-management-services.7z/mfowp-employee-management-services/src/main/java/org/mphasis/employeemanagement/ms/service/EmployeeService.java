package org.mphasis.employeemanagement.ms.service;


import java.util.List;

import javax.validation.Valid;

import org.mphasis.employeemanagement.ms.entity.EmployeeEntity;
import org.mphasis.mros.transition.ms.exceptionClasses.DataNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.EmpAlreadyExists;
import org.mphasis.mros.transition.ms.exceptionClasses.EmployeeNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;
import org.mphasis.mros.transition.ms.exceptionClasses.ValidEmpID;
import org.springframework.http.ResponseEntity;

public interface EmployeeService {
	
	// To insert new Employee Data
	public ResponseEntity<EmployeeEntity> insertnewEmployeeDetails(EmployeeEntity emp) throws EmpAlreadyExists;

	// Get Employee data (Employee Details Data)
	public ResponseEntity<?> getEmployeeById(int empNumber) throws EmployeeNotFound;
	
	// Delete Employee data (Employee Details Data)
	public ResponseEntity<?> deleteEmployeeById(int empNumber) throws DataNotFound;

	// Update Employee data
	public ResponseEntity<EmployeeEntity> updateEmployeeDetails(EmployeeEntity emp, int empNumber) throws ValidEmpID;
	
	//MJ start
	public ResponseEntity<?> fetchEmployeeList(int dmEmpNumber,String startDate,String endDate,String Status) throws IncorrectDateFormat;
    //MJ end

}
