package org.mphasis.employeemanagement.ms.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Employee")
public class EmployeeEntity {
	

	@Id
	private int employeeNumber;
	private String employeeName;
	private String dateOfJoining;
	private String transition;
	private String workLocation;
	private String position;
	private String gradeDescription;
	private String employeeCategory;
	private String projectManagerId;
	private String projectManagerName;
	private String projectManagerContact;
	private int deliveryManagerId;//MJ
	private String deliveryManagerName;
	private String projectNumber;
	private String projectName;
	private String resourceAllocationStatus;
    //MJ start
	private Date releaseDate;
	private String offboardingStatus;
	//MJ end
	public EmployeeEntity(int employeeNumber, String employeeName, String dateOfJoining, String transition,
			String workLocation, String position, String gradeDescription, String employeeCategory,
			String projectManagerId, String projectManagerName, String projectManagerContact, int deliveryManagerId,
			String deliveryManagerName, String projectNumber, String projectName, String resourceAllocationStatus,
			Date releaseDate, String offboardingStatus) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.dateOfJoining = dateOfJoining;
		this.transition = transition;
		this.workLocation = workLocation;
		this.position = position;
		this.gradeDescription = gradeDescription;
		this.employeeCategory = employeeCategory;
		this.projectManagerId = projectManagerId;
		this.projectManagerName = projectManagerName;
		this.projectManagerContact = projectManagerContact;
		this.deliveryManagerId = deliveryManagerId;
		this.deliveryManagerName = deliveryManagerName;
		this.projectNumber = projectNumber;
		this.projectName = projectName;
		this.resourceAllocationStatus = resourceAllocationStatus;
		this.releaseDate = releaseDate;
		this.offboardingStatus = offboardingStatus;
	}
	public EmployeeEntity() {
		super();
	}
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getTransition() {
		return transition;
	}
	public void setTransition(String transition) {
		this.transition = transition;
	}
	public String getWorkLocation() {
		return workLocation;
	}
	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getGradeDescription() {
		return gradeDescription;
	}
	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}
	public String getEmployeeCategory() {
		return employeeCategory;
	}
	public void setEmployeeCategory(String employeeCategory) {
		this.employeeCategory = employeeCategory;
	}
	public String getProjectManagerId() {
		return projectManagerId;
	}
	public void setProjectManagerId(String projectManagerId) {
		this.projectManagerId = projectManagerId;
	}
	public String getProjectManagerName() {
		return projectManagerName;
	}
	public void setProjectManagerName(String projectManagerName) {
		this.projectManagerName = projectManagerName;
	}
	public String getProjectManagerContact() {
		return projectManagerContact;
	}
	public void setProjectManagerContact(String projectManagerContact) {
		this.projectManagerContact = projectManagerContact;
	}
	public int getDeliveryManagerId() {
		return deliveryManagerId;
	}
	public void setDeliveryManagerId(int deliveryManagerId) {
		this.deliveryManagerId = deliveryManagerId;
	}
	public String getDeliveryManagerName() {
		return deliveryManagerName;
	}
	public void setDeliveryManagerName(String deliveryManagerName) {
		this.deliveryManagerName = deliveryManagerName;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getResourceAllocationStatus() {
		return resourceAllocationStatus;
	}
	public void setResourceAllocationStatus(String resourceAllocationStatus) {
		this.resourceAllocationStatus = resourceAllocationStatus;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getOffboardingStatus() {
		return offboardingStatus;
	}
	public void setOffboardingStatus(String offboardingStatus) {
		this.offboardingStatus = offboardingStatus;
	}
	
	
	
}
