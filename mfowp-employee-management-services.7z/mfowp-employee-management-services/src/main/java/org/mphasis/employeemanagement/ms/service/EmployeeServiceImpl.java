package org.mphasis.employeemanagement.ms.service;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.mphasis.employeemanagement.ms.entity.EmployeeEntity;
import org.mphasis.employeemanagement.ms.repository.EmployeeRepository;
import org.mphasis.mros.transition.ms.exceptionClasses.DataNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.EmpAlreadyExists;
import org.mphasis.mros.transition.ms.exceptionClasses.EmployeeNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;
import org.mphasis.mros.transition.ms.exceptionClasses.ValidEmpID;
import org.mphasis.mros.transition.ms.util.EmployeeConstants;
import org.mphasis.mros.transition.ms.vo.EmpTransitionResponseVO;
import org.mphasis.mros.transition.ms.vo.NotificationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);

	@Override
	public ResponseEntity<EmployeeEntity> insertnewEmployeeDetails(EmployeeEntity emp) throws EmpAlreadyExists {
		EmployeeEntity empDetails = null;
		try {
			empDetails = employeeRepository.insert(emp);
			logger.debug("EmployeeServiceImpl.addEmployeeDetails()");
			return empDetails == null ? new ResponseEntity<EmployeeEntity>(empDetails, HttpStatus.BAD_REQUEST)
					: new ResponseEntity<EmployeeEntity>(empDetails, HttpStatus.CREATED);
		} catch (Exception e) {
			System.out.println(e);
			throw new EmpAlreadyExists(EmployeeConstants.EMP_ALREADY_EXISTS);
		}
	}

	@Override
	public ResponseEntity<?> getEmployeeById(int empNumber) throws EmployeeNotFound {
		EmployeeEntity empDetails = null;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			empDetails = employeeRepository.findById(empNumber).get();
			logger.debug("EmployeeServiceImpl.getEmployeeById()");
			if (empDetails != null) {
				responseObj.put("empList", empDetails);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			throw new EmployeeNotFound(EmployeeConstants.EMP_NOT_FOUND);

		}
	}

	@Override
	public ResponseEntity<?> deleteEmployeeById(int empNumber) throws DataNotFound {
		EmployeeEntity empDetails = null;
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			Map<String, Object> responseObj = new HashMap<String, Object>();
			empDetails = employeeRepository.findById(empNumber).get();
			employeeRepository.deleteById(empNumber);
			logger.debug("MongoDAOImpl.deleteEmployeeById()");
			if (empDetails != null) {
				responseObj.put("empList", empDetails);
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,
						EmployeeConstants.HIGH_SEVERITY_SUCCESS, "410", "APP"));

				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.GONE);
			} else {
				empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
				empTransitionResponseVO.setData(responseObj);
				empTransitionResponseVO.setNotification(
						new NotificationVO("NO DATA", EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
				return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			throw new DataNotFound(EmployeeConstants.NO_DATA_AVAILABLE);

		}

	}

	@Override
	public ResponseEntity<EmployeeEntity> updateEmployeeDetails(EmployeeEntity emp, int empNumber) throws ValidEmpID {
		try {
			EmployeeEntity empDetails = employeeRepository.findById(empNumber).get();
			empDetails.setEmployeeNumber(emp.getEmployeeNumber());
			empDetails.setEmployeeName(emp.getEmployeeName());
			empDetails.setDateOfJoining(emp.getDateOfJoining());
			empDetails.setTransition(emp.getTransition());
			empDetails.setWorkLocation(emp.getWorkLocation());
			empDetails.setPosition(emp.getPosition());
			empDetails.setGradeDescription(emp.getGradeDescription());
			empDetails.setEmployeeCategory(emp.getEmployeeCategory());
			empDetails.setProjectManagerId(emp.getProjectManagerId());
			empDetails.setProjectManagerName(emp.getProjectManagerName());
			empDetails.setProjectManagerContact(emp.getProjectManagerContact());
			empDetails.setDeliveryManagerId(emp.getDeliveryManagerId());
			empDetails.setDeliveryManagerName(emp.getDeliveryManagerName());
			empDetails.setProjectNumber(emp.getProjectNumber());
			empDetails.setProjectName(emp.getProjectName());
			empDetails.setResourceAllocationStatus(emp.getResourceAllocationStatus());
			employeeRepository.save(empDetails);
			logger.debug("MongoDAOImpl.updateEmployeeDetails()");
			if (empDetails != null)
				return new ResponseEntity<EmployeeEntity>(empDetails, HttpStatus.OK);
			else
				throw new ValidEmpID(EmployeeConstants.VALID_EMP_ID);

		} catch (Exception e) {
			System.out.println(e);
			throw new ValidEmpID(EmployeeConstants.VALID_EMP_ID);
		}
	}

	//MJ Start
	@Override
	public ResponseEntity<?> fetchEmployeeList(int dmEmpNumber,String startDate, String endDate, String Status) throws IncorrectDateFormat {
		EmpTransitionResponseVO empTransitionResponseVO = new EmpTransitionResponseVO();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			Date startDate1 = null;
			Date endDate1 = null;
			startDate1 = formatter.parse(startDate);
			endDate1 = formatter.parse(endDate);
			System.out.println(Status);
			Query queryObj = new Query();
			if (dmEmpNumber > 0 && Status.equalsIgnoreCase("Offboarding")) {
				queryObj.addCriteria(new Criteria().orOperator(Criteria.where("offboardingStatus").is("Account Offboarding"),Criteria.where("offboardingStatus").is("Mphasis Offboarding"))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1),
								Criteria.where("deliveryManagerId").is(dmEmpNumber)));
			}
			else if (dmEmpNumber == 0 && Status.equalsIgnoreCase("Offboarding")) {
				queryObj.addCriteria(new Criteria().orOperator(Criteria.where("offboardingStatus").is("Account Offboarding"),Criteria.where("offboardingStatus").is("Mphasis Offboarding"))
						.andOperator(Criteria.where("releaseDate").gte(startDate1).lte(endDate1)));
			}
			List<EmployeeEntity> result = mongoTemplate.find(queryObj, EmployeeEntity.class);
			if(result.size()>0) {
					List<Map<String, Object>> finalResponse = new ArrayList<>();
					Map<String, Object> responseObj = new HashMap<String, Object>();
					if (dmEmpNumber != 0) {
						List<EmployeeEntity> empList = result.stream().filter(a -> (a.getDeliveryManagerId() == (dmEmpNumber)))
									.collect(Collectors.toList());
						responseObj.put("DeliveryManagerId", dmEmpNumber);
						responseObj.put("Emplist", empList);
						finalResponse.add(responseObj);	
					}else {
						List<Integer> dmIDs = new ArrayList<Integer>();
						for (EmployeeEntity res : result) {
							dmIDs.add(res.getDeliveryManagerId());
						}
						System.out.println(dmIDs);
						Set<Integer> setDmIDs = new LinkedHashSet<>();
						setDmIDs.addAll(dmIDs);
						System.out.println(setDmIDs);
						List<Integer> listDmId = new ArrayList<>(setDmIDs);
						for (int i = 0; i < listDmId.size(); i++) {
							List<EmployeeEntity> empList =null;
							Map<String, Object> responseObj1 = new HashMap<String, Object>();
							int dmId = listDmId.get(i);
							empList = result.stream().filter(a -> (a.getDeliveryManagerId() == (dmId)))
										.collect(Collectors.toList());
							responseObj1.put("DeliveryManagerId", listDmId.get(i));
							responseObj1.put("Emplist", empList);
							finalResponse.add(responseObj1);	
						
						}
						}
				
				
				
			empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
			empTransitionResponseVO.setData(finalResponse);
			empTransitionResponseVO
					.setNotification(new NotificationVO(EmployeeConstants.HIGH_SEVERITY_SUCCESS,EmployeeConstants.HIGH_SEVERITY_SUCCESS, "200", "APP"));
			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.OK);
		} else {
			empTransitionResponseVO.setHighestSeverity(EmployeeConstants.HIGH_SEVERITY_SUCCESS);
			empTransitionResponseVO.setData(result);
			empTransitionResponseVO
					.setNotification(new NotificationVO(EmployeeConstants.No_Data_Found_DM,EmployeeConstants.HIGH_SEVERITY_SUCCESS, "404", "APP"));
			return new ResponseEntity<EmpTransitionResponseVO>(empTransitionResponseVO, HttpStatus.NOT_FOUND);
		}
			
		} catch (DateTimeParseException | ParseException e) {
			throw new IncorrectDateFormat(EmployeeConstants.INCORRECT_DATE_FORMAT,EmployeeConstants.HIGH_SEVERITY_FAILURE);
		}
	}


}
