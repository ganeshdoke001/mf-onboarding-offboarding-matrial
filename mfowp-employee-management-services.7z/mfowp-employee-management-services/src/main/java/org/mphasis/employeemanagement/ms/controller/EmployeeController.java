package org.mphasis.employeemanagement.ms.controller;


import javax.validation.Valid;

import org.mphasis.employeemanagement.ms.entity.EmployeeEntity;
import org.mphasis.employeemanagement.ms.repository.EmployeeRepository;
import org.mphasis.employeemanagement.ms.service.EmployeeService;
import org.mphasis.mros.transition.ms.exceptionClasses.DataNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.EmpAlreadyExists;
import org.mphasis.mros.transition.ms.exceptionClasses.EmployeeNotFound;
import org.mphasis.mros.transition.ms.exceptionClasses.IncorrectDateFormat;
import org.mphasis.mros.transition.ms.exceptionClasses.ValidEmpID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
@Service
public class EmployeeController {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private EmployeeService employeeService;

	Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@PostMapping("/addnewEmployee")
	public ResponseEntity<EmployeeEntity> addEmployeeDetails(@Valid @RequestBody EmployeeEntity employeeDetails) throws EmpAlreadyExists {
		logger.info("inside addEmployeeDetails()");
		return employeeService.insertnewEmployeeDetails(employeeDetails);

	}

	@GetMapping("/getEmpById/{empNumber}")
	public ResponseEntity<?> getEmployeeById(@PathVariable("empNumber") int empNumber)
			throws EmployeeNotFound {
		logger.info("inside getEmployeeById()");
		return employeeService.getEmployeeById(empNumber);

	}
	
	@DeleteMapping("/deleteEmpById/{empNumber}")
	public ResponseEntity<?> deleteEmployeeById(@PathVariable int empNumber) throws DataNotFound{
		logger.info("inside deleteEmployeeById()");
		return employeeService.deleteEmployeeById(empNumber);

	}
	
	@PutMapping("/updateEmpById/{empNumber}")
	public ResponseEntity<EmployeeEntity> updateEmployeeDetails(@PathVariable int empNumber,
			@RequestBody EmployeeEntity emp) throws ValidEmpID {
		logger.info("inside updateEmployeeDetails()");
		return employeeService.updateEmployeeDetails(emp, empNumber);
	}
	
	//MJ start
	@GetMapping("/employeeList/{dmEmpNumber}")
	public ResponseEntity<?> fetchEmployeeList(@PathVariable(value = "dmEmpNumber",required = false) int dmEmpNumber,@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate,@RequestParam("Status") String Status) throws IncorrectDateFormat {
		return employeeService.fetchEmployeeList(dmEmpNumber,startDate, endDate,Status);
	}
	//MJ end 
}
