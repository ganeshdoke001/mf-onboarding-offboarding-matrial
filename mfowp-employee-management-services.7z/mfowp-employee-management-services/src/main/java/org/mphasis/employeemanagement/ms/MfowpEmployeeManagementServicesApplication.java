package org.mphasis.employeemanagement.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MfowpEmployeeManagementServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MfowpEmployeeManagementServicesApplication.class, args);
	}

}
