package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;


public class InformationSecurityAttestation {

	@Id
	@NotNull(message="Id :: Should not empty")
	private Integer id;
	
//	@NotNull(message="StartTime :: Should not empty")
////	@JsonFormat(pattern="localDateTime':'2019-02-06T03:45:42.01")
//	@NotEmpty(message="StartTime :: Should not empty")
	private LocalDateTime startTime;
	
//	@NotNull(message="StartTime :: Should not empty")
////	@JsonFormat(pattern="localDateTime':'2019-02-06T03:45:42.01")
//	@NotEmpty(message="CompletationTime :: Should not empty")
	private LocalDateTime completationTime;
	
    @NotNull
	@NotEmpty(message="Email :: Should not empty")
	private String email;
	
	@NotNull
	@NotEmpty(message="Name :: Should not empty")
	private String name;
	
	@NotNull
	@NotEmpty(message="EmployeeName :: Should not empty")
	private String employeeName;
	
	@NotNull(message="EmployeeId :: Should not empty")
	private Integer employeeId;
	
	@NotNull
	@NotEmpty(message="haveYouReadAndUnderstoodTheInformationSecurityDosAndDonts :: Should not empty")
	private String readAcknowledgement;//haveYouReadAndUnderstoodTheInformationSecurityDosAndDonts
	
	@NotNull
	@NotEmpty(message="AttestationAcknowledge :: Should not empty")
	private String attestationAcknowledgement;
	
	
	private String status;

	public InformationSecurityAttestation() {
		// TODO Auto-generated constructor stub
	}

	public InformationSecurityAttestation(Integer id, LocalDateTime startTime, LocalDateTime completationTime,
			String email, String name, String employeeName, Integer employeeId,
			String haveYouReadAndUnderstoodTheInformationSecurityDosAndDonts, String attestationAcknowledgement,
			String status) {
		super();
		this.id = id;
		this.startTime = startTime;
		this.completationTime = completationTime;
		this.email = email;
		this.name = name;
		this.employeeName = employeeName;
		this.employeeId = employeeId;
		this.readAcknowledgement = haveYouReadAndUnderstoodTheInformationSecurityDosAndDonts;
		this.attestationAcknowledgement = attestationAcknowledgement;
		this.status = status;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getCompletationTime() {
		return completationTime;
	}

	public void setCompletationTime(LocalDateTime completationTime) {
		this.completationTime = completationTime;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getreadAcknowledgement() {
		return readAcknowledgement;
	}

	public void setreadAcknowledgement(
			String readAcknowledgement) {
		this.readAcknowledgement = readAcknowledgement;
	}

	public String getAttestationAcknowledgement() {
		return attestationAcknowledgement;
	}

	public void setAttestationAcknowledgement(String attestationAcknowledgement) {
		this.attestationAcknowledgement = attestationAcknowledgement;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "InformationSecurityAttestation [id=" + id + ", startTime=" + startTime + ", completationTime="
				+ completationTime + ", email=" + email + ", name=" + name + ", employeeName=" + employeeName
				+ ", employeeId=" + employeeId + ", readAcknowledgement="
				+ readAcknowledgement + ", attestationAcknowledgement="
				+ attestationAcknowledgement + ", status=" + status + "]";
	}

}
