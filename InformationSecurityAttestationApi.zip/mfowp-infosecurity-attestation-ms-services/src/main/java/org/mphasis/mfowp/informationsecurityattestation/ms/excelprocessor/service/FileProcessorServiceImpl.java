package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelException;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelReader;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.mapper.InformationSecurityAttestationMapperImpl;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model.InformationSecurityAttestation;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.reader.InformationSecurityAttestationExcelReader;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.repository.ExcelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileProcessorServiceImpl implements FileProcessorService {

	private ExcelReader<InformationSecurityAttestation> infromationSecurityAttestationReader = new InformationSecurityAttestationExcelReader<InformationSecurityAttestation>();

	@Autowired
	private FilePersistanceService filePersistanceService;

	@Autowired
	private ExcelRepository excelRepository;

	@Autowired
	private InformationSecurityAttestationMapperImpl informationSecurityAttestationMapperImpl;

	@Autowired
	private FileValidationService fileValidationService;

	public List<InformationSecurityAttestation> process(String fileType, MultipartFile sourceFile) throws IOException {

		fileValidationService.validateFile(sourceFile);

		List<InformationSecurityAttestation> infromationSecurityAttestations = null;
		
		if (fileType.equalsIgnoreCase("infoSecurityAttestation")) {
			infromationSecurityAttestationReader.setSourceFile(sourceFile);
			if(infromationSecurityAttestationReader != null) {
				
				infromationSecurityAttestations = infromationSecurityAttestationReader.listRecords();
			}
		}

//		Save your file
		filePersistanceService.persistFile(fileType, sourceFile);

//		persist the records
//		by Ashish start
		for (int i = 0; i < infromationSecurityAttestations.size(); i++) 
		{
			InformationSecurityAttestation infoCheck = (InformationSecurityAttestation) infromationSecurityAttestations.get(i);
			InformationSecurityAttestationEntity informationSecurityAttestationEntity = new InformationSecurityAttestationEntity();
			Optional<InformationSecurityAttestationEntity>informationSecurityAttestationEntityOptional = excelRepository.findById(infoCheck.getId());
			if (informationSecurityAttestationEntityOptional.isPresent()) 
			{
				informationSecurityAttestationEntity = informationSecurityAttestationEntityOptional.get();

				infoCheck.setStatus("Update");
				excelRepository.save(informationSecurityAttestationMapperImpl.InformationSecurityAttestationToEmployee(infoCheck));
			}
			else
			{
				informationSecurityAttestationEntity.setStatus("New");
				infoCheck.setStatus("New");
				excelRepository.save(informationSecurityAttestationMapperImpl.InformationSecurityAttestationToEmployee(infoCheck));
			}
		}
		
		return infromationSecurityAttestations;

	}

	@Override
	public ResponseEntity<Object> uploadFile(String fileType, MultipartFile file)
			throws IOException, FileNotFoundException {
		List<?> data = null;

		try {
			data = process(fileType, file);
		} catch (ExcelException e) {
			e.getErrors();
			return new ResponseEntity<Object>(e.getErrors(), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return new ResponseEntity<Object>(data, new HttpHeaders(), HttpStatus.OK);
	}

}
