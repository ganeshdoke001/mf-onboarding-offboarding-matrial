package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model;

import java.util.ArrayList;
import java.util.List;

public class ExcelFileInfo {
	private String fileName;
	private List<ExcelHeader> headers;
	
	public ExcelFileInfo(){
		headers = new ArrayList<>();
	}
	public ExcelFileInfo(String fileName){
		this();
		this.fileName = fileName;
	}
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public List<ExcelHeader> getHeaders() {
		return headers;
	}
	public void setHeaders(List<ExcelHeader> headers) {
		this.headers = headers;
	}
	public void addHeader(ExcelHeader header) {
		this.headers.add(header);
	}
	

}
