package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.reader;

import java.time.LocalDateTime;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelRowMapper;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model.InformationSecurityAttestation;

public class InformationSecurityAttestationExcelRowMapper implements ExcelRowMapper<InformationSecurityAttestation> {

	@Override
	public InformationSecurityAttestation mapRow(Row nextExcelRow, int rowNum) throws ExcelDataProcessorException {

		InformationSecurityAttestation informationSecurityAttestation = new InformationSecurityAttestation();
		Integer valueInt;
		String valueStr;
		LocalDateTime valueDate;

		
		Cell cell = nextExcelRow.getCell(0);
		if(cell !=null) {
		valueInt = (int) cell.getNumericCellValue();
		informationSecurityAttestation.setId(valueInt);
		}
		
		cell = nextExcelRow.getCell(1);
		if(cell !=null) {
		valueDate = cell.getLocalDateTimeCellValue();
		informationSecurityAttestation.setStartTime(valueDate);
		}
		
		cell = nextExcelRow.getCell(2);
		if(cell !=null) {
        valueDate=cell.getLocalDateTimeCellValue();
        informationSecurityAttestation.setCompletationTime(valueDate);
		}
		
		cell = nextExcelRow.getCell(3);
		if(cell !=null) {
		valueStr=cell.getStringCellValue();
		informationSecurityAttestation.setEmail(valueStr);
		}
		
		
		cell = nextExcelRow.getCell(4);
		if(cell !=null) {
        valueStr=cell.getStringCellValue();
        informationSecurityAttestation.setName(valueStr);
		}
		
        cell = nextExcelRow.getCell(5);
        if(cell !=null) {
        valueStr=cell.getStringCellValue();
        informationSecurityAttestation.setEmployeeName(valueStr);
        }
        
        cell = nextExcelRow.getCell(6);
        if(cell !=null) {
        valueInt=(int)cell.getNumericCellValue();
        informationSecurityAttestation.setEmployeeId(valueInt);
        }
        
        cell = nextExcelRow.getCell(7);
        if(cell !=null) {
        valueStr=cell.getStringCellValue();
        informationSecurityAttestation.setreadAcknowledgement(valueStr);
        }
        
        cell = nextExcelRow.getCell(8);
        if(cell !=null) {
        valueStr=cell.getStringCellValue();
        informationSecurityAttestation.setAttestationAcknowledgement(valueStr);
        }
        
		return informationSecurityAttestation;
	}

}
