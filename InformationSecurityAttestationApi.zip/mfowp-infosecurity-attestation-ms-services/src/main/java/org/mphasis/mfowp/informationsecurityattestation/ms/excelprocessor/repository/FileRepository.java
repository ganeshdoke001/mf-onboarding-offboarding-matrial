package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.repository;

import java.util.List;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.FileEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface FileRepository extends MongoRepository<FileEntity, String> {
	
	List<FileEntity> findByFileName(String fileName);

}