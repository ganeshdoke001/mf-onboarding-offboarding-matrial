package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.reader;

import java.io.IOException;
import java.util.List;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelHeaderMapper;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelReader;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelTemplate;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model.ExcelFileInfo;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model.ExcelHeader;
import org.springframework.web.multipart.MultipartFile;

public class InformationSecurityAttestationExcelReader<InformationSecurityAttestation>
		implements ExcelReader<InformationSecurityAttestation> {

	private static ExcelFileInfo fileInfo;
	private ExcelTemplate excelTemplate;

	static {
		fileInfo = new ExcelFileInfo("infoSecurityAttestation");
		fileInfo.addHeader(new ExcelHeader(0, "A", "ID", "Integer"));
		fileInfo.addHeader(new ExcelHeader(1, "B", "Start time", "LocalDateTime"));
		fileInfo.addHeader(new ExcelHeader(2, "C", "Completion time", "LocalDateTime"));
		fileInfo.addHeader(new ExcelHeader(3, "D", "Email", "String"));
		fileInfo.addHeader(new ExcelHeader(4, "E", "Name", "String"));
		fileInfo.addHeader(new ExcelHeader(5, "F", "Employee Name.", "String"));
		fileInfo.addHeader(new ExcelHeader(6, "G", "Mphasis Employee ID (Check with your manager in case you are not aware).", "Integer"));
		fileInfo.addHeader(new ExcelHeader(7, "H", "Have you read and understood the Information Security - Dos and Don'ts?", "String"));
		fileInfo.addHeader(new ExcelHeader(8, "I", "Attestation Acknowledgement", "String"));

	}
	
	public InformationSecurityAttestationExcelReader() {

	}

	@Override
	public void setSourceFile(MultipartFile datafile) throws IOException {
		ExcelHeaderMapper<ExcelHeader> excelHeaderMapper = new InformationSecurityAttestationExcelHeaderMapper();
		excelTemplate = new ExcelTemplate(excelHeaderMapper, datafile, fileInfo);

	}

	@Override
	public List<InformationSecurityAttestation> listRecords() {
		List<InformationSecurityAttestation> hcrs = (List<InformationSecurityAttestation>) excelTemplate.lookup(new InformationSecurityAttestationExcelRowMapper());
		return hcrs;
	}

	@Override
	public InformationSecurityAttestation get(Integer rowNumber) {
		InformationSecurityAttestation hcr = (InformationSecurityAttestation) excelTemplate.lookup(rowNumber, new InformationSecurityAttestationExcelRowMapper());
		return hcr;
	}

}
