package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.mapper;


import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model.InformationSecurityAttestation;
import org.springframework.stereotype.Service;

@Service
public class InformationSecurityAttestationMapperImpl implements InformationSecurityAttestationMapper {

	@Override
	public InformationSecurityAttestationEntity InformationSecurityAttestationToEmployee(
			InformationSecurityAttestation informationSecurityAttestation) {

		InformationSecurityAttestationEntity informationSecurityAttestationEntity = new InformationSecurityAttestationEntity();
		informationSecurityAttestationEntity.setId(informationSecurityAttestation.getId());
		informationSecurityAttestationEntity.setStartTime(informationSecurityAttestation.getStartTime());
		informationSecurityAttestationEntity.setCompletationTime(informationSecurityAttestation.getCompletationTime());
		informationSecurityAttestationEntity.setName(informationSecurityAttestation.getName());
		informationSecurityAttestationEntity.setEmail(informationSecurityAttestation.getEmail());
		informationSecurityAttestationEntity.setEmployeeName(informationSecurityAttestation.getEmployeeName());
		informationSecurityAttestationEntity.setEmployeeId(informationSecurityAttestation.getEmployeeId());
		informationSecurityAttestationEntity.setreadAcknowledgement(informationSecurityAttestation.getreadAcknowledgement());
		informationSecurityAttestationEntity.setAttestationAcknowledgement(informationSecurityAttestation.getAttestationAcknowledgement());

		return informationSecurityAttestationEntity;

	}

	@Override
	public InformationSecurityAttestation EmployeeToInformationSecurityAttestation(
			InformationSecurityAttestationEntity informationSecurityAttestationEntity) {

		InformationSecurityAttestation informationSecurityAttestation = new InformationSecurityAttestation();
		informationSecurityAttestation.setId(informationSecurityAttestation.getId());
		informationSecurityAttestation.setStartTime(informationSecurityAttestation.getStartTime());
		informationSecurityAttestation.setCompletationTime(informationSecurityAttestation.getCompletationTime());
		informationSecurityAttestation.setName(informationSecurityAttestation.getName());
		informationSecurityAttestation.setEmail(informationSecurityAttestation.getEmail());
		informationSecurityAttestation.setEmployeeName(informationSecurityAttestation.getEmployeeName());
		informationSecurityAttestation.setEmployeeId(informationSecurityAttestation.getEmployeeId());
		informationSecurityAttestation.setreadAcknowledgement(informationSecurityAttestation.getreadAcknowledgement());
		informationSecurityAttestation.setAttestationAcknowledgement(informationSecurityAttestation.getAttestationAcknowledgement());
		return informationSecurityAttestation;
	}

}
