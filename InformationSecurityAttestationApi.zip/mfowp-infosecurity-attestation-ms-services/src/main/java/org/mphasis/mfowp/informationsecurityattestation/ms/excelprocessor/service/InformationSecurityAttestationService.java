package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.service;

import java.util.List;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public interface InformationSecurityAttestationService {

	public InformationSecurityAttestationEntity getInfoSecByid(Integer id);

	public List<InformationSecurityAttestationEntity> getAllInfoSec(InformationSecurityAttestationEntity entity);

	public InformationSecurityAttestationEntity saveInformationSecurityAttestation(
			InformationSecurityAttestationEntity entity);

	public Boolean deleteById(Integer id);

	public InformationSecurityAttestationEntity updateInformationSecurityAttestation(Integer id,
			InformationSecurityAttestationEntity entity);

	public Page<InformationSecurityAttestationEntity> findAll(Pageable pageable);

}
