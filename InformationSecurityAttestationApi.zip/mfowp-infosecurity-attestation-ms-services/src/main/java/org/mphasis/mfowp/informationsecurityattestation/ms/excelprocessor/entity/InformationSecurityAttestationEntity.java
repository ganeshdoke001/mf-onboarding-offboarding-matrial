package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="InfoSecurityAttestation")
public class InformationSecurityAttestationEntity {

	@Id
	private Integer id;
	
	
	private LocalDateTime startTime;
	
	
	private LocalDateTime completationTime;
	
	
	private String email;
	
	
	private String name;
	
	
	private String employeeName;
	
	
	private Integer employeeId;
	
	
	private String readAcknowledgement;
	
	
	private String attestationAcknowledgement;
	
	
	private String status;

	public InformationSecurityAttestationEntity() {
		// TODO Auto-generated constructor stub
	}

	public InformationSecurityAttestationEntity(Integer id, LocalDateTime startTime, LocalDateTime completationTime,
			String email, String name, String employeeName, Integer employeeId,
			String readAcknowledgement, String attestationAcknowledgement,
			String status) {
		super();
		this.id = id;
		this.startTime = startTime;
		this.completationTime = completationTime;
		this.email = email;
		this.name = name;
		this.employeeName = employeeName;
		this.employeeId = employeeId;
		this.readAcknowledgement = readAcknowledgement;
		this.attestationAcknowledgement = attestationAcknowledgement;
		this.status = status;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getCompletationTime() {
		return completationTime;
	}

	public void setCompletationTime(LocalDateTime completationTime) {
		this.completationTime = completationTime;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getreadAcknowledgement() {
		return readAcknowledgement;
	}

	public void setreadAcknowledgement(
			String readAcknowledgement) {
		this.readAcknowledgement = readAcknowledgement;
	}

	public String getAttestationAcknowledgement() {
		return attestationAcknowledgement;
	}

	public void setAttestationAcknowledgement(String attestationAcknowledgement) {
		this.attestationAcknowledgement = attestationAcknowledgement;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "InformationSecurityAttestation [id=" + id + ", startTime=" + startTime + ", completationTime="
				+ completationTime + ", email=" + email + ", name=" + name + ", employeeName=" + employeeName
				+ ", employeeId=" + employeeId + ", readAcknowledgement="
				+ readAcknowledgement + ", attestationAcknowledgement="
				+ attestationAcknowledgement + ", status=" + status + "]";
	}


}
