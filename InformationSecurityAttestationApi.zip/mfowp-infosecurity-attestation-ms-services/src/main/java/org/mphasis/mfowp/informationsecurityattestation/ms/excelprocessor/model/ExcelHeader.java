package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model;

public class ExcelHeader {
	private Integer columnNumber;
	private String columnName;
	private String headerName;
	private String dataType;
	
	public ExcelHeader() {
		
		
	}
	
	public ExcelHeader(Integer columnNumber, String columnName, String headerName,String dataType) {
		super();
		this.columnName = columnName;
		this.columnNumber = columnNumber;
		this.headerName = headerName;
		this.dataType = dataType;
	}
	

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public Integer getColumnNumber() {
		return columnNumber;
	}

	public void setColumnNumber(Integer columnNumber) {
		this.columnNumber = columnNumber;
	}

	public String getHeaderName() {
		return headerName;
	}

	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}

	

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	@Override
	public String toString() {
		return "ExcelHeader [columnNumber=" + columnNumber + ", columnName=" + columnName + ", headerName=" + headerName
				+ ", dataType=" + dataType + "]";
	}
}
