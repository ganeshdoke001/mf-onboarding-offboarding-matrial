package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.mapper;


import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model.InformationSecurityAttestation;
import org.springframework.stereotype.Service;

@Service
public interface InformationSecurityAttestationMapper {

	InformationSecurityAttestationEntity InformationSecurityAttestationToEmployee(InformationSecurityAttestation informationSecurityAttestation);
	
	 InformationSecurityAttestation EmployeeToInformationSecurityAttestation(InformationSecurityAttestationEntity informationSecurityAttestationEntity);
}
