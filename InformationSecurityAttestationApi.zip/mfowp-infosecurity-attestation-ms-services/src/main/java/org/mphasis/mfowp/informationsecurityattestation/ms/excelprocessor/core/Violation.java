package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core;

import java.util.Date;

public class Violation {
	public String code;
	private String row;
	private String column;
	public String message;
	public Date timestamp;
	
	public Violation() {
		
	}
	
	public Violation(String code, String row, String column, String message, Date timestamp) {
		super();
		this.code = code;
		this.row = row;
		this.column = column;
		this.message = message;
		this.timestamp = timestamp;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getRow() {
		return row;
	}
	public void setRow(String row) {
		this.row = row;
	}
	public String getColumn() {
		return column;
	}
	public void setColumn(String column) {
		this.column = column;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String string) {
		this.message = string;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "Violation [code=" + code + ", row=" + row + ", column=" + column + ", message=" + message
				+ ", timestamp=" + timestamp + "]";
	}
	
	

}
