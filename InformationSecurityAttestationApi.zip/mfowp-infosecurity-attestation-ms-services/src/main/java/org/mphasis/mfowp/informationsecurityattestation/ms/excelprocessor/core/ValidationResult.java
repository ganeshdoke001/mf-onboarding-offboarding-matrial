package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ValidationResult {
	 private boolean success = true;
	private List<Violation> violations = new ArrayList<Violation>(); 

	public ValidationResult(){
		 this.success = true;
	}
	
	public ValidationResult(Violation violation) {
		this.success = false;
		this.violations.add(violation);
	}
	
	ValidationResult(List<Violation> violations) {
        this.success = false;
        this.violations = violations;
    }

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public List<Violation> getViolations() {
		return violations;
	}

	public void setViolations(List<Violation> violations) {
		this.success = false;
		this.violations = violations;
	}
	public boolean add(Violation violation) {
		this.success = false;
		return this.violations.add(violation);
	}

}