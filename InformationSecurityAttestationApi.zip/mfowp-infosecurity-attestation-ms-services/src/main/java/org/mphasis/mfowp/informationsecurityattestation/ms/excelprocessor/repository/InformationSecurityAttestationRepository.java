package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.repository;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface InformationSecurityAttestationRepository extends MongoRepository<InformationSecurityAttestationEntity, Integer>{

}
