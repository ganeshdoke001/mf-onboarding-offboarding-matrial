package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.reader;

public class ExcelDataProcessorException extends RuntimeException {
	public ExcelDataProcessorException(){
		
	}
}
