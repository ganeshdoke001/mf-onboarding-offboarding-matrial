package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity;

public class Assets {
	private String assetName;
	private String status;
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Assets(String assetName, String status) {
		super();
		this.assetName = assetName;
		this.status = status;
	}

}
