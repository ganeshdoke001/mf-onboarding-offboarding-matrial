package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.Api;

import java.util.List;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.service.InformationSecurityAttestationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/info-security")
public class InformationSecurityAttestationApi {

	@Autowired
	private InformationSecurityAttestationService informationSecurityAttestationService;

	@PostMapping()
	public ResponseEntity<InformationSecurityAttestationEntity> saveInformationSecurityAttestation(@RequestBody InformationSecurityAttestationEntity entity){
		InformationSecurityAttestationEntity infoSecEntity=informationSecurityAttestationService.saveInformationSecurityAttestation(entity);
		return new ResponseEntity<InformationSecurityAttestationEntity>(infoSecEntity,HttpStatus.ACCEPTED);
	}

	@GetMapping("/{id}")
	public ResponseEntity<InformationSecurityAttestationEntity> getInfoSecByid(@PathVariable Integer id, InformationSecurityAttestationEntity entity){
		InformationSecurityAttestationEntity infoSecEntity=informationSecurityAttestationService.saveInformationSecurityAttestation(entity);
		return new ResponseEntity<InformationSecurityAttestationEntity>(infoSecEntity,HttpStatus.OK);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<InformationSecurityAttestationEntity>> getAllInfoSec(@PathVariable InformationSecurityAttestationEntity entity){
		List<InformationSecurityAttestationEntity> infoSecEntity=informationSecurityAttestationService.getAllInfoSec(entity);
		return new ResponseEntity<List<InformationSecurityAttestationEntity>>(infoSecEntity,HttpStatus.OK);
	}
	
	
	@PutMapping("/{id}")
	public ResponseEntity<InformationSecurityAttestationEntity> updateInformationSecurityAttestation(@RequestBody InformationSecurityAttestationEntity entity,Integer id){
		InformationSecurityAttestationEntity infoSecEntity=informationSecurityAttestationService.updateInformationSecurityAttestation(id, entity);
		return new ResponseEntity<InformationSecurityAttestationEntity>(infoSecEntity,HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Boolean> deleteById(@PathVariable Integer id){
		Boolean infoSecEntity=informationSecurityAttestationService.deleteById(id);
		return new ResponseEntity<Boolean>(infoSecEntity,HttpStatus.FORBIDDEN);
	}
	
	@GetMapping("/paging")
	public Page<InformationSecurityAttestationEntity> findAll(@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "3") int size) {
		Pageable paging = PageRequest.of(page, size);
		return informationSecurityAttestationService.findAll(paging);

	}
}
