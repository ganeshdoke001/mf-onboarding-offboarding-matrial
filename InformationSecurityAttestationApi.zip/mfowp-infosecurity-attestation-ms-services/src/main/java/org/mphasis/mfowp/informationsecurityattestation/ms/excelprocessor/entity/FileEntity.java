package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "files")
public class FileEntity {
    
	@Id
	private String id;
    
    @Field("fileName")
	private String fileName;

	private String fileType;

	private byte[] data;

	private  String updatedBy;
	
	private String createdDate;
	
	private String status;
	
	private boolean active;
	
	private String fileCategory;

	public FileEntity() {}
	
	public FileEntity(String fileName, String fileType, byte[] data, String updatedBy, String createdDate,
			String status, boolean active, String fileCategory) {
		this.fileName = fileName;
		this.fileType = fileType;
		this.data = data;
		this.updatedBy = updatedBy;
		this.createdDate = createdDate;
		this.status = status;
		this.active = active;
		this.fileCategory = fileCategory;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}
	
	
	

}

