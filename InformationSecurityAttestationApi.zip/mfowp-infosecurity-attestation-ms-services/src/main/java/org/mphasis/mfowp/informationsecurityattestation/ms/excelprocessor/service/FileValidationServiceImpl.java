package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.List;
import java.util.Optional;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelException;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.core.ExcelReader;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.FileEntity;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.exception.ExcelConstants;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.exception.FileNotAvailableException;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.exception.InvalidFileException;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.mapper.InformationSecurityAttestationMapperImpl;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.model.InformationSecurityAttestation;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.reader.InformationSecurityAttestationExcelReader;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.repository.FileRepository;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.repository.ExcelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileValidationServiceImpl implements FileValidationService {

	@Autowired
	private FileRepository fileRepository;

	@Autowired
	private ExcelRepository excelRepository;

	@Autowired
	private InformationSecurityAttestationMapperImpl informationSecurityAttestationMapperImpl;

	private ExcelReader<InformationSecurityAttestation> informationSecurityAttestationReader = new InformationSecurityAttestationExcelReader<InformationSecurityAttestation>();

	// by manoj changed to ValidateExcel
	public List<InformationSecurityAttestation> validateExcel(String fileType, MultipartFile sourceFile)
			throws IOException {
		List<InformationSecurityAttestation> informationSecurityAttestations = null;

		if (fileType.equalsIgnoreCase("infoSecurityAttestation")) {
			informationSecurityAttestationReader.setSourceFile(sourceFile);
			informationSecurityAttestations = informationSecurityAttestationReader.listRecords();

			// by Ashish start
			System.out.println("InformationSecurityAttestation Record" + informationSecurityAttestations);
			for (int i = 0; i < informationSecurityAttestations.size(); i++) {
				InformationSecurityAttestation infoCheck = (InformationSecurityAttestation) informationSecurityAttestations
						.get(i);

				System.out.println("InformationSecurityAttestation: " + informationSecurityAttestations.get(i));

				Optional<InformationSecurityAttestationEntity> InformationSecurityAttestationEntityOptional = excelRepository.findById(infoCheck.getId());
				excelRepository.equals(informationSecurityAttestationMapperImpl.InformationSecurityAttestationToEmployee(infoCheck));
				
				if (InformationSecurityAttestationEntityOptional.isPresent()) {
					System.out.println("Record already exists");
					InformationSecurityAttestationEntity informationSecurityAttestationEntity = InformationSecurityAttestationEntityOptional
							.get();
					informationSecurityAttestationEntity.setStatus("Update");

					informationSecurityAttestationEntity.setId(infoCheck.getId());
					informationSecurityAttestationEntity
							.setStartTime(infoCheck.getStartTime());
					informationSecurityAttestationEntity
							.setCompletationTime(infoCheck.getCompletationTime());
					informationSecurityAttestationEntity.setName(infoCheck.getName());
					informationSecurityAttestationEntity.setEmail(infoCheck.getEmail());
					informationSecurityAttestationEntity
							.setEmployeeName(infoCheck.getEmployeeName());
					informationSecurityAttestationEntity
							.setEmployeeId(infoCheck.getEmployeeId());
					informationSecurityAttestationEntity.setreadAcknowledgement(
							infoCheck
									.getreadAcknowledgement());
					informationSecurityAttestationEntity.setAttestationAcknowledgement(
							infoCheck.getAttestationAcknowledgement());
					infoCheck.setStatus("Update");
					informationSecurityAttestationEntity.setStatus("Update");

				} else {
					InformationSecurityAttestationEntity informationSecurityAttestationEntity = new InformationSecurityAttestationEntity();
					informationSecurityAttestationEntity.setStatus("New");
					infoCheck.setStatus("New");
				}
			}
			// by Ashish end
		}
		return informationSecurityAttestations;
	}

	public String validateFile(MultipartFile file) throws FileNotFoundException, FileAlreadyExistsException {

		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		String extension = "";
		String ErrorMsg = "";
		if (file.isEmpty()) {
			throw new FileNotAvailableException(ExcelConstants.FILE_NOT_AVBL);
		}
		List<FileEntity> fileGot = fileRepository.findByFileName(fileName);
		int fileSize = fileGot.size();
		if (fileSize > 0) {
			throw new FileAlreadyExistsException(ExcelConstants.FILE_ALREADY_EXISTS);
		} else {
			int i = fileName.lastIndexOf('.');
			if (i >= 0) {
				extension = fileName.substring(i + 1);
				if (!extension.equals("xlsx")) {
					throw new InvalidFileException(ExcelConstants.INVALID_FILE);
				}
			}
		}
		return ErrorMsg;

	}

	public ResponseEntity<Object> validate(String fileType, MultipartFile file)
			throws IOException, FileNotFoundException {
		List<?> data = null;
		try {
			
			validateFile(file);
		} catch (Exception e) {
			// TODO: handle exception
		} {
			
		}

		try {
			data = validateExcel(fileType, file);// To be verified by tukaram;

		} catch (ExcelException e) {
			return new ResponseEntity<Object>(e.getErrors(), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return new ResponseEntity<Object>(data, new HttpHeaders(), HttpStatus.OK);

	}

}