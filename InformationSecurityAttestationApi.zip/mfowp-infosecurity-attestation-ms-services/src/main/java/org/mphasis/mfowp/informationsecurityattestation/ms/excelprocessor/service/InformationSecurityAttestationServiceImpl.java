package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.service;

import java.util.List;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.repository.InformationSecurityAttestationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class InformationSecurityAttestationServiceImpl implements InformationSecurityAttestationService {

	@Autowired
	private InformationSecurityAttestationRepository informationSecurityAttestationRepository;

	@Override
	public InformationSecurityAttestationEntity getInfoSecByid(Integer id) {
		InformationSecurityAttestationEntity entity=informationSecurityAttestationRepository.findById(id).get();
		return entity;
	}

	@Override
	public List<InformationSecurityAttestationEntity> getAllInfoSec(InformationSecurityAttestationEntity entity) {
		List<InformationSecurityAttestationEntity> infoSecEntity=informationSecurityAttestationRepository.findAll();
		return infoSecEntity;
	}

	@Override
	public InformationSecurityAttestationEntity saveInformationSecurityAttestation(
			InformationSecurityAttestationEntity entity) {
		InformationSecurityAttestationEntity informationSecurityAttestationEntity = informationSecurityAttestationRepository
				.save(entity);
		return informationSecurityAttestationEntity;
	}

	@Override
	public Page<InformationSecurityAttestationEntity> findAll(Pageable pageable) {

		return informationSecurityAttestationRepository.findAll(pageable);

	}

	@Override
	public InformationSecurityAttestationEntity updateInformationSecurityAttestation(Integer id,
			InformationSecurityAttestationEntity entity) {
       InformationSecurityAttestationEntity infoSecEntity=informationSecurityAttestationRepository.save(entity);
	    return infoSecEntity;
	}

	@Override
	public Boolean deleteById(Integer id) {
		informationSecurityAttestationRepository.deleteById(id);
		return deleteById(id);
	}

}
