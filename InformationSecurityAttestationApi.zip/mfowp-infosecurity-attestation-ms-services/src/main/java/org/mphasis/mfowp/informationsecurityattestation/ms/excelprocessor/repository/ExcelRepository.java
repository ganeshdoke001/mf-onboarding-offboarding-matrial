package org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.repository;

import org.mphasis.mfowp.informationsecurityattestation.ms.excelprocessor.entity.InformationSecurityAttestationEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExcelRepository extends MongoRepository<InformationSecurityAttestationEntity, Integer> {



}
